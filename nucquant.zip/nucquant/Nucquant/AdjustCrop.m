function [NewCropIma, NewRect, NewBoundaries, NewCentroid, MultipleCellInFinalCrop, Tag] = AdjustCrop(SingleCrop,CropRect,Boundaries, Centroid, MinSize,ColorChannel,OffsetDistance,Ima)

% This function is used to adjust the crop window. Actually, as the
% threshold value used to binarise the image is calculated with the whole
% image, it may not be adapted to each cell. And as the crop window is
% determined thanks to the cell borders, it may not really fit the cell.
% Thus, we check if the crop window has to be moved or changed by finding
% the new cell borders.
% As we use the function FindBoundaries, we need the Boundaries, the single
% crop, the minimum border size and the colorchannel. As we study the crop
% rectangle, we also need to know its coordinates. Finally, we have to know
% several things about the whole image, so we get it as an input parameter.

NewCropIma = SingleCrop;                                                                        % if the actual crop window is OK, ne need to change it
NewRect = CropRect;
NewBoundaries = Boundaries;
NewCentroid = Centroid;
MultipleCellInFinalCrop = false;

% Tag is a tag attached to the crop and that has the following format:
%     ->if Tag(1) = 1, then the crop is ok
%     ->if Tag(2) = 1, then the crop contains a cell on the border of the image
%     ->if Tag(3) = 1, then the crop contains more than one cell
Tag = zeros(1,3);                                                                               % begins by initializing the tags
Tag(1) = 1;                                                                                     % then assume that the crop is correct (not for long)

ImaWidth = size(Ima,1);                                                                         % gets the image width
ImaHeight = size(Ima,2);                                                                        % gets the image height

LIMITER = 1;                                                                                    % this is a counter that avoid oscillation problems

[Flag,N,B,C] = CompareBorderSize(Boundaries,SingleCrop,MinSize,ColorChannel);                   % checks if another detection is needed or not (for more details, have a look to the CompareBorderSize function

offset = OffsetDistance;                                                                        % small offset around the cell in order to get background information.... this will be shorten if necessary
MaxDist = 0;                                                                                    % maximum distance between the centroid and the border

while Flag == true;

    [Flag,N,B,C] = CompareBorderSize(Boundaries,NewCropIma,MinSize,ColorChannel);               % checks the new boundaries compared to the boundaries found on the previous crop

    clear NewCropIma;                                                                           % here we have to clear the data of the newcrop in order to fill the new crop with effective datas

    NMax = 0;                                                                                   % this loop is to determine which boder is the real border if there is more than one boundary in the crop
    label = 1;                                                                                  % label represents the label of the biggest border
    if N>1
        for j=1:N
            if length(B{j}) > NMax
                NMax = length(B{j});
                label = j;
            end
        end
    end

    XTL = NewRect(1);                                                                           % This is the top left corner of the actual crop (relatively to the x axis)
    YTL = NewRect(2);                                                                           % and relatively to the y axis
    SemiHeight = NewRect(3)/2;                                                                  % This is the semi-height of the actual crop (in order to find the centre of the crop)
    SemiWidth = NewRect(4)/2;                                                                   % and its semi-height

    CropCentroid(1) = XTL + SemiWidth;                                                          % These are the coordinates of the cell centroid in the global image (X and Y coordinates)
    CropCentroid(2) = YTL + SemiHeight;

    if iscell(C)                                                                                % As we can have several borders, we can also have several centroids in the image. Thus, we need to get the centroid of the biggest border (centroid of the cell)
        CellCentroid(1) = C{label,2} + XTL;                                                     % gets the centroid coordinates
        CellCentroid(2) = C{label,1} + YTL;
        B = B{label};
    else
        CellCentroid(1) = C(label,2) + XTL;
        CellCentroid(2) = C(label,1) + YTL;
    end

    NbrOfPts = length(B{label});                                                                % number of points in the biggest border

    for j=1:NbrOfPts                                                                            % For each point of the boudary, calculate the distance between the point and the centroid
        Dist = sqrt(((C(label,1)-B{label,:}(j,1)).^2+(C(label,2)-B{label,:}(j,2)).^2));
        if Dist > MaxDist                                                                        % Stock the greatest distance
            MaxDist = floor(Dist);
        end
    end

    XTLim = CellCentroid(1) - MaxDist;                                                          % Now let's fix the new Top Left corner of the new centroid
    YTLim = CellCentroid(2) - MaxDist;
    XBRim = CellCentroid(1) + MaxDist;                                                          % And also get the Bottom Right corner
    YBRim = CellCentroid(2) + MaxDist;

    if N > 1                                                                                    % If there is more than one cell detected in the crop, the offset needs to be shorten
        if offset > 2
            offset = floor(offset/2);
        else
            offset = 2;
        end
    end

    offsetL = offset;                                                                           % Now determines the offset for each direction (top, right, bottom and left)
    offsetT = offset;
    offsetR = offset;
    offsetB = offset;

    XTLncim = XTLim - offsetL;                                                                  % Now we can calculate the new crop borders, which are the Top left point added to the top and left offsets
    YTLncim = YTLim - offsetT;
    XBRncim = XBRim + offsetR;                                                                  % And the bottom right point added to the bottom and right offsets
    YBRncim = YBRim + offsetB;

    XTLncim = max(1,XTLncim);
    YTLncim = max(1,YTLncim);

    XBRncim = min(size(Ima,2),XBRncim);
    YBRncim = min(size(Ima,1),YBRncim);

    WidthCell = XBRncim - XTLncim;                                                         % calculates the width of the crop rectangle with offsets
    HeightCell = YBRncim - YTLncim;                                                        % calculates the height of the crop rectangle with offsets

    dx = NewRect(1) - XTLncim;                                                                  % this is the shift along the x axis between the actual crop and the new crop...
    dy = NewRect(2) - YTLncim;                                                                  % and this is the shift along the Y axis.

    NewRect = [XTLncim YTLncim WidthCell HeightCell];                                           % defines the new rect of the new crop window


    %     for i=0:NewRect(4)                                                                          % gets the new crop window in the global image
    %         for j=0:NewRect(3)
    % %             %             NewCropIma(i+1,j+1,1) = Ima(NewRect(2)+i,NewRect(1)+j,1);                           % red component
    % %                 %                 NewCropIma(i+1,j+1,2) = Ima(NewRect(2)+i,NewRect(1)+j,2);                           % green component
    % %                 %                 NewCropIma(i+1,j+1,3) = Ima(NewRect(2)+i,NewRect(1)+j,3);                           % blue component
    % %             end
    %              NewCropIma(i+1,j+1,:) = Ima(NewRect(2)+i,NewRect(1)+j,2);
    %         end
    %     end

    NewCropIma(1:HeightCell,1:WidthCell,:) = Ima(YTLncim:YTLncim+HeightCell-1,XTLncim:XTLncim+WidthCell-1,:);   %Ch.Z., oct 2007

    LIMITER = LIMITER + 1;                                                                      % Remember the limiter... for each loop step, it's increasing. If this counter goes up to ten, we can consider there is an oscillation in the detection, so we stop it.
    if LIMITER == 10                                                                            % if we detect an oscillation
        Flag = false;                                                                           % we force the loop to stop by setting the flag to false
        disp('Oscillations.... Stopping the analysis for this cell...');
    end

    if Flag == false                                                                            % if the flag value is false, then we get out of the loop
        clear NewBoundaries;                                                                    % but don't forget to save the new boundaries... so begin with cleraing it
        clear NewCentroid;                                                                      % and do the same for the new centroid of the main cell
        if iscell(B)                                                                            % Now if there is several boundaries found (case of several cells in the same crop)
            NewBoundaries(:,1) = B{label}(:,1)+dx;                                              % gets the biggest boundaries (corresponds to the effective cell)
            NewBoundaries(:,2) = B{label}(:,2)+dy;
            if iscell(C)                                                                        % if there is several cells, we also have to get the correct centroid
                NewCentroid(1) = C{label,1}+dx;
                NewCentroid(2) = C{lable,2}+dy;
            else
                NewCentroid(1) = C(label,1)+dx;
                NewCentroid(2) = C(label,2)+dy;
            end
        else                                                                                    % else, just get the only boundary and centroid
            NewBoundaries(:,1) = B(:,1)+dx;
            NewBoundaries(:,2) = B(:,2)+dy;
            NewCentroid(1) = C(label,1)+dx;
            NewCentroid(2) = C(label,2)+dy;
        end

        if N>1                                                                                  % if during the final step the number of cells in the crop is more than 1
            disp('More than one cell in this crop');                                            % just say it
            MultipleCellInFinalCrop = true;
            Tag(1) = 0; Tag(2) = 0; Tag(3) = 1;                                                 % and modify the tag
        end

    end

    Boundaries = B;                                                                             % in order to compare the actual boundary (which is now the new one) to the following boundary, set the Boundaries argument with B

end

% At the end of the analysis, we have to check if the crop contains a cell that is on the border of the image, then modify the tag if so
if (NewCentroid(1)+NewRect(2)-MaxDist <= 1) || (NewCentroid(1)*2+NewRect(2) > ImaWidth) || (NewCentroid(2)+NewRect(1)-MaxDist <= 1) || (NewCentroid(2)*2+NewRect(1) > ImaHeight)
    disp('Cell on the border of the image.... cannot do better');
    Tag(1) = 0; Tag(2) = 1; Tag(3) = 0;
end
