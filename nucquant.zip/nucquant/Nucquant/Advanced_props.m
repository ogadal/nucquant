function varargout = Advanced_props(varargin)
% ADVANCED_PROPS M-file for Advanced_props.fig
% Here is the code that controls the Advanced paramters dialog box
% This DB is used to enter different properties concerning the cell
% detection. As the user is not really supposed to modify these, we don't
% add these paramters to the main interface.
% There are 3 paramters:
%       -> the minimal radius for nuclei to be detected during the first
%       analysis of the image
%       -> the minimal radius for nuclei to be detected during the second
%       analysis (analysis of ROIs)
%       -> the offset distance between the cell border and the crop border

% Last Modified by GUIDE v2.5 19-Jul-2007 11:10:03

%% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Advanced_props_OpeningFcn, ...
                   'gui_OutputFcn',  @Advanced_props_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% Opening function (hello Dialog box)
function Advanced_props_OpeningFcn(hObject, eventdata, handles, varargin)

%While the GUI opens, we set the different values to the one set in the
%main application.
set(handles.MIN_RADIUS_1_EB,'string',getappdata(getappdata(0,'hGui'),'MinRadius1')*getappdata(getappdata(0,'hGui'),'dx')/(2*pi));   % Radius for first analysis
set(handles.MIN_RADIUS_2_EB,'string',getappdata(getappdata(0,'hGui'),'MinRadius2')*getappdata(getappdata(0,'hGui'),'dx')/(2*pi));   % Radius for second analysis
set(handles.DISTANCE_EB,'string',getappdata(getappdata(0,'hGui'),'OffsetDistance'));                        % offset distance
set(gcf,'Name','Advanced Settings');                                                                        % name of the GUI

handles.output = hObject;
guidata(hObject, handles);

%% Output function (goodbye Dialog Box)
function varargout = Advanced_props_OutputFcn(hObject, eventdata, handles)

varargout{1} = handles.output;

%% function that contains the min radius value for the first pass (doesn't do anything actually)
function MIN_RADIUS_1_EB_Callback(hObject, eventdata, handles)

function MIN_RADIUS_1_EB_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% function that contains the min radius value for the second pass (doesn't do anything neither)
function MIN_RADIUS_2_EB_Callback(hObject, eventdata, handles)

function MIN_RADIUS_2_EB_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function that contains the offset distance between the cell border and the crop border
function DISTANCE_EB_Callback(hObject, eventdata, handles)

function DISTANCE_EB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% function that controls the user =)
function figure1_KeyPressFcn(hObject, eventdata, handles)
% As we don't want the user to do anything stupid, we won't do anything
% stupid too...


%% function that control the OK push button
function OK_PB_Callback(hObject, eventdata, handles)

hGui = getappdata(0,'hGui');                                                                                % First, begin by begin by getting the application data set from the main program

setappdata(hGui,'MinRadius1',PerimeterCalculator(str2double(get(handles.MIN_RADIUS_1_EB,'string'))));       % Then we modify in this set the value of the minimal radius for the first detection step
setappdata(hGui,'MinRadius2',PerimeterCalculator(str2double(get(handles.MIN_RADIUS_2_EB,'string'))));       % Also the second one
setappdata(hGui,'OffsetDistance',str2double(get(handles.DISTANCE_EB,'string')));                            % And we add the value of the offset

figure1_CloseRequestFcn(hObject, eventdata, handles)                                                        % Now that everything has been saved, we can call the Closing function

function OK_PB_KeyPressFcn(hObject, eventdata, handles)

if get(gcf,'CurrentCharacter') == 13                                                                        % if the focus is set on the OK button and the user press the "Return" key
    OK_PB_Callback(hObject, eventdata, handles)                                                             % call the function that deals with the OK button
end

function figure1_CloseRequestFcn(hObject, eventdata, handles)
setappdata(getappdata(0,'hGui'),'ASFlag',false);                                                            % We tell the main program that this GUI has been closed
delete(gcf);                                                                                                % and we close it

%% Actually, we don't need the radius in micrometers, but the permiter in pixels.... so here is the function that makes the conversion
function Perimeter = PerimeterCalculator(Radius)

Perimeter = 2*pi*Radius/getappdata(getappdata(0,'hGui'),'dx');                                              % Permiter = 2*pi*Radius/pixel size

