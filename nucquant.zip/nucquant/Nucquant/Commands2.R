#Load required R.matlab package
library(nuclocR)
#Load data saved from Matlab
source('cont.R') 
source('uvmin.R')
source('uvmax.R')
source('uv2.R')
#Run one sample t test and save results
H <- Hpi(x=uv2, binned=TRUE)
gm <- kde.genemap.2d(x=uv2, H=H, xmin=uvmin, xmax=uvmax, gridsize=c(151,301))
estimate <- gm$estimate
evalu <- gm$eval[[1]]
evalv <- gm$eval[[2]]
cont <- contourLevels(gm, cont=cont)
  
#Save results to Matlab data file
write(estimate, "a12.txt", sep = "\t")
write(evalu,"a13.txt", sep = "\t")
write(evalv,"a14.txt", sep = "\t")
write(cont,"a15.txt", sep = "\t")