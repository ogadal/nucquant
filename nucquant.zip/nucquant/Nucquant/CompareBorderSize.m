function [IsNewBorderGreater, NumberOfEffectiveCells, BoundariesOfCrops, CentroidOfCrops] = CompareBorderSize(BoundariesOfCrop,SingleCrop,MinSize,ColorChannel)

% This function is used to check if we need to apply another detection in a
% given crop because broders are not well detected during the first
% detection step.

if iscell(BoundariesOfCrop)                                                         % As the boundaries can be composed of a single cell or several cells, we need to check it
    ActualSize = length(BoundariesOfCrop{1});                                       % Number of points in the cell borders.
else
    ActualSize = length(BoundariesOfCrop);
end

[N,B,C] = FindBoundaries(SingleCrop,MinSize,ColorChannel,false);                    % Detection of the new cell borders in the crop
NumberOfEffectiveCells = N;                                                         % Calculates the new number of cell found in the crop
BoundariesOfCrops = B;                                                              % Finds the new boundary (or boundaries)
CentroidOfCrops = C;                                                                % Finds the new centroid (or centroids)
NewSize = length(B{1});                                                             % Number of points in the cell borders.
if NewSize ~= ActualSize                                                            % If the new size is different from the previous size
    IsNewBorderGreater = true;                                                      % So we set the flag to True
else
    IsNewBorderGreater = false;                                                     % Else we set the flag to False
end