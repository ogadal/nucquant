function [NbrOfEffectiveCells, Boundaries, Centroids] = FindBoundaries(Image,MinSize,ColorChannel,DisplayText)

%The FindBoundaries function finds the boundaries of the different objects
%in an image. The RGB image is firstly transformed into a gray image in
%order to find a correct threshold value thanks to the Matlab graytresh()
%function. Then the image is binarized, and obects are filled if necessary.
%The borders are detected where a transition between a '0' and a '1'
%occurs. Connected boundaries are then stocked in a list of borders
%returned in the Boundaries output parameter. MinSize represents the
%minimum number of points in the boundary of one cell. This avoids the
%detection of artefacts as effective cells. The Centroids output parameter
%contains the list of the centroid of each boundary.

if DisplayText == true
    disp('Finding cells borders...');
end

if strcmp(ColorChannel,'green')                             % detects borders with the green component of the image
    if ndims(Image)>2 && size(Image,3)>=2
        Gray_Image = Image(:,:,2);
    else  % Ch.Z., oct 2007
        Gray_Image = Image(:,:);
    end
elseif strcmp(ColorChannel,'red')                           % detects borders with the red component of the image
    Gray_Image = Image(:,:,1);
elseif strcmp(ColorChannel,'both')                          % detects borders from the red and green components of the image
    Gray_Image = rgb2gray(Image);
else                                                        % there is a problem, so stop the analysis here
    disp('There is a problem concerning the color channel.... :(');
    return;
end

Threshold_Value = graythresh(Gray_Image);                   % Automatic detection of an appropriate threshold value relative to the image properties
Bin_Image = im2bw(Gray_Image,Threshold_Value);              % Binarisation of the gray image (8bits to 1bit per pixel)
Filled_Image = imfill(Bin_Image,'holes');                   % Fills objects that have holes after the binarisation
TempBoundaries = bwboundaries(Filled_Image);                % Finds the borders of cells and stocks them in the TempBoundaries cell array

% figure(1);
% Dims = size(Gray_Image);
% GIW = floor(Dims(1)/5)
% GIH = floor(Dims(2)/5)

% subplot(1,2,1)
% for i=1:GIW
%     for j=1:GIH
%         Bin_Image2(i,j) = Bin_Image(i,j);
%         Gray_Image2(i,j) = Gray_Image(i,j);
%     end
% end
% colormap(gray);
% imagesc(Gray_Image);
% subplot(1,2,1)
% imagesc(Bin_Image);
%
% subplot(1,2,2);
% hold on;
% imhist(Gray_Image);
% line([Threshold_Value*65536 Threshold_Value*65536],[0 5000],'color','r');
% hold off;
% pause;
% close(1);

if isempty(TempBoundaries)
    NbrOfEffectiveCells = 0;
    Boundaries = [];
    Centroids = [];
else

    NbrOfCells = length(TempBoundaries(:,1));                   % Number of boudaries foud

    Count = 0;                                                  % Allows to count the number of effective cells foud (rejects contours composed of less than MinSize points)

    for i=0:NbrOfCells-1                                        % Select the boundaries that have more than MinSize points
        NbrOfPoints = length(TempBoundaries{i+1});
        if NbrOfPoints > MinSize                                % Selection of the corrects boundaries
            Count = Count + 1;
            BX = 0; BY = 0;                                     % Calculation of the centroid of the boundary to display the label of the cell
            for j=1:NbrOfPoints
                BX = BX + TempBoundaries{i+1,:}(j,1);
                BY = BY + TempBoundaries{i+1,:}(j,2);
            end
            BX = floor(BX/NbrOfPoints );
            BY = floor(BY/NbrOfPoints );
            Centroids(Count,1) = BX;
            Centroids(Count,2) = BY;

            b=TempBoundaries{i+1};                              % Select the boundaries that fit to MinSize criterion
            Boundaries{Count} = b;
        end
    end

    Boundaries = Boundaries.';                                  % Transpose the Boundaries output parameter

    NbrOfEffectiveCells = length(Boundaries);                   % Calculate the number of cells that have been selected with the MinSize parameter

    if DisplayText == true
        disp(strcat('Number of detected objects: ',num2str(NbrOfCells)));
        disp(strcat('Number of effective cells found: ',num2str(NbrOfEffectiveCells)));
    end

end