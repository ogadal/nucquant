function varargout = IHM(varargin)
% IHM M-file for IHM.fig
%      IHM is a single interface that allows the user to open "tif" images
%      and find borders of the obects. A classification of the different
%      objects found is also achieved, and a crop of the image is done in
%      order to analyse each cell of the image.
% 
%  Renaud Tilte, april-sept 2007

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @IHM_OpeningFcn, ...
    'gui_OutputFcn',  @IHM_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

end

%% Beginning function... intialisation of several objects of the view
function IHM_OpeningFcn(hObject, eventdata, handles, varargin)

clc;
disp('============================================================================');
disp('import_nuclei_robot (beta version, R. Tilte)');
disp('Automatic detection of cell nuclei (Beta version, Renault Tilte april-sept 2007)')
disp('============================================================================');

handles.output = hObject;
guidata(hObject, handles);

% properties of the general GUI
set(0,'DefaultTextInterpreter','tex');                                                          % needs the TeX text interpretor in order to format text
set(gcf,'Name','import_nuclei_robot');                                                              % changes the main window title

% default values for the Find Nuclei properties panel
set(handles.GREENCHANNEL_CB,'Value',1);                                                         % default value for the channel we will use to detect cell borders... default, green is checked
set(handles.REDCHANNEL_CB,'Value',0);                                                           % default value for the red channel
set(handles.DISP_BORDERS_CB,'Value',1);

%default values for the Display crops properties panel
set(handles.WIDTH_EDITBOX,'string','4');                                                        % Sets the number of cells per tab to 4x3 cells
set(handles.HEIGHT_EDITBOX,'string','3');
set(handles.DISP_CROP_WINDOWS_CB,'Value',1);
set(handles.AUTODISP_RB,'Value',1);                                                             % default value for the "Auto Display"... default, we display crops in a tab GUI with automatic format
set(handles.CUSTOMDISP_RB,'Value',0);                                                           % default value for the "Custom Display" raio button
set(handles.SAVE_CORRECT_CROPS_RB,'Value',1);
set(handles.SAVE_ALL_CROPS_RB,'Value',0);

%default accessibility of the different items
SetFindNucleiPanelState('off',handles);                                                         % blocks the access to the "Find nuclei properties" panel
SetDisplayCropsPanelState('off',handles);                                                       % blocks the access to the "Display crops properties" panel
SetSavingOptionsPanelState('on',handles);                                                      % blocks the access to the "Saving properties" panel
set(handles.SWAP_PUSHBUTTON,'Enable','off');                                                    % blocks the access of the "Swap Red&Green" channels button
set(handles.SAVECROPS_PUSHBUTTON,'Enable','off');                                               % blocks the 'Save' button. As we save crops, it won't be possible to save before splitting the image

%defaulte values for microsettings
set(handles.DATASOURCE_ANDOR_CB, 'Value',1);                                                    % Data source
set(handles.DATASOURCE_PE_CB, 'Value',0);
set(handles.RINDEX_EDITBOX,'string','1.33');                                                    % Microsettings of the data source
set(handles.NA_EDITBOX,'string','1.4');
set(handles.EW_EDITBOX,'string','0.5');
set(handles.VDX_EDITBOX,'string','0.065');
set(handles.VDY_EDITBOX,'string','0.065');
set(handles.VDZ_EDITBOX,'string','0.25');
set(handles.RCHANNEL_PB,'Value',1);                                                             % Number of channels to study
set(handles.RVCHANNEL_PB,'Value',0);
set(handles.RVBCHANNEL_PB,'Value',1);

set(handles.MQC_PB,'Enable','off');                                                             % Disables the Manual Quality Control button
set(handles.ADV_PROP_PB,'Enable','off');                                                        % Also disables the Advanced properties button

set(handles.PROMPT_MI_ST,'Visible','off');

% default values for the application data set
setappdata(0,'hGui',gcf);                                                                       % defines an application data set
hGui = getappdata(0, 'hGui');                                                                   % handle to the data set
setappdata(hGui,'IsImageLoaded',false);                                                         % flag that prove that the image is not loaded yet
setappdata(hGui,'dx',str2double(get(handles.VDX_EDITBOX,'string')));                            % set the pixel size in the application data set
setappdata(hGui,'MinRadius1',60);                                                               % minimal radius under which a cell WILL NOT be detected (to find nuclei)
setappdata(hGui,'MinRadius2',10);                                                               % minimal radius above which a cell WILL be detected (to know when a crop contains more than one nucleus)
setappdata(hGui,'OffsetDistance',10);                                                           % offset distance between the cell border and the crop border

%OPENFOLDER_PUSHBUTTON_Callback(hObject, eventdata, handles);

end

%% Output function.... doesn't return anything actually :)
function varargout = IHM_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

end

%% Opening function....Used to open 'tif' images & modify acquisition parameters.
function OPEN_PUSHBUTTON_Callback(hObject, eventdata, handles)

disp('Opening the image');                                                                      % Displays to the command window what's happening
set(handles.EDIT_BOX_TEST,'string','Opening the image');

clearappdata();                                                                                 % call of a function that destroys the application data

setappdata(0, 'hGui', gcf);                                                                     % defines a context for application data
hGui = getappdata(0, 'hGui');                                                                   % handle to the application data
setappdata(hGui,'IsImageLoaded',false);                                                         % flag that prove that the image is loaded (or not)

if isappdata(hGui,'tabGUIFlag')                                                                 % checks if a previous analyse has been done and close the tab GUI if necessary
    if getappdata(hGui,'tabGUIFlag') == true
        close(handles.handleTabGUI);
        setappdata(hGui,'tabGUIFlag',false);
    end
end

%Gets the file to analyse...

if strcmp(get(handles.DATASOURCE_ANDOR_CB,'string'),'Andor')                                    % gets the data source
    input_parameters.data_format = 'Andor';
else
    input_parameters.data_format = 'Perkin-Elmer';
end

% gets the microparameters
n = str2double(get(handles.RINDEX_EDITBOX, 'string'));                                             % refractive index n of the sample medium
NA = str2double(get(handles.NA_EDITBOX,'string'));                                                 % numerical aperture for the objective lense
lambda = str2double(get(handles.EW_EDITBOX,'string'));                                             % emission wavelength
dx = str2double(get(handles.VDX_EDITBOX,'string'));                                                % voxel dimension along X axis
dy = str2double(get(handles.VDY_EDITBOX,'string'));                                                % voxel dimension along Y axis
dz = str2double(get(handles.VDZ_EDITBOX,'string'));                                                % voxel dimension along Z axis

setappdata(hGui,'outputformat','matlab');                                                       % output format for the cropped regions

%Creates several application data such as the effective RGB image
switch input_parameters.data_format
    case 'Perkin-Elmer'                                                                         % Import from Perkin-Elmer data
        Directory = uigetdir(dir0,'Select folder containing the Perkin-Elmer data');            % gets the folder where the image is stocked
        if Directory == 0                                                                       % if no file have been selected, don't continue
            disp('No file to analyse...');
            return;
        end
        disp('importing data...');                                                              % command display of what is happening
        set(handles.EDIT_BOX_TEST,'string','importing data...');                                % graphical display of what is happening
        [Nchannels,width,height,Nz,Ntimes,lambdas,imagenamestem] = importPEinfo(Directory);     % see the importePEinfo function for more details
        I3d = importPEdata(Directory,imagenamestem,Nchannels,width,height,Nz,Ntimes,1);         % see the importe PEdata function for more details
        Iinfo = [];
    case 'Andor'                                                                                % Import from tif files
        [FileToAnalyse,Directory] = uigetfile('*.tif','Select the single tif image file');      % opens a dialog box asking for the path of the file to open
        if FileToAnalyse == 0                                                                   % if no file have been selected, don't continue
            disp('No file to analyse...');
            return;
        end
        setappdata(hGui,'FileName',FileToAnalyse);                                              % File name added to application data
        FileToAnalyse = strcat(Directory,FileToAnalyse);                                        % Path of the file to analyse
        if get(handles.RCHANNEL_PB,'Value') == 0                                                % gettings the number of color channels
            Nchannels = 1;
        elseif get(handles.RVCHANNEL_PB,'Value') == 0
            Nchannels = 2;
        else
            Nchannels = 3;
        end
        [I3d, Iinfo] = importtif(FileToAnalyse,Nchannels);                                      % see the importtiff function for more details
        [aux,imagenamestem,aux2] = fileparts(FileToAnalyse);
        Nz = size(I3d,3);
        Ntimes = 1;
    otherwise
        error('unacceptable data format !');
end

% Adds the different parameters to the appliction data...
setappdata(hGui,'NTimes', Ntimes);
setappdata(hGui,'PathName',Directory);
setappdata(hGui,'I3d',I3d);
setappdata(hGui,'dx',dx);
setappdata(hGui,'dy',dy);
setappdata(hGui,'dz',dz);
setappdata(hGui,'n',n);
setappdata(hGui,'NA',NA);
setappdata(hGui,'lambda',lambda);
setappdata(hGui,'Iinfo',Iinfo);
setappdata(hGui,'Nchannels',Nchannels);
setappdata(hGui,'input_parameters',input_parameters);

%Prepares the image to be dispalyed
hwb = waitbar(0,'Computing max. int. proj. ...'); drawnow;                                      % waitbar
if Nz>1
    aux = squeeze(max(I3d,[],3));                                                               % building of the RGB image according to the number of channels
    if ndims(aux)==2 % if there is only a single channel, assign it to the green channel
        aux1(:,:,2) = aux;
        aux1(:,:,1) = zeros(size(aux));
        aux1(:,:,3) = zeros(size(aux));
        aux = aux1;
    end
    if size(aux,3) == 2
        set(handles.EDIT_BOX_TEST,'string','Padding third dimension of image with zeros..');    % graphical display of what is happening
        disp('Padding third dimension of image with zeros..');                                  % console display of what is happening
        aux(:,:,3) = zeros(size(aux(:,:,1)));
    end
    Ima = imadjust(aux,stretchlim(aux,[0.01 0.999]),[]);                                        % adjusts the image
    clear aux*;
else
    Ima = imadjust(I3d,stretchlim(I3d,[0.01 0.999]),[]);
end
% if Nz>1
%     if 1==0
%         aux = squeeze(max(I3d,[],3));                                                               % building of the RGB image according to the number of channels
%     else   % Ch.Z., oct 2007
%         aux = max(I3d,[],3);
%     end
%     if size(aux,3) == 2
%         set(handles.EDIT_BOX_TEST,'string','Padding third dimension of image with zeros..');    % graphical display of what is happening
%         disp('Padding third dimension of image with zeros..');                                  % console display of what is happening
%         aux(:,:,3) = zeros(size(aux(:,:,1)));
%     end
%     Ima = imadjust(aux,stretchlim(aux,[0.01 0.999]),[]);                                        % adjusts the image
%     clear aux;
% else
%     Ima = imadjust(I3d,stretchlim(I3d,[0.01 0.999]),[]);
% end
delete(hwb);                                                                                    % delete the waitbar
set(handles.EDIT_BOX_TEST,'string','Image correctly loaded... Press a button');     % says ti the user that the image is correctly loaded
% if ndims(Ima)>2 && size(Ima,3)>=2   % Ch.Z., oct 2007
if get(handles.checkbox8,'Value')
    Ima = SwapRG(Ima);                                                                       % as the reading of the file is "wrong", we have to swap the red and green channels
end
setappdata(hGui, 'Ima', Ima);                                                                   % adds the image to the application data
setappdata(hGui,'IsImageLoaded',true);                                                          % image loaded with success
axes(handles.Window);                                                                           % this sets IHM as the current figure
imagesc(Ima);                                                                                   % display the RGB image

set(handles.SWAP_PUSHBUTTON,'Enable','on');                                                     % allow the access to the "Swap RG" push button
set(handles.ADV_PROP_PB,'Enable','on');                                                        % allow the user to modify detection parameters
SetFindNucleiPanelState('on',handles);                                                          % also allow the user to modify some parameters in the "Find nuclei properties" panel
SetDisplayCropsPanelState('on',handles);                                                        % and allow the user to modify other parameters in the "Display crops properties" panel

end

%% function that controls the Edit box....As it is not usable, the function's empty ^___^
function EDIT_BOX_TEST_Callback(hObject, eventdata, handles)
end

%% function that controls the "Find Nuclei" button
function Boundary_PUSHBUTTON_Callback(hObject, eventdata, handles)

hGui = getappdata(0, 'hGui');                                                                   % gets the application data
if getappdata(hGui,'IsImageLoaded') == false                                                    % if no image has been loaded, no need to continue
    disp('You must open an image before trying to do anything');                                % so say it to the user
    set(handles.EDIT_BOX_TEST,'string','Nothing to analyse');
    return;
end

if getappdata(hGui,'tabGUIFlag') == true                                                        % if the tabGUI is already open, close it
    close(handles.handleTabGUI);
    setappdata(hGui,'tabGUIFlag',false);                                                        % and say to the program that the gui has been closed
end

Ima = getappdata(hGui, 'Ima');                                                                  % gets the image
width = size(Ima,1);                                                                            % width of the image
height = size(Ima,2);                                                                           % height of the image
if get(handles.GREENCHANNEL_CB,'Value') == 1 && get(handles.REDCHANNEL_CB,'Value') == 0         % gets the channel we're going to use to achieve the detection
    ColorChannel = 'green';
elseif get(handles.GREENCHANNEL_CB,'Value') == 0 && get(handles.REDCHANNEL_CB,'Value') == 1
    ColorChannel = 'red';
elseif get(handles.GREENCHANNEL_CB,'Value') == 1 && get(handles.REDCHANNEL_CB,'Value') == 1
    ColorChannel = 'both';
else
    disp('You must chose a color channel to achieve the analysis');                             % if there is a problem, juste stop the program and says what's happening
    set(handles.EDIT_BOX_TEST,'string','No color channel found');
    return;
end

MinRadius1 = getappdata(hGui,'MinRadius1');
MinRadius2 = getappdata(hGui,'MinRadius2');
OffsetDist = getappdata(hGui,'OffsetDistance');

[NbrOfEffectiveCells, Boundaries, Centroids] = FindBoundaries(Ima,MinRadius1,ColorChannel,true);        % See the FindBoundaries function for more details

[Mosaic_Of_Crops, CentroidsOfCrop, BoundariesOfCrop, CropRect] = Split_Image(NbrOfEffectiveCells, Boundaries, Centroids,Ima,OffsetDist);     % Automatic split of the image in small crops    .... see the "Split_Image" function for more details

set(handles.EDIT_BOX_TEST,'string','Finding cells border...');
hwb = waitbar(0,'Adjusting Crop Windows...');                                                   % waitbar
counterforSC = 0;                                                                               % counter that counts the number of crops that have more than one cell
counterforBC = 0;
counterforCC = 0;
for i=1:NbrOfEffectiveCells                                                                     % for each crop
    disp(strcat('Analysing cell n_',num2str(i)));                                               % display the label of the studied crop
    AdjustWB = waitbar(i/NbrOfEffectiveCells,hwb,['Adjusting crop window n� ',num2str(i),'/',num2str(NbrOfEffectiveCells),'...']);                                                          % adjuste the waitbar position
    [NewCropIma,NewRect,NewBoundaries,NewCentroid,MultipleCellInFinalCrop,Tag] = AdjustCrop(Mosaic_Of_Crops{i},CropRect{i},BoundariesOfCrop{i},CentroidsOfCrop(i,:),MinRadius2,ColorChannel,OffsetDist,Ima);    % for more details, check the "AdjustCrop" function
    CropRect{i} = NewRect;                                                                      % here is the new crop rectangle
    Mosaic_Of_Crops{i} = NewCropIma;                                                            % so we have to refresh the crop in the list of crop windows
    BoundariesOfCrop{i} = NewBoundaries;                                                        % here are the new coordinates for the boundary(ies) inside the new crop
    CentroidsOfCrop(i,:) = NewCentroid;                                                         % and the new centroid(s) for the new crop
    if Tag(3) == 1
        counterforSC = counterforSC + 1;
    elseif Tag(2) == 1
        counterforBC = counterforBC + 1;
    elseif Tag(1) == 1
        counterforCC = counterforCC + 1;
    end
    TagTable{i} = Tag;                                                                          % and finally, we set the tag value with the tag output variable of the "AdjustCrop" function (Tag = 001 for correct crop, Tag = 010 for crop on the border of the image, and Tag = 100 for a crop with several cells)
end
delete(AdjustWB);                                                                               % As the analysis is finished, we close the waitbar
disp(strcat(num2str(counterforSC),' crops with more than one cell'));                           % and we display in the command window the number of crops with more than one cell
disp(strcat(num2str(counterforBC),' crops with cell on border of the image'));
disp(strcat(num2str(counterforCC),' correct crops'));

% for i=1:NbrOfEffectiveCells
%     if TagTable{i}(3) == 1
%         [NewCropIma, NewRect, NewBoundaries, NewCentroid, MultipleCellInFinalCrop, Tag] = AdjustCropWithMultipleCells(CropRect{i},BoundariesOfCrop{i},MinRadius2,ColorChannel,Ima);
%         CropRect{i} = NewRect;
%         Mosaic_Of_Crops{i} = NewCropIma;
%         BoundariesOfCrop{i} = NewBoundaries;
%         CentroidsOfCrop(i,:) = NewCentroid(:);
%         TagTable{i} = Tag;
%     end
% end


% %%%%%%%%    Testing code    %%%%%%%%%%%%%%
% [NewCropIma, NewRect, NewBoundaries, NewCentroid] = AdjustCrop(Mosaic_Of_Crops{89},CropRect{89},BoundariesOfCrop{89},CentroidsOfCrop(89),4,ColorChannel,Ima);
%
% CropRect{89} = NewRect;
% Mosaic_Of_Crops{89} = NewCropIma;
% BoundariesOfCrop{89} = NewBoundaries;
% CentroidsOfCrop(89,:) = NewCentroid;
% %%%%%%%%    Testing code    %%%%%%%%%%%%%%


% Adds the different objects to the application data
setappdata(hGui,'NbrOfEffectiveCells', NbrOfEffectiveCells);                                    % adds the number of effective cells detected in the image
setappdata(hGui,'Boundaries', Boundaries);                                                      % adds the cell borders to the application data
setappdata(hGui,'Centroids', Centroids);                                                        % adds the centroids to the application data set
setappdata(hGui,'Mosaic_Of_Crops',Mosaic_Of_Crops);                                             % adds the several crops to the application data
setappdata(hGui,'CentroidsOfCrop',CentroidsOfCrop);                                             % adds the centroid of each object in each crop (avoid the calculation of the centroid coordiantes in the crop)
setappdata(hGui,'BoundariesOfCrop',BoundariesOfCrop);                                           % adds the boudaries of each object in each crop to the application data
setappdata(hGui,'CropRectangles', CropRect);                                                    % adds the rectangle defining each crop
setappdata(hGui,'CropTag',TagTable);                                                            % adds the TagTable (defines the category of crop) to the application data

setappdata(hGui, 'BThickness', 1);                                                              % defines the borders thickness to 1 pixel
setappdata(hGui, 'BColors', 'white');                                                           % defines the borders color to white


str = strcat('Number of effective cells: ',num2str(NbrOfEffectiveCells));                       % Number of effective objects found in the image
set(handles.EDIT_BOX_TEST,'string',str);                                                        % graphical display of what is happening

% If we only detect a small number of objects in the scene, we can diplay
% less cells in the tab view, this to get a more confortable display. If
% the number of object increases, the number of objects per tab increases
% too.
% Note that we had only 20 tabs.

if get(handles.AUTODISP_RB,'Value') == 1
    if NbrOfEffectiveCells <150
        set(handles.WIDTH_EDITBOX,'string','4');
        set(handles.HEIGHT_EDITBOX,'string','3');
    elseif NbrOfEffectiveCells <300
        set(handles.WIDTH_EDITBOX,'string','6');
        set(handles.HEIGHT_EDITBOX,'string','4');
    elseif NbrOfEffectiveCells <450
        set(handles.WIDTH_EDITBOX,'string','7');
        set(handles.HEIGHT_EDITBOX,'string','5');
    else
        set(handles.WIDTH_EDITBOX,'string','8');
        set(handles.HEIGHT_EDITBOX,'string','6');
    end
elseif get(handles.CUSTOMDISP_RB,'Value') == 1
    % nothing happens actually, the values are added by the final user
else
    disp('Problem in the Boundary_PUSHBUTTON_Callback function');                               % this should never happen, but if so, just tells where is the problem
end

setappdata(hGui,'WidhtForCrops',str2double(get(handles.WIDTH_EDITBOX,'string')));               % adds the number of objects per line to the application data
setappdata(hGui,'HeightForCrops',str2double(get(handles.HEIGHT_EDITBOX,'string')));             % adds the number of lines per pages to the application data

handleTabGUI = tabGUI;
handles.handleTabGUI = handleTabGUI;                                                            % handle to the tabGUI, in order to know if a new window is open or not when doing a new analysis
guidata(hObject, handles);                                                                      % update the handles
tabGUIFlag = true;                                                                              % flag to prove that a new window has been created
setappdata(hGui,'tabGUIFlag',tabGUIFlag);                                                       % adds flag to the application data

set(handles.SAVECROPS_PUSHBUTTON,'Enable','on');                                                % allow the user to save the crops in .m files
SetSavingOptionsPanelState('on',handles);

axes(handles.Window);
imagesc(Ima);                                                                                   % display the image

if get(handles.DISP_BORDERS_CB,'Value') == 1
    PlotBoundaries(getappdata(hGui, 'BColors'),getappdata(hGui, 'BThickness'));                 % Call to the PlotBoundaries function
end

if get(handles.DISP_CROP_WINDOWS_CB,'Value') == 1
    PlotCropWindows();
end

set(handles.MQC_PB,'Enable','on');                                                              % let the user the possibility to achieve a manual quality control

end

%% PlotBoundaries function: display on the image the several boundaries found
function PlotBoundaries(color,thickness)

hGui = getappdata(0, 'hGui');                                                                   % gets the application data set
Ima = getappdata(hGui, 'Ima');                                                                  % gets the image to display
NbrOfEffectiveCells = getappdata(hGui, 'NbrOfEffectiveCells');                                  % gets the number of borders to display
Boundaries = getappdata(hGui, 'Boundaries');                                                    % gets the boundaries to plot
Centroids = getappdata(hGui, 'Centroids');                                                      % gets the centroid of each boundary

imagesc(Ima);                                                                                   % display the total image
hold on;
for i=1:NbrOfEffectiveCells                                                                     % display each border
    b=Boundaries{i};
    plot(b(:,2),b(:,1),color,'Linewidth',thickness);                                             % plot the border with thickness 'thickness'
    text(Centroids(i,2),Centroids(i,1),['\color{yellow}',num2str(i)]);                           % display the label of the object next to the centroid
end
hold off;

end

%% PlotCropWindows function: display on the image the different ROIs
function PlotCropWindows()
hGui = getappdata(0,'hGui');
NbrOfEffectiveCells = getappdata(hGui,'NbrOfEffectiveCells');
TagTable = getappdata(hGui,'CropTag');
CropRect = getappdata(hGui,'CropRectangles');

hold on;
for i=1:NbrOfEffectiveCells                                                                 % and do this for every crop
    if TagTable{i}(3) == 1
        rectangle('Position',CropRect{i},'EdgeColor','red','LineWidth',1,'LineStyle','--');
    elseif TagTable{i}(2) == 1
        rectangle('Position',CropRect{i},'EdgeColor','blue','LineWidth',1,'LineStyle','--');
    elseif TagTable{i}(1) == 1
        rectangle('Position',CropRect{i},'EdgeColor','w','LineWidth',1,'LineStyle','--');
    end
end
hold off;

end

%% function that controls the edit box.... as we don't use it, no code is needed
function EDIT_BOX_TEST_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% function that controls the "Swap" button
function SWAP_PUSHBUTTON_Callback(hObject, eventdata, handles)

hGui = getappdata(0, 'hGui');                                                                   % gets the application data set
if getappdata(hGui,'IsImageLoaded') == false
    disp('You must open an image before trying to do anything');
    set(handles.EDIT_BOX_TEST,'string','No image loaded');
    return;
end
set(handles.EDIT_BOX_TEST, 'string', 'Swapping Red and green channels');                        % displays on screen what's happening
disp('Swapping Red & Green Channels');
Ima = getappdata(hGui,'Ima');                                                                   % gets the image
if get(handles.checkbox8)
    SwappedIma = SwapRG(Ima);                                                                       % as the reading of the file is "wrong", we have to swap the red and green channels
    Ima = SwappedIma;
end
setappdata(hGui, 'Ima', SwappedIma);                                                            % modifies the image in the application data
imagesc(SwappedIma);                                                                            % display the new image
PlotBoundaries(getappdata(hGui, 'BColors'),getappdata(hGui, 'BThickness'));                     % plot boundaries (if existing)
end

%% functions that controls the "Width" EditBox for the crops display
function WIDTH_EDITBOX_Callback(hObject, eventdata, handles)

% not used here
end

function WIDTH_EDITBOX_CreateFcn(hObject, eventdata, handles)

% not used either

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end

%% function that controls the "Height" EditBox for the crops display
function HEIGHT_EDITBOX_Callback(hObject, eventdata, handles)

%not used here
end

function HEIGHT_EDITBOX_CreateFcn(hObject, eventdata, handles)

% not used either

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end

%% function that controls the "Save" button
function SAVECROPS_PUSHBUTTON_Callback(hObject, eventdata, handles)

disp('Saving the crops');
set(handles.EDIT_BOX_TEST,'string','Saving the ROIs');
hGui = getappdata(0,'hGui');                                                                    % gets the application data set

CurrentDirectory = cd;                                                                          % gets the current folder we're working in

Directory = getappdata(hGui,'PathName');                                                        % gets the folder where the image is
cd(Directory);                                                                                  % go to this folder
FileName = getappdata(hGui,'FileName');                                                         % gets the name of the file we're analysing
pos = findstr('.',FileName)-1;                                                                  % find the '.' char in order to get what's before '.tif' = the real file name
FileName = FileName(1:pos);                                                                     % that's it... the file name without its extension

if get(handles.SAVE_ALL_CROPS_RB,'Value') == 1
    DestinationFolderForCropWithSeveralCells = 'cropped_matlab_SC';
    DestinationFolderForCropWithBorderCells = 'cropped_matlab_BC';
    mkdir(DestinationFolderForCropWithSeveralCells);
    mkdir(DestinationFolderForCropWithBorderCells);
end

DestinationFolderForCorrectCrops = 'cropped_matlab';
mkdir(DestinationFolderForCorrectCrops);

for  i=1:getappdata(hGui,'NbrOfEffectiveCells')                                                 % prepares the saving operation giving names to each crop
    for time_index=1:getappdata(hGui,'NTimes')
        outputfilename{i,time_index} = [FileName,'_cr',int2str2(i,3),'_t',int2str2(time_index,4)];
    end
end

%gets every parameter we have to save from the application data set
Ntimes = getappdata(hGui,'NTimes');
I3d = getappdata(hGui,'I3d');
crop_rectangle = getappdata(hGui,'CropRectangles');
dx = getappdata(hGui,'dx');
dy = getappdata(hGui,'dy');
dz = getappdata(hGui,'dz');
n = getappdata(hGui,'n');
NA = getappdata(hGui,'NA');
lambda = getappdata(hGui,'lambda');
Iinfo = getappdata(hGui,'Iinfo');
Nchannels = getappdata(hGui,'Nchannels');
input_parameters = getappdata(hGui,'input_parameters');
Ncrops = getappdata(hGui,'NbrOfEffectiveCells');
TagTable = getappdata(hGui,'CropTag');

set(handles.EDIT_BOX_TEST,'string','Saving ROIs');
hwb = waitbar(0,['Cropping and saving ',num2str(Ncrops),' regions...']);                        % create a waitbar to show where the saving operation is
for  icrop=1:getappdata(hGui,'NbrOfEffectiveCells')                                             % for each object
    Icrop = imcrop3d(I3d,crop_rectangle{icrop});                                                % defines an object representing the crop (image+rectangle)
    [Nx Ny Nz aux] = size(Icrop);                                                               % gets the dimensions of this object
    xx = 0:dx:(Nx-1)*dx;
    yy = 0:dy:(Ny-1)*dy;
    zz = 0:dz:(Nz-1)*dz;

    if get(handles.SAVE_ALL_CROPS_RB,'Value') == 1
        if TagTable{icrop}(3) == 1
            DestFolder = DestinationFolderForCropWithSeveralCells;
        elseif TagTable{icrop}(2) == 1
            DestFolder = DestinationFolderForCropWithBorderCells;
        elseif TagTable{icrop}(1) == 1
            DestFolder = DestinationFolderForCorrectCrops;
        else
            disp('Problem with the destination folder');
            set(handles.EDIT_BOX_TEST,'string','Problem with the destination folder');
            return;
        end

        cd(strcat('./',DestFolder));


        % operates the actual saving
        disp(['saving cropped image and acquisition parameters as matlab file ',outputfilename{icrop,1},'...']);
        save(outputfilename{icrop,1},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes','Iinfo','input_parameters');

        % modifies the waitbar
        wbcrop = waitbar(icrop/Ncrops,hwb,['Cropping and saving region ',num2str(icrop),'/',num2str(Ncrops),'...']);
        clear Icrop;
        cd('..');
    elseif get(handles.SAVE_CORRECT_CROPS_RB,'Value') == 1
        if TagTable{icrop}(1) == 1
            DestFolder = DestinationFolderForCorrectCrops;
            cd(strcat('./',DestFolder));
            % operates the actual saving
            disp(['saving cropped image and acquisition parameters as matlab file ',outputfilename{icrop,1},'...']);
            save(outputfilename{icrop,1},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes','Iinfo','input_parameters');

            % modifies the waitbar
            wbcrop = waitbar(icrop/Ncrops,hwb,['Cropping and saving region ',num2str(icrop),'/',num2str(Ncrops),'...']);
            clear Icrop;
            cd('..');
        end
    end
end

delete(wbcrop);                                                                                 % deletes the waitbar
WhereAreWe = cd;                                                                                % locates where we are
text = strcat('ROIs saved in:',WhereAreWe);                                                   % make a nice text to display
set(handles.EDIT_BOX_TEST,'string',text);                                                       % and display it to the edit text

cd(CurrentDirectory);                                                                           % go back to the root folder

end

%% function that controls the Andor data source button
function DATASOURCE_ANDOR_CB_Callback(hObject, eventdata, handles)

% fills the Andor default microsettings
set(hObject,'Value',1);
set(handles.DATASOURCE_PE_CB,'Value',0);
set(handles.RINDEX_EDITBOX,'string','1.33');                                            % Microsettings for the Andor data source
set(handles.NA_EDITBOX,'string','1.4');
set(handles.EW_EDITBOX,'string','0.5');
set(handles.VDX_EDITBOX,'string','0.0773');
set(handles.VDY_EDITBOX,'string','0.0773');
set(handles.VDZ_EDITBOX,'string','0.25');

end

%% function that controls the Perkin Elmer source button
function DATASOURCE_PE_CB_Callback(hObject, eventdata, handles)

%fills the Perkin-Elmer default microsettings
set(hObject,'Value',1);
set(handles.DATASOURCE_ANDOR_CB,'Value',0);
set(handles.RINDEX_EDITBOX,'string','1.33');                                            % Microsettings for the Perkin Elmer data source
set(handles.NA_EDITBOX,'string','1.4');
set(handles.EW_EDITBOX,'string','0.5');
set(handles.VDX_EDITBOX,'string','0.0645');
set(handles.VDY_EDITBOX,'string','0.0645');
set(handles.VDZ_EDITBOX,'string','0.25');

end

%% function that controls the different microsettings edit boxes.... no action needed

function RINDEX_EDITBOX_Callback(hObject, eventdata, handles)                                   % Refractive index of the sample medium
end

function RINDEX_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function NA_EDITBOX_Callback(hObject, eventdata, handles)                                       % Numerical Aperture of the obejctive lens
end

function NA_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function EW_EDITBOX_Callback(hObject, eventdata, handles)                                       % Emission Wavelength
end

function EW_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function VDX_EDITBOX_Callback(hObject, eventdata, handles)                                      % Vortex Dimension along X axis
end

function VDX_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function VDY_EDITBOX_Callback(hObject, eventdata, handles)                                      % VOrtex Dimension along Y axis
end

function VDY_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function VDZ_EDITBOX_Callback(hObject, eventdata, handles)                                      % Vortex Dimension along Z axis
end

function VDZ_EDITBOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% functions that controls the number of channels selected by buttons
function RCHANNEL_PB_Callback(hObject, eventdata, handles)

set(handles.RCHANNEL_PB,'Value',0);                                                             % sets the number of channels to 1 (only red channel)
set(handles.RVCHANNEL_PB,'Value',1);
set(handles.RVBCHANNEL_PB,'Value',1);
end

function RVCHANNEL_PB_Callback(hObject, eventdata, handles)                                     % sets the number of channels to 2 (red and green channels)
set(handles.RCHANNEL_PB,'Value',1);
set(handles.RVCHANNEL_PB,'Value',0);
set(handles.RVBCHANNEL_PB,'Value',1);
end

function RVBCHANNEL_PB_Callback(hObject, eventdata, handles)                                    % sets the number of channels to 3 (RVB image)
set(handles.RCHANNEL_PB,'Value',1);
set(handles.RVCHANNEL_PB,'Value',1);
set(handles.RVBCHANNEL_PB,'Value',0);
end

%% function that controls the main window in case that the user clicks on it (mainly to avoid the destruction of data sets or bugs)
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
disp('do not try to click anywhere, it will not do anything ;)');

%% function that allow the user to access the buttons of the "find nuclei" panel
end

function SetFindNucleiPanelState(state,handles)

% According to the state parameter (on or off), the user will be able to
% access the panel objects.... or not
set(handles.GREENCHANNEL_CB,'Enable',state);                                                    % sets state for the "Green channel" check box
set(handles.REDCHANNEL_CB,'Enable',state);                                                      % sets state for the "Red channel" check box
set(handles.DISP_BORDERS_CB,'Enable',state);                                                    % sets state for the "Display borders and label" check box
set(handles.Boundary_PUSHBUTTON,'Enable',state);                                                % sets state for the "Find nuclei" button
% sets state for the Find Nuclei Properties Static Text (FNP_STi)
set(handles.FNP_ST1,'Enable',state');

%% function that allow the user to access the buttons of the "Display Crops" panel
end

function SetDisplayCropsPanelState(state, handles)

% According to the state parameter (on or off), the user will be able to
% access the panel objects.... or not
set(handles.DISP_CROP_WINDOWS_CB,'Enable',state);
set(handles.WIDTH_EDITBOX,'Enable',state);                                                      % sets state for the "Width" edit box
set(handles.HEIGHT_EDITBOX,'Enable',state);                                                     % sets state for the "Height" edit box
set(handles.AUTODISP_RB,'Enable',state);                                                        % sets state for the "Automatic display" radio button
set(handles.CUSTOMDISP_RB,'Enable',state);                                                      % sets state for the "Custom display" radio button
set(handles.LEGEND1,'Enable',state);
set(handles.LEGEND2,'Enable',state);
set(handles.LEGEND3,'Enable',state);
set(handles.LEGEND4,'Enable',state);
if strcmp(state,'off')                                                                          % if state is off, don't give access to anything.... easy
    set(handles.DCP_ST1,'Enable',state);
    set(handles.DCP_ST2,'Enable',state);
elseif strcmp(state,'on')
    if get(handles.AUTODISP_RB,'Value') == 1                                                    % if state is on, but the format is automatically set, then don't give access to the parameters
        set(handles.DCP_ST1,'Enable','off');                                                    % set or let the static texts to "disable"
        set(handles.DCP_ST2,'Enable','off');
        set(handles.WIDTH_EDITBOX,'Enable','off');                                              % set or let the edit boxes to "disable"
        set(handles.HEIGHT_EDITBOX,'Enable','off');
    elseif get(handles.CUSTOMDISP_RB,'Value') == 1                                              % if state is on and if the user wants to modify the display parameters
        set(handles.DCP_ST1,'Enable','on');                                                     % activate the static texts
        set(handles.DCP_ST2,'Enable','on');
        set(handles.WIDTH_EDITBOX,'Enable','on');                                               % and activate the edit boxes
        set(handles.HEIGHT_EDITBOX,'Enable','on');
    end
else
    disp('There is a problem in the set panel state function.... that si too bad :(');          % say where is the problem if there is one... but as the programer is good, there shouldn't be any problem :p
end
end

%% function that allow the user to access the buttons of the "Saving options" panel

function SetSavingOptionsPanelState(state,handles)

set(handles.SAVE_CORRECT_CROPS_RB,'Enable',state);
set(handles.SAVE_ALL_CROPS_RB,'Enable',state);
end

%% these are the functions controlling the green and red channel... not used, so no code
function GREENCHANNEL_CB_Callback(hObject, eventdata, handles)
end

function REDCHANNEL_CB_Callback(hObject, eventdata, handles)
end

%% functions that controls the automatic or custom display properties (contrilling exclusive elimination)
function AUTODISP_RB_Callback(hObject, eventdata, handles)
set(hObject,'Value',1);                                                                         % if the user pushes on this button, then push the button
set(handles.CUSTOMDISP_RB,'Value',0);                                                           % and get the other get up
SetDisplayCropsPanelState('on',handles);                                                        % don't forget to update the global view
end

function CUSTOMDISP_RB_Callback(hObject, eventdata, handles)
set(hObject,'Value',1);                                                                         % if the user pushes on this button, then push the button
set(handles.AUTODISP_RB,'Value',0);                                                             % and get the other get up
SetDisplayCropsPanelState('on',handles);                                                        % don't forget to update the global view
end

%% functions that controls the saving radio buttons (save every ROI or only correct ones)
function SAVE_CORRECT_CROPS_RB_Callback(hObject, eventdata, handles)
set(hObject,'Value',1);
set(handles.SAVE_ALL_CROPS_RB,'Value',0);
end

function SAVE_ALL_CROPS_RB_Callback(hObject, eventdata, handles)
set(hObject,'Value',1);
set(handles.SAVE_CORRECT_CROPS_RB,'Value',0);
end


%% function that allow the user to open a complete folder in order to analyse multiple images at once
function OPENFOLDER_PUSHBUTTON_Callback(hObject, eventdata, handles)

set(handles.PROMPT_MI_ST,'Visible','on');

CurrentDir = cd;                                                                                % stocks the current directory we're working in
DirName = uigetdir('','Open workspace directory');                                                                             % asks the user for a directory where images are
[NbrOfFoldersToAnalyse,ListOfFoldersToAnalyse,NbrOfImages] = PathAnalyser(DirName);
FileCounter = 1;

for l=1:NbrOfFoldersToAnalyse-1
    cd(ListOfFoldersToAnalyse{l});
    TempNbrOfObjects = size(ls);                                                                % counts the objects found in the directory
    NbrOfObjects = TempNbrOfObjects(1);
    FileNameTemp = dir;                                                                         % gets all the objects (files and folders)
    FileName = {};
    counter = 0;
    for i=1:NbrOfObjects                                                                        % for each object, determine what is what (file or directory... or other)
        pos = findstr('.tif',FileNameTemp(i).name)-1;                                           % to do so, find the '.tif' string...
        if isempty(FileNameTemp(i).name(1:pos)) ~= 1                                            % If you don't find it, so it's not a file
            counter = counter + 1;
            FileName{counter} = FileNameTemp(i).name;                                           % else, add the name of the file to the list of files to analyse
        end
    end

    NbrOfFilesTemp = size(FileName);                                                            % gets the total number of images to analyse
    NbrOfFiles = NbrOfFilesTemp(2);

    disp(strcat(num2str(NbrOfFiles),' files to analyse'));                                      % display in the console how many files we're going to analyse

    if get(handles.SAVE_ALL_CROPS_RB,'Value') == 1                                              % if we have to save not only correct crops
        mkdir('cropped_matlab_SC');                                                             % creates a folder to put crops with Several Cells (SC)
        mkdir('cropped_matlab_BC');                                                             % and one for crops with cells on the border of the image (BC)
    end
    mkdir('cropped_matlab');

    cd(CurrentDir);                                                                             % now go back to the directory where the matlab code is (elsewhere, this stupid program won't know where to find the code)

    for i=1:NbrOfFiles                                                                          % for each file, make a complete analysis (opening, finding borders, cropping and saving)
        set(handles.PROMPT_MI_ST,'string',['>>   Analysis of file: ',FileName{i},' (Image ',num2str(FileCounter),'/',num2str(NbrOfImages),')']);
        FileCounter = FileCounter + 1;
        AnalyseMultipleImages(FileName{i},CurrentDir,ListOfFoldersToAnalyse{l},handles);        % see the AnalyseMultipleImages for more details
    end
end

disp('Analysis is over... ');                                                                   % that's all folks :)
set(handles.PROMPT_MI_ST,'Visible','off');
set(handles.EDIT_BOX_TEST,'string','Analysis is over....');
end

%% function that open, analyse and save the crops all at once
% for more details, just see the different functions written just over this
% one... It's just a mix of all of them (copy + paste power .lml)
function AnalyseMultipleImages(FileName, Directory, DestinationFolderForCrops, handles)

set(handles.EDIT_BOX_TEST,'string','Opening the image...');

clearappdata();                                                                                 % call of a function that destroys the application data

setappdata(0, 'hGui', gcf);                                                                     % defines a context for application data
hGui = getappdata(0, 'hGui');                                                                   % handle to the application data
setappdata(hGui,'IsImageLoaded',false);                                                         % flag that prove that the image is loaded (or not)

if isappdata(hGui,'tabGUIFlag')                                                                 % checks if a previous analyse has been done and close the tab GUI if necessary
    if getappdata(hGui,'tabGUIFlag') == true
        close(handles.handleTabGUI);
        setappdata(hGui,'tabGUIFlag',false);
    end
end

%Gets the file to source parameters...

if strcmp(get(handles.DATASOURCE_ANDOR_CB,'string'),'Andor')                                    % gets the data source
    input_parameters.data_format = 'Andor';
else
    input_parameters.data_format = 'Perkin-Elmer';
end

% gets the microparameters
n = str2num(get(handles.RINDEX_EDITBOX, 'string'));                                             % refractive index n of the sample medium
NA = str2num(get(handles.NA_EDITBOX,'string'));                                                 % numerical aperture for the objective lense
lambda = str2num(get(handles.EW_EDITBOX,'string'));                                             % emission wavelength
dx = str2num(get(handles.VDX_EDITBOX,'string'));                                                % voxel dimension along X axis
dy = str2num(get(handles.VDY_EDITBOX,'string'));                                                % voxel dimension along Y axis
dz = str2num(get(handles.VDZ_EDITBOX,'string'));                                                % voxel dimension along Z axis

setappdata(hGui,'outputformat','matlab');                                                       % output format for the cropped regions

%Creates several application data such as the effective RGB image
switch input_parameters.data_format
    case 'Perkin-Elmer'                                                                         % Import from Perkin-Elmer data
        %         DestinationFolderForCrops = uigetdir(dir0,'Select folder containing the Perkin-Elmer data');            % gets the folder where the image is stocked
        if DestinationFolderForCrops == 0                                                                       % if no file have been selected, don't continue
            disp('No file to analyse...');
            return;
        end
        disp('importing data...');                                                              % command display of what is happening
        set(handles.EDIT_BOX_TEST,'string','importing data...');                                % graphical display of what is happening
        [Nchannels,width,height,Nz,Ntimes,lambdas,imagenamestem] = importPEinfo(DestinationFolderForCrops);     % see the importePEinfo function for more details
        I3d = importPEdata(DestinationFolderForCrops,imagenamestem,Nchannels,width,height,Nz,Ntimes,1);         % see the importe PEdata function for more details
        Iinfo = [];
    case 'Andor'                                                                                % Import from tif files
        %         [FileToAnalyse,Directory] = uigetfile('*.tif','Select the single tif image file');    % opens a dialog box asking for the path of the file to open
        FileToAnalyse = FileName;
        if FileToAnalyse == 0                                                                   % if no file have been selected, don't continue
            disp('No file to analyse...');
            return;
        end
        setappdata(hGui,'FileName',FileToAnalyse);                                              % File name added to application data
        FileToAnalyse = strcat(DestinationFolderForCrops,'\',FileToAnalyse);                                    % Path of the file to analyse
        if get(handles.RCHANNEL_PB,'Value') == 0                                                % gettings the number of color channels
            Nchannels = 1;
        elseif get(handles.RVCHANNEL_PB,'Value') == 0
            Nchannels = 2;
        else
            Nchannels = 3;
        end
        Nchannels
        [I3d, Iinfo] = importtif(FileToAnalyse,Nchannels);                                      % see the importtiff function for more details
        [aux,imagenamestem,aux2] = fileparts(FileToAnalyse);
        Nz = size(I3d,3);
        Ntimes = 1;
    otherwise
        error('unacceptable data format !');
end

% Adds the different parameters to the appliction data...
setappdata(hGui,'NTimes', Ntimes);
setappdata(hGui,'PathName',DestinationFolderForCrops);
setappdata(hGui,'I3d',I3d);
setappdata(hGui,'dx',dx);
setappdata(hGui,'dy',dy);
setappdata(hGui,'dz',dz);
setappdata(hGui,'n',n);
setappdata(hGui,'NA',NA);
setappdata(hGui,'lambda',lambda);
setappdata(hGui,'Iinfo',Iinfo);
setappdata(hGui,'Nchannels',Nchannels);
setappdata(hGui,'input_parameters',input_parameters);

%Prepares the image to be dispalyed
hwb = waitbar(0,'Computing max. int. proj. ...'); drawnow;                                      % waitbar
Nz
FileName
if Nz>1
    aux = squeeze(max(I3d,[],3));                                                               % building of the RGB image according to the number of channels
    if ndims(aux)==2 % if there is only a single channel, assign it to the green channel
        aux1(:,:,2) = aux;
        aux1(:,:,1) = zeros(size(aux));
        aux1(:,:,3) = zeros(size(aux));
        aux = aux1;
    end
    if size(aux,3) == 2
        set(handles.EDIT_BOX_TEST,'string','Padding third dimension of image with zeros..');    % graphical display of what is happening
        disp('Padding third dimension of image with zeros..');                                  % console display of what is happening
        aux(:,:,3) = zeros(size(aux(:,:,1)));
    end
    Ima = imadjust(aux,stretchlim(aux,[0.01 0.999]),[]);                                        % adjusts the image
    clear aux*;
else
    %size(I3d)
    Ima = imadjust(I3d,stretchlim(I3d,[0.01 0.999]),[]);
end
delete(hwb);                                                                                    % delete the waitbar
if get(handles.checkbox8,'Value')
    Ima = SwapRG(Ima);                                                                       % as the reading of the file is "wrong", we have to swap the red and green channels
end
setappdata(hGui, 'Ima', Ima);                                                                   % adds the image to the application data
setappdata(hGui,'IsImageLoaded',true);                                                          % image loaded with success
imagesc(Ima);                                                                                   % display the RGB image

width = size(Ima,1);                                                                            % width of the image
height = size(Ima,2);                                                                           % height of the image
if get(handles.GREENCHANNEL_CB,'Value') == 1 && get(handles.REDCHANNEL_CB,'Value') == 0         % gets the channel we're going to use to achieve the detection
    ColorChannel = 'green';
elseif get(handles.GREENCHANNEL_CB,'Value') == 0 && get(handles.REDCHANNEL_CB,'Value') == 1
    ColorChannel = 'red';
elseif get(handles.GREENCHANNEL_CB,'Value') == 1 && get(handles.REDCHANNEL_CB,'Value') == 1
    ColorChannel = 'both';
else
    disp('You must chose a color channel to achieve the analysis');                             % if there is a problem, juste stop the program and says what's happening
    return;
end

set(handles.EDIT_BOX_TEST,'string','Finding cells borders...');
[NbrOfEffectiveCells, Boundaries, Centroids] = FindBoundaries(Ima,40,ColorChannel,true);        % See the FindBoundaries function for more details

set(handles.EDIT_BOX_TEST,'string','Splitting the image in several crops...');
OffsetDist = getappdata(hGui,'OffsetDistance');
[Mosaic_Of_Crops, CentroidsOfCrop, BoundariesOfCrop, CropRect] = Split_Image(NbrOfEffectiveCells, Boundaries, Centroids,Ima,OffsetDist);     % Automatic split of the image in small crops    .... see the "Split_Image" function for more details

set(handles.EDIT_BOX_TEST,'string','Adjusting Crop Windows...');
hwb = waitbar(0,'Adjusting Crop Windows...');                                                   % waitbar
counter = 0;
for i=1:NbrOfEffectiveCells
    disp(strcat('Analysing cell n_',num2str(i)));
    AdjustWB = waitbar(i/NbrOfEffectiveCells,hwb,['Adjusting crop window n� ',num2str(i),'/',num2str(NbrOfEffectiveCells),'...']);
    [NewCropIma,NewRect,NewBoundaries,NewCentroid,MultipleCellInFinalCrop,Tag] = AdjustCrop(Mosaic_Of_Crops{i},CropRect{i},BoundariesOfCrop{i},CentroidsOfCrop(i,:),4,ColorChannel,OffsetDist,Ima);
    CropRect{i} = NewRect;
    Mosaic_Of_Crops{i} = NewCropIma;
    BoundariesOfCrop{i} = NewBoundaries;
    CentroidsOfCrop(i,:) = NewCentroid;
    if MultipleCellInFinalCrop == true
        counter = counter + 1;
    end
    TagTable{i} = Tag;
end
disp(strcat(num2str(counter),' crops with more than one cell'));
delete(AdjustWB);

% Adds the different objects to the application data
setappdata(hGui,'NbrOfEffectiveCells', NbrOfEffectiveCells);                                    % adds the number of effective cells detected in the image
setappdata(hGui,'Boundaries', Boundaries);                                                      % adds the cell borders to the application data
setappdata(hGui,'Centroids', Centroids);                                                        % adds the centroids to the application data set
setappdata(hGui,'Mosaic_Of_Crops',Mosaic_Of_Crops);                                             % adds the several crops to the application data
setappdata(hGui,'CentroidsOfCrop',CentroidsOfCrop);                                             % adds the centroid of each object in each crop (avoid the calculation of the centroid coordiantes in the crop)
setappdata(hGui,'BoundariesOfCrop',BoundariesOfCrop);                                           % adds the boudaries of each object in each crop to the application data
setappdata(hGui,'CropRectangles', CropRect);                                                    % adds the rectangle defining each crop
setappdata(hGui,'CropTag',TagTable);

setappdata(hGui, 'BThickness', 1);                                                              % defines the borders thickness to 1 pixel
setappdata(hGui, 'BColors', 'white');                                                           % defines the borders color to white

str = strcat('Number of effective cells: ',num2str(NbrOfEffectiveCells));                       % Number of effective objects found in the image
set(handles.EDIT_BOX_TEST,'string',str);                                                        % graphical display of what is happening

if get(handles.DISP_BORDERS_CB,'Value') == 1
    PlotBoundaries(getappdata(hGui, 'BColors'),getappdata(hGui, 'BThickness'));                 % Call to the PlotBoundaries function
end

if get(handles.DISP_CROP_WINDOWS_CB,'Value') == 1
    PlotCropWindows();
end

CurrentDirectory = cd;                                                                          % gets the current folder we're working in

cd(Directory);                                                                                  % go to this folder
cd(DestinationFolderForCrops);                                                                  % and go to this new folder

ls


for  i=1:getappdata(hGui,'NbrOfEffectiveCells')                                                 % prepares the saving operation giving names to each crop
    for time_index=1:getappdata(hGui,'NTimes')
        pos = findstr('.tif',FileName)-1;
        outputfilename{i,time_index} = [FileName(1:pos),'_cr',int2str2(i,3),'_t',int2str2(time_index,4),'.mat'];
    end
end

%gets every parameter we have to save from the application data set
Ntimes = getappdata(hGui,'NTimes');
I3d = getappdata(hGui,'I3d');
crop_rectangle = getappdata(hGui,'CropRectangles');
dx = getappdata(hGui,'dx');
dy = getappdata(hGui,'dy');
dz = getappdata(hGui,'dz');
n = getappdata(hGui,'n');
NA = getappdata(hGui,'NA');
lambda = getappdata(hGui,'lambda');
Iinfo = getappdata(hGui,'Iinfo');
Nchannels = getappdata(hGui,'Nchannels');
input_parameters = getappdata(hGui,'input_parameters');
Ncrops = getappdata(hGui,'NbrOfEffectiveCells');

set(handles.EDIT_BOX_TEST,'string','Saving ROIs');
hwb = waitbar(0,['Cropping and saving ',num2str(Ncrops),' regions...']);                        % create a waitbar to show where the saving operation is
for  icrop=1:getappdata(hGui,'NbrOfEffectiveCells')                                             % for each object
    Icrop = imcrop3d(I3d,crop_rectangle{icrop});                                                % defines an object representing the crop (image+rectangle)
    [Nx Ny Nz aux] = size(Icrop);                                                               % gets the dimensions of this object
    xx = 0:dx:(Nx-1)*dx;
    yy = 0:dy:(Ny-1)*dy;
    zz = 0:dz:(Nz-1)*dz;

    if get(handles.SAVE_ALL_CROPS_RB,'Value') == 1
        if TagTable{icrop}(3) == 1
            DestinationFolderForCrops = 'cropped_matlab_SC';
        elseif TagTable{icrop}(2) == 1
            DestinationFolderForCrops = 'cropped_matlab_BC';
        elseif TagTable{icrop}(1) == 1
            DestinationFolderForCrops = 'cropped_matlab';
        else
            disp('Problem with the destination folder for crops');
            return;
        end

        cd(DestinationFolderForCrops);

        % operates the actual saving
        save(outputfilename{icrop,1},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes','Iinfo','input_parameters');

        % modifies the waitbar
        waitbar(icrop/Ncrops,['Cropping and saving region ',num2str(icrop),'/',num2str(Ncrops),'...']);
        clear Icrop;

        cd('..');
    elseif get(handles.SAVE_CORRECT_CROPS_RB,'Value') == 1
        if TagTable{icrop}(1) == 1
            DestFolder = 'cropped_matlab';
            cd(strcat('./',DestFolder));
            % operates the actual saving
            disp(['saving cropped image and acquisition parameters as matlab file ',outputfilename{icrop,1},'...']);
            save(outputfilename{icrop,1},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes','Iinfo','input_parameters');

            % modifies the waitbar
            waitbar(icrop/Ncrops,['Cropping and saving region ',num2str(icrop),'/',num2str(Ncrops),'...']);
            clear Icrop;
            cd('..');
        end
    end
end
%delete(wbcrop);                                                                                 % deletes the waitbar
WhereAreWe = cd;                                                                                % locates where we are
text = strcat('ROIs saved in:',WhereAreWe);                                                     % make a nice text to display
set(handles.EDIT_BOX_TEST,'string',text);                                                       % and display it to the edit text

cd(CurrentDirectory);                                                                           % go back to the root folder
end


%% function called when the program is forced to close
function figure1_CloseRequestFcn(hObject, eventdata, handles)

disp('============================================================================');
disp('closing the window.....');
disp('============================================================================');
hGui = getappdata(0,'hGui');
if isappdata(hGui,'tabGUIFlag')                                                                 % checks if a previous analyse has been done and close the tab GUI if necessary
    if getappdata(hGui,'tabGUIFlag') == true
        close(handles.handleTabGUI);
        setappdata(hGui,'tabGUIFlag',false);
    end
end

if isappdata(hGui,'MQCFlag')
    if getappdata(hGui,'MQCFlag') == true
        close(handles.MQC);
        setappdata(hGui,'MQCFlag',false);
    end
end

if isappdata(hGui,'ASFlag')
    if getappdata(hGui,'ASFlag') == true
        close(handles.AS);
        setappdata(hGui,'ASFlag',false);
    end
end

clearappdata();                                                                                 % kills everything that have been created to free the memory
set(0,'DefaultTextInterpreter','none');                                                         % sets the text interpreter to none

delete(hObject);                                                                                % kills the main GUI window

end

%% function that controls the "Display cell borders & label" check box
function DISP_BORDERS_CB_Callback(hObject, eventdata, handles)

hGui = getappdata(0,'hGui');                                                                    % firstly, get the application data set

if isappdata(hGui,'Boundaries')                                                                 % then check if an analysis has been done. If no borders have been found yet, no need to do anything
    if get(hObject,'Value') == 1                                                                % if we have to draw the borders and labels (check box checked)
        PlotBoundaries(getappdata(hGui,'BColors'),getappdata(hGui,'BThickness'));               % then just draw them with the PlotBoundaries function
    else                                                                                        % else
        Ima = getappdata(hGui,'Ima');                                                           % get the image
        imagesc(Ima);                                                                           % and plot it on screen
    end

    if get(handles.DISP_CROP_WINDOWS_CB,'Value') == 1                                           % check if we have to plot the ROIs too
        PlotCropWindows();                                                                      % if so, then draw them thanks to the PlotCropWindows function
    end
end

end

%% function that controls the "Display ROIs on image" check box
function DISP_CROP_WINDOWS_CB_Callback(hObject, eventdata, handles)

hGui = getappdata(0,'hGui');                                                                    % Begin by getting the application data set

if isappdata(hGui,'Boundaries')                                                                 % then check if an analysis has been done. If no borders have been detected yet, no need to do anything
    if get(handles.DISP_BORDERS_CB,'Value') == 1                                                % if we have to plot the boundaries and labels
        PlotBoundaries(getappdata(hGui,'BColors'),getappdata(hGui,'BThickness'));               % just plot the boundaries and labels
    else                                                                                        % otherwise, display the image on screen
        imagesc(getappdata(hGui,'Ima'));
    end

    if get(hObject,'Value') == 1                                                                % if we have to plot the ROIs on the image
        PlotCropWindows();                                                                      % then do it thanks to the PlotCropWindows function
    end
end

end

%% function that call the MQC dialog box
function MQC_PB_Callback(hObject, eventdata, handles)

disp('Beginning of Manual Quality Control');                                                    % Begin by telling the user what's happening

figure(handles.handleTabGUI);                                                                   % As the manual quality controls is done with the tabs figure, set the tab figure on top of all other windows

hGui = getappdata(0,'hGui');                                                                    % Now let's get the application data
MQC = MQC_IHM;                                                                                  % This is a call the the Manual Quality Control dialog box
handles.MQC = MQC;                                                                              % We build a handle to the dialog box
guidata(hObject, handles);                                                                      % And refresh the handles
MQCFlag = true;                                                                                 % We also add a flag to the application data, in case the user close the main window wihtout closing the MQC DiBox before
setappdata(hGui,'MQCFlag',MQCFlag);
end

% --- Executes on button press in ADV_PROP_PB.
function ADV_PROP_PB_Callback(hObject, eventdata, handles)

hGui = getappdata(0,'hGui');
AS = Advanced_props;
handles.AS = AS;
guidata(hObject, handles);
ASFlag = true;
setappdata(hGui,'ASFlag',ASFlag);
end



% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8


end