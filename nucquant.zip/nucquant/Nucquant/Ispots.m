%% Create image of a set of point sources
% this function returns a 3D image the same size as I that is
% the image of the point sources with coordinates (xp,yp,zp) and amplitudes
% Ap
% taking into account the PSF, modelled as a double-gaussian with
% parameters sigma_x2 and sigma2_z
% (xx,yy,zz) define the coordinates of the pixel centers

function Ires = Ispots(I,xx,yy,zz,xp,yp,zp,Ap,sigma_z,sigma2_xy,sigma2_z)

N_diracs=length(xp);
Ires = zeros(size(I));
Nx = size(I,1);
Ny = size(I,2);
Nz = size(I,3);



if 1==0
    xxx = repmat(xx(:),1,Ny);
    yyy = repmat(yy(:)',Nx,1);
    for k=1:Nz
        for ip = 1:N_diracs
            %         disp(['k=',num2str(k),', ip =',num2str(ip)]);
            Ires(:,:,k) = Ires(:,:,k) + Ap(ip)*gaussian_psf_thomann(xxx-xp(ip),yyy-yp(ip),zz(k)-zp(ip),sigma2_xy,sigma2_z);
        end
    end
else
    [xxx,yyy,zzz] = ndgrid(xx,yy,zz);
    for ip =1:N_diracs
%         Ires =Ires +       Ap(ip)*gaussian_psf_thomann(xxx-xp(ip),yyy-yp(ip),zzz-zp(ip),sigma2_xy,sigma2_z);
                Ires =Ires + Ap(ip) * bi_gaussian_psf(xxx-xp(ip),yyy-yp(ip),zzz-zp(ip),sigma_z,sigma2_xy,sigma2_z);
    end
end

if 1==0 % normalize the intensity !!
    aux = max(Ires(:));
    Ires = Ires/aux*max(Ap);
end


end