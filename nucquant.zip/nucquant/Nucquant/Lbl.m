function Lbl(a,b,n)

MM=b;%max(C2(:));
mm=a;%min(C2(:));
h = colorbar; 
%%colormap(jet(n));% Make colorbar and save handle.
set(h,'Ylim',[mm MM]);
hh=mm+((MM-mm)/(2*n)):(MM-mm)/n:MM-((MM-mm)/(2*n));%mm:(MM-mm)/9:MM;
set(h, 'Ytick',hh,'YTickLabelMode','manual','YtickMode','manual','FontWeight','bold','YColor','k'); % Assign positions of ticks mm+((MM-mm)/(2*10)):(MM-mm)/10:MM-((MM-mm)/(2*10))

switch n
   case {9}
      labels = {'90%';'80%';'70%';'60%';'50%';'40%';'30%';'20%';'10%'};
   case {5}
      labels = {'100%';'80%';'60%';'40%';'20%'};
   case {4}
      labels = {'100%';'75%';'50%';'25%'};
   case {2}
      labels = {'100%';'50%'};
   otherwise
      disp('Unknown method.')
end
set(h, 'YtickLabel', labels);%,'YtickMode','manual','YTickLabelMode','manual') % Assign tick labels.
