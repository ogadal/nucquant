function varargout = MQC_IHM(varargin)


%% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MQC_IHM_OpeningFcn, ...
                   'gui_OutputFcn',  @MQC_IHM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% function that initialize several things in the dialog box
function MQC_IHM_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;

hGui = getappdata(0,'hGui');                                                            % first we begin by getting the application data from the main gui
NbrOfCells = getappdata(hGui,'NbrOfEffectiveCells');                                    % and particularly the number of cells detected
Tags = getappdata(hGui,'CropTag');                                                      % we also need the tags for each crop in order to know wether it's a correct crop or not

counterCOB = 0;                                                                         % as we don't stock the number of crops with Cells On Border, e have to count them
counterMCROI = 0;                                                                       % same thing for the Multi-Cells ROIs

for i=1:NbrOfCells                                                                      % here is the loop that analyse each tag and counts the number of crops with cells on border or multi-cells ROIs
    if Tags{i}(3) == 1
        counterMCROI = counterMCROI + 1;
    elseif Tags{i}(2) == 1
        counterCOB = counterCOB + 1;
    end
end

set(handles.NBR_OF_CELLS_ST,'string',num2str(NbrOfCells));                              % here is the number of cells found
set(handles.MISSED_CELLS_EB,'string','0');                                              % here is the number of cells not found
set(handles.CELLS_ON_BORDER_ST,'string',num2str(counterCOB));                           % here is the number of cells on the border of the image
set(handles.MCROIS_ST,'string',num2str(counterMCROI));                                  % here is the number of crops with more than one cell
set(handles.UNCORRECT_CROPS_ST,'string','0');                                           % here is the number of uncorrect crops hidden in the correct crops
set(handles.ROI_CID_LABEL_EB,'string','1');                                             % here is the label of the uncorrect crop
figure(hObject);                                                                        % set the MQC figure as the current figure
set(gcf,'name','Manual Quality Control');                                               % here is the name of the dialog box

set(handles.text3,'string','Cells on border:');                                         % all these strings need to be set this way in order to be written in an excel file
set(handles.text4,'string','ROIs with more than 1 cell:');
set(handles.text5,'string','False positives:');
set(handles.text6,'string','Label of ROI with cell in division:');
set(handles.text7,'string','Label of ROI with no nucleus:');
set(handles.text8,'string','Other false positives (dead cells, no nucleolus, 0 gene, more than one...):');
set(handles.text9,'string','Label of ROI with more than one cell:');

setappdata(0,'MQCgui',gcf);                                                             % here is a data set
MQCgui = getappdata(0,'MQCgui');
setappdata(MQCgui,'ListOfUncoCrops',{});                                                % here is the list of uncorrect elements added to the dataset

guidata(hObject, handles);

%% output function... not used here
function varargout = MQC_IHM_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

%% Callback for the missed cells edit box... not used
function MISSED_CELLS_EB_Callback(hObject, eventdata, handles)

function MISSED_CELLS_EB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function for the ROI with Cell In Division label edit box
function ROI_CID_LABEL_EB_Callback(hObject, eventdata, handles)

if get(gcf,'CurrentCharacter') == 13                                                    % if the used presses the "Return" key, the label will be added to the list of uncorrect crops
   ADD_CID_PB_Callback(hObject, eventdata, handles);                                    % see the ADD_PB_Callback for more details
end

function ROI_CID_LABEL_EB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function for the ROI with No Nucleus edit box
function ROI_NN_LABEL_EB_Callback(hObject, eventdata, handles)

if get(gcf,'CurrentCharacter') == 13
    ADD_NN_PB_Callback(hObject,eventdata,handles);
end

function ROI_NN_LABEL_EB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function for the ROI with Unusefull Cells edit box (others)
function ROI_UC_LABEL_EB_Callback(hObject, eventdata, handles)

if get(gcf,'CurrentCharacter') == 13
    ADD_UC_PB_Callback(hObject,eventdata,handles);
end

function ROI_UC_LABEL_EB_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function for the ROI with more than one cell edit box (MTOC)
function ROI_MTOC_LABEL_EB_Callback(hObject, eventdata, handles)
if get(gcf,'CurrentCharacter') == 13
    ADD_MTOC_PB_Callback(hObject,eventdata,handles);
end

function ROI_MTOC_LABEL_EB_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% function for the "Add" button for crops with cells in division
function ADD_CID_PB_Callback(hObject, eventdata, handles)

ListAnalyser('CID',handles.ROI_CID_LABEL_EB, handles);                                  % for more details, see the ListAnalyser function

%% function for the "Add" button for crops with no nucleus
function ADD_NN_PB_Callback(hObject, eventdata, handles)

ListAnalyser('NN',handles.ROI_NN_LABEL_EB, handles);

%% function for the "Add" button for crops with unusefull cell
function ADD_UC_PB_Callback(hObject, eventdata, handles)

ListAnalyser('UC',handles.ROI_UC_LABEL_EB, handles);

%% function for the "Add" button for the crops with more than one cell
function ADD_MTOC_PB_Callback(hObject, eventdata, handles)

ListAnalyser('MTOC',handles.ROI_MTOC_LABEL_EB, handles);



%% function that fills the Elements in the list of uncorrect crops
function ListAnalyser(Reason,edit_box_tag, handles)

MQCgui = getappdata(0,'MQCgui');                                                        % gets the application data set

Str = get(handles.UNCORRECT_CROPS_ST,'string');                                         % here is the string representing the number of uncorrect crops
Nbr = str2double(Str);                                                                  % now we convert it to a number
flag = false;                                                                           % here is a flag with a default value set to false :) (I DO love flags)
ElementInTheList = getappdata(MQCgui,'ListOfUncoCrops');                                % we get the List of Uncorrect crops
NbrOfElementInTheList = length(ElementInTheList);                                       % and we get the number of element in this list

if NbrOfElementInTheList ~= 0                                                           % if there is already something in the list
    for i=1:NbrOfElementInTheList                                                       % we have to check if the label we're going to add isn't already in the list
        if ElementInTheList{i}.label == str2double(get(edit_box_tag,'string'));         % if it is the case
            flag = true;                                                                % we put the flag to true, indicating that the value already exist
        end
    end
end

if flag == false                                                                        % if the flag value is false, it indicates that the label isn't in the list yet
    Nbr = Nbr + 1;                                                                      % thus we add 1 to the number of elements in the list
    ElementInTheList{Nbr}.label = str2double(get(edit_box_tag,'string'));               % and we add the label for the uncorrect crop
    ElementInTheList{Nbr}.cause = Reason;                                               % we add also the reason why we don't take this crop
    setappdata(MQCgui,'ListOfUncoCrops',ElementInTheList);                              % then we modify the list in the data set
end

if Nbr >= str2double(get(handles.NBR_OF_CELLS_ST,'string'))                             % we cannot have more uncorrect crops than the total number of crop in the image
    set(handles.ROI_CID_LABEL_EB,'Enable','off');                                       % thus, if we reach this level, we have to disable everything :)
    set(handles.ROI_NN_LABEL_EB,'Enable','off');
    set(handles.ROI_UC_LABEL_EB,'Enable','off');
    set(handles.ROI_MTOC_LABEL_EB,'Enable','off');
    set(handles.ADD_CID_PB,'Enable','off');
    set(handles.ADD_NN_PB,'Enable','off');
    set(handles.ADD_UC_PB,'Enable','off');
    set(handles.ADD_MTOC_PB,'Enable','off');
end

Str = num2str(Nbr);                                                                     % don't forget to convert the number of element in the list to a string
set(handles.UNCORRECT_CROPS_ST,'string',Str);                                           % and show the (not so) new value in the dialog box

%% function that allow the user to close the dialog box
function FINISH_PB_Callback(hObject, eventdata, handles)

MQCgui = getappdata(0,'MQCgui');                                                        % this is the application data
ListTemp = getappdata(MQCgui,'ListOfUncoCrops');                                        % in order to write things in an excel file, we use a temporary variable

M{1,1} = get(handles.text1,'string');                                                   % we're going to build a 2x8 matrix with all the informations we get from the manual quality control
M{1,2} = str2double(get(handles.NBR_OF_CELLS_ST,'string'));
M{2,1} = get(handles.text2,'string');
M{2,2} = str2double(get(handles.MISSED_CELLS_EB,'string'));
M{3,1} = get(handles.text3,'string');
M{3,2} = str2double(get(handles.CELLS_ON_BORDER_ST,'string'));
M{4,1} = get(handles.text4,'string');
M{4,2} = str2double(get(handles.MCROIS_ST,'string'));
M{5,1} = get(handles.text5,'string');
M{5,2} = str2double(get(handles.UNCORRECT_CROPS_ST,'string'));

counter_CID = 0;                                                                        % as we don't need to write everything in the excel file, we count the number of each uncorrect crop
counter_NN = 0;
counter_UC = 0;
counter_MTOC = 0;

for i=1:length(ListTemp)                                                                % for each kind of uncorrect crop, we count the number
    disp(['The ROI ',num2str(ListTemp{i}.label),' is not studied because its tag is ',ListTemp{i}.cause]);
    if strcmp(ListTemp{i}.cause,'CID') == 1
        counter_CID = counter_CID+1;
    elseif strcmp(ListTemp{i}.cause,'NN') == 1
        counter_NN = counter_NN + 1;
    elseif strcmp(ListTemp{i}.cause,'UC') == 1
        counter_UC = counter_UC + 1;
    elseif strcmp(ListTemp{i}.cause,'MTOC') == 1
        counter_MTOC = counter_MTOC + 1;
    else
        disp(['Problem in the cause of uncorrect ROI for crop ',num2str(ListTemp{i}.label)]);
    end
end

M{6,1} = get(handles.text6,'String');
M{6,2} = counter_CID;
M{7,1} = get(handles.text7,'string');
M{7,2} = counter_NN;
M{8,1} = get(handles.text9,'string');
M{8,2} = counter_MTOC;
M{9,1} = get(handles.text8,'string');
M{9,2} = counter_UC;
M{10,1} = 'Number of ROIs that are really correct';
M{10,2} = str2double(get(handles.NBR_OF_CELLS_ST,'string')) - str2double(get(handles.CELLS_ON_BORDER_ST,'string')) - str2double(get(handles.MCROIS_ST,'string')) - str2double(get(handles.UNCORRECT_CROPS_ST,'string'));

FileName = getappdata(getappdata(0,'hGui'),'FileName');
pos = findstr('.tif',FileName)-1;
FileName = ['Stats_',FileName(1:pos)];
Path = getappdata(getappdata(0,'hGui'),'PathName');

Root = cd();
cd(Path);
xlswrite(FileName,M);                                                                       % and finally, we write the excel file
cd(Root);
disp('Closing and saving data in an excel file');
setappdata(getappdata(0,'hGui'),'MQCFlag',false);
delete(gcf);                                                                                % wanna exit? So go away!!!

%% function that controls the user =)
function figure1_KeyPressFcn(hObject, eventdata, handles)
% assuming that the user can anoy him/herself and can click everywhere or
% press keys at any unappropriate moment, we use this function to avoid
% bugs (the function is empty, but you can add anything you want ^__^)

%% function that controls the closing action
function figure1_CloseRequestFcn(hObject, eventdata, handles)

setappdata(getappdata(0,'hGui'),'MQCFlag',false);
disp('Closing the Manual Quality Control without saving...');
delete(hObject);
