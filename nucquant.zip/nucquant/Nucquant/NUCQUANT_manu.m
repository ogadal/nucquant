function NUCQUANT_manu

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   General code nucquant
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;clear;
[File,Path] = uigetfile('*.*','Select output workspace');
load(fullfile(Path,File))

prompt={'Enter the Cell Number:',...
    'Enter the number of clusters:'};
default_values={'1','1'};
answer=inputdlg(prompt,'Choose the nucleus you are interested',1,default_values);
nk1=str2num(answer{1});
ncl=str2num(answer{2});

Sp=0.15;

[U,C,nn1,nn2,nn3,idx]=myclust(output,nk1,ncl);

if ncl==3
    [X11,Y11,Z11,X21,Y21,Z21,X31,Y31,Z31]=plotclust3(U,C,nn1,nn2,nn3,idx);
    U100=[X11 Y11 Z11];Cc=sum(U100)/size(U100,1);
    [S,U2]=kamregulnuc(U100,Cc,3);
    [FV11,yy]=debdel(S,U2,U100);
    [Vr,Sr]=stlVolume(transpose(FV11.vertices),transpose(FV11.faces));
    
    U200=[X21 Y21 Z21];Cc=sum(U200)/size(U200,1);
    [S,U2]=kamregulnuc(U200,Cc,3);
    [FV22,yy2]=debdel(S,U2,U200);
    [Vg,Sg]=stlVolume(transpose(FV22.vertices),transpose(FV22.faces));
    
    V=[];W=[];
    [V,W]=distrealnpc2env(V,W,yy,U100,Sp);
    [V,W]=distrealnpc2env(V,W,yy2,U200,Sp);
    
    plotclustnearfar(U100,U200,V,W,FV11,FV22);
    
    output(nk1).Vnucleus=Vr+Vg;
    output(nk1).Snucleus=Sr+Sg;
    % Calculate the radius of the sphere with the same volume.
    Rr=(3*(Vr+Vg)/(4*pi))^(1/3);
    % Calculate the surface area of the sphere with the same volume of this
    % nucleus.
    Ss=4*pi*Rr^2;
    output(nk1).sphericity=Ss/(Sr+Sg);
    disp(['Surface ------  ' num2str(output(nk1).Snucleus)])
    disp(['Volume ------  ' num2str(output(nk1).Vnucleus)])
    disp(['Sphericity ------  ' num2str(output(nk1).sphericity)])
    clear X11 Y11 Z11 X21 Y21 Z21 X31 Y31 Z31 U100 S U2 FV11 yy Vr Sr;
    clear U200 U2 FV22 yy2 Vg Sg Rr Ss;
end

if ncl==2
   [X11,Y11,Z11,X21,Y21,Z21]=plotcluster2(U,C,nn1,nn2,idx);
     
   U100=[X11 Y11 Z11];Cc=sum(U100)/size(U100,1);
    [S,U2]=kamregulnuc(U100,Cc,3);
    [FV11,yy]=debdel(S,U2,U100);
    [Vr,Sr]=stlVolume(transpose(FV11.vertices),transpose(FV11.faces));
    
    V=[];W=[];
    [V,W]=distrealnpc2env(V,W,yy,U100,Sp);
    
    U200=[X21 Y21 Z21];Cc=sum(U200)/size(U200,1);
    [S,U2]=kamregulnuc(U200,Cc,3);
    [FV22,yy2]=debdel(S,U2,U200);
    [Vg,Sg]=stlVolume(transpose(FV22.vertices),transpose(FV22.faces));
    
    [V,W]=distrealnpc2env(V,W,yy2,U200,Sp);
    
    plotclustnearfar(U100,U200,V,W,FV11,FV22)
    
    K0=surfinter(FV11,FV22);
    if size(K0,1)>0
        Surf12=plotinter(FV11,FV22,K0);
        [ SS ] = planeqnuc(Surf12);
        [K1,KS1]=intersplansph(FV11,SS);
        [K2,KS2]=intersplansph(FV22,SS);
        [ Sp1,Vp1 ] = volsurfnuc( Vr,Sr,K1,SS );
        [ Sp2,Vp2 ] = volsurfnuc( Vg,Sg,K2,SS );
        Surftot=Sp1+Sp2;
        Voltot=Vp1+Vp2;
    else 
        Surftot=Sr+Sg;
        Voltot=Vr+Vg;                    
    end
            output(nk1).Vnucleus=Voltot;
            output(nk1).Snucleus=Surftot;
            % Calculate the radius of the sphere with the same volume.
            Rr=(3*Voltot/(4*pi))^(1/3);
            % Calculate the surface area of the sphere with the same volume of this
            % nucleus.
            Ss=4*pi*Rr^2;
            output(nk1).sphericity=Ss/Surftot;
            disp(['Surface ------  ' num2str(Surftot)])
            disp(['Volume ------  ' num2str(Voltot)])
            disp(['Sphericity ------  ' num2str(output(nk1).sphericity)])
            clear X11 Y11 Z11 X21 Y21 Z21 Vg Vr Sg Sr U100 S U2 FV11 yy U200 S U2 FV22 yy2;
            clear K0 Surf12 SS K1 KS1 V W K2 KS2 I1 I2 S11 S21 Sp1 Vp1 Sp2 Vp2;
            clear Surftot Voltot Rr Ss;
end

if ncl==1
    [X11,Y11,Z11,C]=plotcluster1(U,output,nk1);
    U100=[X11 Y11 Z11];
    [S,U2]=kamregulnuc(U100,C,3);
    [FV11,yy]=debdel(S,U2,U100);
    V=[];W=[];
    [V,W]=distrealnpc2env(V,W,yy,U100,Sp);
    
    plot1clustnearfar(U100,V,W,FV11);
    
    [Vr,Sr]=stlVolume(transpose(FV11.vertices),transpose(FV11.faces));
    output(nk1).Vnucleus=Vr;
    output(nk1).Snucleus=Sr;
    % Calculate the radius of the sphere with the same volume.
    Rr=(3*Vr/(4*pi))^(1/3);
    % Calculate the surface area of the sphere with the same volume of this
    % nucleus.
    Ss=4*pi*Rr^2;
    output(nk1).sphericity=Ss/Sr;
    clear X11 Y11 Z11 U100 C Cc S U2 FV11 yy Vr Sr Rr Ss xxx yyy;
    disp(['Surface ------  ' num2str(output(nk1).Snucleus)])
    disp(['Volume ------  ' num2str(output(nk1).Vnucleus)])
    disp(['Sphericity ------  ' num2str(output(nk1).sphericity)])
end
clear U C nn1 nn2 nn3 idx Sp File Path answer default_values ncl nk1 prompt;
end

function [ Sp,Vp ] = volsurfnuc( V,S,K1,SS )
%UNTITLED5 Summary of this function goes here
%Detailed explanation goes here
[ct1,rt1]=sphereFit(K1);
t0=-(SS(1,1).*ct1(1,1)+SS(1,2).*ct1(1,2)+SS(1,3).*ct1(1,3)+SS(1,4))/(SS(1,1)^2+SS(1,2)^2+SS(1,3)^2);
nxx1=ct1(1,1)+SS(1,1)*t0;nxy1=ct1(1,2)+SS(1,2)*t0;nxz1=ct1(1,3)+SS(1,3)*t0;
ct2=[nxx1 nxy1 nxz1];OH=norm(ct1-ct2);hh=rt1-OH;
rr=sqrt(rt1^2-OH^2);

if hh<0
    Sp=-1;
    Vp=-1;
else
    Sp=S-2*pi*rt1*hh;
    Vp=V-(pi/3)*(hh^2)*(3*rt1-hh);
end

end

function [K1,KS1]=intersplansph(Surface1,SS)

V11=[];V12=[];
eps=0.000000000001;
VV1=Surface1.vertices;
W=SS(1,1).*VV1(:,1)+SS(1,2).*VV1(:,2)+SS(1,3).*VV1(:,3)+SS(1,4);
for i=1:size(W,1)
    if W(i,1)>eps
        V11=[V11;VV1(i,:)];
    end
    if W(i,1)<=-eps
        V12=[V12;VV1(i,:)];
    end
end
if size(V11,1)<size(V12,1)
    K1=V12;
    KS1=V11;
else
    K1=V11;
    KS1=V12;
end

end

function [totalVolume,totalArea] = stlVolume(p,t)
% Given a surface triangulation, compute the volume enclosed using
% divergence theorem.
% Assumption:Triangle nodes are ordered correctly, i.e.,computed normal is outwards
% Input: p: (3xnPoints), t: (3xnTriangles)
% Output: total volume enclosed, and total area of surface  
% Author: K. Suresh; suresh@engr.wisc.edu

% Compute the vectors d13 and d12
d13= [(p(1,t(2,:))-p(1,t(3,:))); (p(2,t(2,:))-p(2,t(3,:))); (p(3,t(2,:))-p(3,t(3,:)))];
d12= [(p(1,t(1,:))-p(1,t(2,:))); (p(2,t(1,:))-p(2,t(2,:))); (p(3,t(1,:))-p(3,t(2,:)))];
cr = cross(d13,d12,1);%cross-product (vectorized)
area = 0.5*sqrt(cr(1,:).^2+cr(2,:).^2+cr(3,:).^2);% Area of each triangle
totalArea = sum(area);
crNorm = sqrt(cr(1,:).^2+cr(2,:).^2+cr(3,:).^2);
zMean = (p(3,t(1,:))+p(3,t(2,:))+p(3,t(3,:)))/3;
nz = -cr(3,:)./crNorm;% z component of normal for each triangle
volume = area.*zMean.*nz; % contribution of each triangle
totalVolume = sum(volume);%divergence theorem
end

function [Center,Radius] = sphereFit(X)
% this fits a sphere to a collection of data using a closed form for the
% solution (opposed to using an array the size of the data set). 
% Minimizes Sum((x-xc)^2+(y-yc)^2+(z-zc)^2-r^2)^2
% x,y,z are the data, xc,yc,zc are the sphere's center, and r is the radius

% Assumes that points are not in a singular configuration, real numbers, ...
% if you have coplanar data, use a circle fit with svd for determining the
% plane, recommended Circle Fit (Pratt method), by Nikolai Chernov
% http://www.mathworks.com/matlabcentral/fileexchange/22643

% Input:
% X: n x 3 matrix of cartesian data
% Outputs:
% Center: Center of sphere 
% Radius: Radius of sphere
% Author:
% Alan Jennings, University of Dayton

A=[mean(X(:,1).*(X(:,1)-mean(X(:,1)))), ...
    2*mean(X(:,1).*(X(:,2)-mean(X(:,2)))), ...
    2*mean(X(:,1).*(X(:,3)-mean(X(:,3)))); ...
    0, ...
    mean(X(:,2).*(X(:,2)-mean(X(:,2)))), ...
    2*mean(X(:,2).*(X(:,3)-mean(X(:,3)))); ...
    0, ...
    0, ...
    mean(X(:,3).*(X(:,3)-mean(X(:,3))))];
A=A+A.';
B=[mean((X(:,1).^2+X(:,2).^2+X(:,3).^2).*(X(:,1)-mean(X(:,1))));...
    mean((X(:,1).^2+X(:,2).^2+X(:,3).^2).*(X(:,2)-mean(X(:,2))));...
    mean((X(:,1).^2+X(:,2).^2+X(:,3).^2).*(X(:,3)-mean(X(:,3))))];
Center=(A\B).';
Radius=sqrt(mean(sum([X(:,1)-Center(1),X(:,2)-Center(2),X(:,3)-Center(3)].^2,2)));
end

function [ SS ] = planeqnuc(Surf12)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
VV=Surf12.vertices;
dd1=pdist2(VV,VV);
n=size(VV,1);
M=max(dd1(:));
for i=1:5
    tt=0;
    while tt==0
        s1=floor(1+(n-1)*rand(1,3));
        n1=s1(1,1);n2=s1(1,2);n3=s1(1,3);
        if (dd1(n1,n2)<0.5*M || dd1(n1,n3)<0.5*M || dd1(n3,n2)<0.5*M)
            tt=0;
        else
            P1 = [VV(n1,1),VV(n1,2),VV(n1,3)];
            P2 = [VV(n2,1),VV(n2,2),VV(n2,3)];
            P3 = [VV(n3,1),VV(n3,2),VV(n3,3)];
            normal = cross(P1-P2, P1-P3);
            a=normal(1,1);b=normal(1,2);c=normal(1,3);
            d=-(a*P1(1,1)+b*P1(1,2)+c*P1(1,3));
            tt=1;
        end
    end
    SS(i,:)=[a b c d];
    
end

end

function [V,W]=distrealnpc2env(V,W,yy,U100,Sp)

    for i=1:size(yy,2)
        if yy(1,i)>Sp
            V=[V;U100(i,:)];
        else
           W=[W;U100(i,:)];
        end
    end
   
end

function [FV11,yy]=debdel(S,U2,U100)
U1=[U2;S];
dv1=delaunayn(U1);
tr1=TriRep(dv1,U1);
[trv1,vb1]=freeBoundary(tr1);
FV11.vertices=vb1;FV11.faces=trv1;
xxx=pdist2(FV11.vertices,U100);
yy=min(xxx,[],1);
clear vb1 trv1 FV2;    
end

function [U,C,nn1,nn2,nn3,idx]=myclust(output,nk1,ncl)

X=[];Y=[];Z=[];

x=output(nk1).xNPC; X=[X x]; clear x;
y=output(nk1).yNPC; Y=[Y y]; clear y;
z=output(nk1).zNPC; Z=[Z z]; clear z;

X=transpose(X);Y=transpose(Y);Z=transpose(Z);

U=[X Y Z];
opts = statset('Display','final');
[idx,C] = kmeans(U,ncl,'Distance','sqeuclidean','Replicates',5,'Options',opts);
n1=size(U(idx==1,1),1);n2=size(U(idx==2,1),1);n3=size(U(idx==3,1),1);
 
[nn1,nn2,nn3]=plusgr3(n1,n2,n3);

end

function [X11,Y11,Z11,C]=plotcluster1(U,output,nk1)

xc=output(nk1).xc;yc=output(nk1).yc;zc=output(nk1).zc;
C=[xc yc zc];
X11=U(:,1); Y11=U(:,2); Z11=U(:,3);
figure;
plot3(U(:,1),U(:,2),U(:,3),'g.','MarkerSize',12);
hold on
plot3(C(1,1),C(1,2),C(1,3),'kx','MarkerSize',15,'LineWidth',3);
axis equal;

end

function [X11,Y11,Z11,X21,Y21,Z21]=plotcluster2(U,C,nn1,nn2,idx)

figure
plot3(U(idx==nn1,1),U(idx==nn1,2),U(idx==nn1,3),'r.','MarkerSize',12)
hold on
plot3(U(idx==nn2,1),U(idx==nn2,2),U(idx==nn2,3),'g.','MarkerSize',12)
plot3(C(:,1),C(:,2),C(:,3),'kx',...
     'MarkerSize',15,'LineWidth',3)
axis equal;
legend('Cluster 1','Cluster 2','Centroids',...
       'Location','NW');
title ('Cluster Assignments and Centroids');

X11=U(idx==nn1,1); Y11=U(idx==nn1,2); Z11=U(idx==nn1,3);
X21=U(idx==nn2,1); Y21=U(idx==nn2,2); Z21=U(idx==nn2,3);

end

function [X11,Y11,Z11,X21,Y21,Z21,X31,Y31,Z31]=plotclust3(U,C,nn1,nn2,nn3,idx)

figure
plot3(U(idx==nn1,1),U(idx==nn1,2),U(idx==nn1,3),'r.','MarkerSize',12)
hold on
plot3(U(idx==nn2,1),U(idx==nn2,2),U(idx==nn2,3),'g.','MarkerSize',12)
plot3(U(idx==nn3,1),U(idx==nn3,2),U(idx==nn3,3),'b.','MarkerSize',12)
plot3(C(:,1),C(:,2),C(:,3),'kx', 'MarkerSize',15,'LineWidth',3)
legend('Cluster 1','Cluster 2','Cluster 3','Centroids','Location','NW');title('Cluster Assignments and Centroids');
axis equal;
X11=U(idx==nn1,1); Y11=U(idx==nn1,2); Z11=U(idx==nn1,3);
X21=U(idx==nn2,1); Y21=U(idx==nn2,2); Z21=U(idx==nn2,3);
X31=U(idx==nn3,1); Y31=U(idx==nn3,2); Z31=U(idx==nn3,3);

end

function [S,U2]=kamregulnuc(U,G0,N)

    S=[];U2=U;SG=[];
    for i=1:N
        U1=unique(U,'rows');
        dv1=delaunayn(U1);
        tr1=TriRep(dv1,U1);
        [trv1,vb1]=freeBoundary(tr1);
        for j=1:size(trv1,1)
            P1=vb1(trv1(j,1),:);P2=vb1(trv1(j,2),:);P3=vb1(trv1(j,3),:);
            G=kamgravitnuc(P1,P2,P3,G0);SG=[SG;G];
            B=kamsymnuc(G,G0,P1,P2,P3);
            S=[S;B];
        end
        U=[U1;S];
    end
    clear U U1 dv1 tr1 vb1 P1 P2 P3 G SG B;
end

function G=kamgravitnuc(P1,P2,P3,G0)
    
   % 3G0G=-P1G0-P2G0-P3G0=G0P1+G0P2+G0P3
   xg=(P1(1)+P2(1)+P3(1)-3*G0(1))/3+G0(1);
   yg=(P1(2)+P2(2)+P3(2)-3*G0(2))/3+G0(2);
   zg=(P1(3)+P2(3)+P3(3)-3*G0(3))/3+G0(3);
   
   G=[xg yg zg];   
end


function B=kamsymnuc(G,G0,P1,P2,P3)
    a=G(1)-G0(1);b=G(2)-G0(2);c=G(3)-G0(3);
    d=mean([norm(P1-G0) norm(P2-G0) norm(P3-G0)]);
    
    r(1)=d/sqrt(a*a+b*b+c*c);r(2)=-d/sqrt(a*a+b*b+c*c);
    X=a*r+G0(1);Y=b*r+G0(2);Z=c*r+G0(3);
    
    P11=[X(1) Y(1) Z(1)];P12=[X(2) Y(2) Z(2)];
    
    e1=norm(P11-P1);e2=norm(P12-P1);
    
    if e1<e2
         B=[X(1) Y(1) Z(1)];
    else
        B=[X(2) Y(2) Z(2)];
    end


end
function plot1clustnearfar(U100,V,W,FV11)

figure;
    subplot(2,2,1)
    C= ones(size(U100,1),1)*[0 0 1];
    patch(FV11,'facecolor',[1 0 0]);alpha(0.5);hold on
    scatter3sph(U100(:,1),U100(:,2),U100(:,3),'size',0.1,'color',C,'trans',0.99);
    title('1 cluster with all npc');
    axis equal;
    
    subplot(2,2,2)
    C= ones(size(W,1),1)*[0 0 1];
    patch(FV11,'facecolor',[1 1 1]);alpha(0.2);hold on;
    scatter3sph(W(:,1),W(:,2),W(:,3),'size',0.1,'color',C,'trans',0.99);
    title('1 cluster with near npc');
    axis equal;
    hold on;

    if size(V,1)>0
        Cc= ones(size(V,1),1)*[1 0 0];
        
        subplot(2,2,3)
        patch(FV11,'facecolor',[1 1 1]);alpha(0.2);hold on;
        if size(V,1)==1
            scatter3(V(:,1),V(:,2),V(:,3),'ro','filled');
        else
            scatter3sph(V(:,1),V(:,2),V(:,3),'size',0.1,'color',Cc,'trans',0.99);
        end
        title('1 cluster with far npc');axis equal; 
    end 
end

function plotclustnearfar(U100,U200,V,W,FV11,FV22)

figure
subplot(2,2,1)
C= ones(size(U100,1),1)*[0 0 1];
patch(FV11,'facecolor',[1 0 0]);alpha(0.9);hold on
scatter3sph(U100(:,1),U100(:,2),U100(:,3),'size',0.1,'color',C,'trans',0.99);
title('1st cluster with all npc')
axis equal;

subplot(2,2,2)
C= ones(size(U200,1),1)*[0 0 1];
patch(FV22,'facecolor',[0 1 0]);alpha(0.9);
scatter3sph(U200(:,1),U200(:,2),U200(:,3),'size',0.1,'color',C,'trans',0.99);
title('2nd cluster with all npc')
axis equal;

subplot(2,2,3)

C= ones(size(W,1),1)*[1 0 0];

patch(FV11,'facecolor',[1 1 1]);alpha(0.2);hold on;
patch(FV22,'facecolor',[1 1 1]);alpha(0.2);
scatter3sph(W(:,1),W(:,2),W(:,3),'size',0.1,'color',C,'trans',0.99);
title('both clusters with near npc')
axis equal;

if size(V,1)>0
    subplot(2,2,4)

    C= ones(size(V,1),1)*[1 0 0];

    patch(FV11,'facecolor',[1 1 1]);alpha(0.2);hold on;
    patch(FV22,'facecolor',[1 1 1]);alpha(0.2);
    
    if size(V,1)==1
            scatter3(V(:,1),V(:,2),V(:,3),'ro','filled');
        else
            scatter3sph(V(:,1),V(:,2),V(:,3),'size',0.1,'color',C,'trans',0.99);
    end
    title('both clusters with far npc')
    axis equal
end
end

function K0=surfinter(Surface1, Surface2)

[intersect12, Surf12] = SurfaceIntersection(Surface1, Surface2);

K0=Surf12.vertices;

end

function Surf12=plotinter(Surface1,Surface2,K0)

figure
if size(K0,1)>0
    S=Surface1; trisurf(S.faces, S.vertices(:,1),S.vertices(:,2),S.vertices(:,3),'FaceAlpha', 0.5, 'FaceColor', 'r');
    hold on
    S=Surface2; trisurf(S.faces, S.vertices(:,1),S.vertices(:,2),S.vertices(:,3),'FaceAlpha', 0.5, 'FaceColor', 'g');

    view([3 1 1])
    axis equal
    title ('Two surfaces with the intersection')

    [intersect12, Surf12] = SurfaceIntersection(Surface1, Surface2);
    hold on
    S=Surf12; trisurf(S.faces, S.vertices(:,1),S.vertices(:,2),S.vertices(:,3),'EdgeColor', 'b', 'FaceColor', 'b','LineWidth',3);

else
    S=Surface1; trisurf(S.faces, S.vertices(:,1),S.vertices(:,2),S.vertices(:,3),'FaceAlpha', 0.5, 'FaceColor', 'r');
    hold on
    S=Surface2; trisurf(S.faces, S.vertices(:,1),S.vertices(:,2),S.vertices(:,3),'FaceAlpha', 0.5, 'FaceColor', 'g');

    view([3 1 1])
    axis equal
    title ('Two surfaces with no intersection');
end
end
