function [NbrOfFoldersToAnalyse,ListOfFoldersToAnalyse,NbrOfImages] = PathAnalyser(PathName)

% The PathAnalyser function achieves a complete analysis of the folder
% PathName, going as deep as possible to find images that have a *.tif
% extension. If a folder contains images, the path to this folder is saved
% and returned in ListOfFoldersToAnalyse which is a list of all the folders
% that have images in.

cd(PathName);                                                           % We just go into this folder down to level 1

[s,w] = system('dir /s');                                               % from this level, we can get the layout

pos = findstr(':\',w)-1;                                                % from the tree layout, we can find the general ':\' before the volume name (C:\ or D:\)
NbrOfFolder = length(pos);                                              % now we have to count the number of folder we found
Folders = {};                                                           % this initialize the Folders item

for i=1:NbrOfFolder-1                                                   % for each item
    StrTemp = w(pos(i):pos(i+1));                                       % we cut the global string in several parts from one ':\' position to the next one
    pos2=findstr(char(10),StrTemp)-1;                                   % and now we find the 'Return' character (char(10)) to know where the path is in the new string
    Folders{i} = StrTemp(1:pos2);                                       % and this will be a new path to analyse
end

StrTemp = w(pos(NbrOfFolder):end);                                      % we have to analyse the part between the last pos and the end of the string too
pos2=findstr(char(10),StrTemp)-1;                                       % so we find the 'Return' character
Folders{NbrOfFolder} = StrTemp(1:pos2);                                 % and gets the name of the new path

ListOfFoldersToAnalyse = {};                                            % this is to initialize the List of folders to analyse (we will now eliminate folders that don't have any image)
NbrOfFoldersToAnalyse = 1;                                              % this is a counter to know how much folders countain images
NbrOfImages = 0;

for i=1:NbrOfFolder                                                     % for each folder
    ImageFoundFlag = false;
    cd(Folders{i});                                                     % we go in the folder
    Files = ls();                                                       % we get the list of objects in (files, folders)
    L = size(Files);                                                    % we get the number of objects found
    L = L(1);                                                           % this is the number of objects
    for j=1:L                                                           % and for each object
        pos = findstr('.tif',Files(j,:));                               % we try to find a '.tif' extension proving that there is an image in the folder
        if isempty(pos) == 0                                            % if there is a tif image
            if ImageFoundFlag == false
                ListOfFoldersToAnalyse{NbrOfFoldersToAnalyse} = Folders{i}; % we add the path to the list of folders to analyse
                NbrOfFoldersToAnalyse = NbrOfFoldersToAnalyse + 1;          % we modify the number of folders to analyse
                ImageFoundFlag = true;                                  % and it's no need to continue for this folder...
            end
            NbrOfImages = NbrOfImages + 1;
        end
    end
end