function [Mosaic_Of_Crops,CentroidsOfCrop,BoundariesOfCrop,CropRect] = Split_Image(NbrOfEffectiveCells, Boundaries, Centroids,Image,OffsetDistance);

%This function splits the image Image in a mosaic of small selections. Each
%crop is supposed to contain a single cell previously detected with the
%function "FindBoundaries". Each small window is then stocked in the output
%parameter Mosaic_Of_Crops.
%The window is calculated from the centroid of the boundary and its width
%and height are the maximum distance between this centroid and the farthest
%point of the boundary. An offset is added in order to select the whole
%cell.

disp('Splitting the image...');

width = size(Image,1);                                                  % width of the image
height = size(Image,2);                                                 % height of the image

for i=1:NbrOfEffectiveCells                                             % For each boundary
    wb = waitbar(i/NbrOfEffectiveCells,'Splitting the image...');
    NbrOfPts = length(Boundaries{i});                                   % Stock the number of points in the border

    MaxDist = 0;
    for j=1:NbrOfPts                                                    % For each point of the boudary, calculate the distance between the point and the centroid
        Dist = sqrt(((Centroids(i,1)-Boundaries{i,:}(j,1)).^2+(Centroids(i,2)-Boundaries{i,:}(j,2)).^2));
        if Dist > MaxDist                                                % Stock the greatest distance
            MaxDist = floor(Dist);
        end
    end

    % In order not to reach pixels that are outside the image, we have to
    % be careful and shorten the Max Distance if necessary.
    while Centroids(i,1)-MaxDist < 0 || Centroids(i,2) - MaxDist < 0 || Centroids(i,1) + MaxDist > width || Centroids(i,2) + MaxDist > height
        MaxDist = MaxDist - 1;
    end

    XTL = Centroids(i,1)-MaxDist;                                       % x position of the top left point of crop rectangle
    YTL = Centroids(i,2)-MaxDist;                                       % y position of the top left point of crop rectangle
    XBR = Centroids(i,1)+MaxDist;                                       % x position of the bottom right point of crop rectangle
    YBR = Centroids(i,2)+MaxDist;                                       % y position of the bottom right point of crop rectangle

    offset = OffsetDistance;                                            % small affset to be sure the crop rectangle is large enough
    if XTL - offset < 0 offsetL=0; else offsetL = offset; end           % determines if we can add an offset on the left of the crop rectangle
    if YTL - offset < 0 offsetT=0; else offsetT = offset; end           % determines if we can add an offset on the top of the crop rectangle
    if XBR + offset > width offsetR=0; else offsetR = offset; end       % determines if we can add an offset on the right of the crop rectangle
    if YBR + offset > height offsetB=0; else offsetB = offset; end      % determines if we can add an offset on the bottom of the crop rectangle

    WidthCell = 2*MaxDist + offsetR + offsetL;                          % calculates the width of the crop rectangle with offsets
    HeightCell = 2*MaxDist + offsetT + offsetB;                         % calculates the height of the crop rectangle with offsets

    CropRect{i} = [YTL-offsetT XTL-offsetL HeightCell WidthCell];       % defines the crop rectangle as a rectangle matlab object

    for j=1:WidthCell                                                   % defines a crop image from the global image (RVB parts)
        for k=1:HeightCell
            Cell(j,k,1) = Image(XTL-offsetL+j,YTL-offsetT+k,1);
            if size(Image,3)>1    % Ch.Z, oct 2007
                Cell(j,k,2) = Image(XTL-offsetL+j,YTL-offsetT+k,2);
            end
            if size(Image,3)>2 % Ch.Z, oct 2007
                Cell(j,k,3) = Image(XTL-offsetL+j,YTL-offsetT+k,3);
            end
        end
    end

    Mosaic_Of_Crops{i} = Cell;                                          % add the cell defined previously to the list of crop rectangles
    CentroidsOfCrop(i,1) = Centroids(i,1) - XTL + offsetL;              % defines the x position of the object centroid in the crop referential
    CentroidsOfCrop(i,2) = Centroids(i,2) - YTL + offsetT;              % defines the y position of the object centroid in the crop referential
    for j=1:NbrOfPts
        BoundariesOfCrop{i}(:,1) = Boundaries{i}(:,1) - XTL + offsetL;  % adds the x position of boundaries to the list of boundaries
        BoundariesOfCrop{i}(:,2) = Boundaries{i}(:,2) - YTL + offsetT;  % adds the y position of boundaries to the list of boundaries
    end

    clear Cell;                                                         % clear the cell to begin a new analysis

end

if exist('wb','var') && ishandle(wb)
    delete(wb);                                                             % delete the waitbar
end