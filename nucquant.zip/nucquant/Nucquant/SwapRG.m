function SwappedImage = SwapRG(Image)

% The SwapRG function swaps the Red channel and the Green channel of the
% Image.

disp('swapping red and green..');

SwappedImage(:,:,1) = Image(:,:,2);
SwappedImage(:,:,2) = Image(:,:,1);
SwappedImage(:,:,3) = Image(:,:,3);