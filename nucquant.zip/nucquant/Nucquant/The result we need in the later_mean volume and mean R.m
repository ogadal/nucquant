for i=1:length(output)
Rx(i)=output(i).Rxfe;
Ry(i)=output(i).Ryfe;
Rz(i)=output(i).Rzfe;
Vnucleolus(i)=output(i).Vnuc_mu3;
Vnucleus(i)=(4*pi*Rx(i)*Ry(i)*Rz(i))/3;
end
mean_Vnucleolus=mean(Vnucleolus);
mean_Rx=mean(Rx);
mean_Ry=mean(Ry);
mean_Rz=mean(Rz);
mean_Vnucleus=mean(Vnucleus);

save results.mat
