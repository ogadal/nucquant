
% Add channels containing zero values to a 3D image to get an RGB image
% Nchannels is the number of non-empty channels in the image
function    I3d = add_empty_channels(I3d,Nchannels);
if Nchannels<3
    disp('setting channel 3 to zero..')
    I3d(:,:,:,3) = 0*I3d(:,:,:,1);
    if Nchannels<2
        disp('setting channel 2 to zero..')
        I3d(:,:,:,2) = 0*I3d(:,:,:,1);
    end
end