

function Q = add_quantity(Q,field,value,unit,label,class)

Q.(field).value = value;
Q.(field).unit = unit;
Q.(field).label = label;
Q.class = class;

end