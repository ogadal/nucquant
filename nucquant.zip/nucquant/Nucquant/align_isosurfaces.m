% align isosurfaces (for use with nucquant_align)


faces_nuc = output_suppl(inuc).faces_nuc;
vertices_nuc = output_suppl(inuc).vertices_nuc;

% Translate isosurface to align nucleus centers
if 1==1
    disp('translating  to align nucleus centers..');
    if use_isosurf == 'y'
        vertices_nuc(:,1) = vertices_nuc(:,1) - xcnucleus;
        vertices_nuc(:,2) = vertices_nuc(:,2) - ycnucleus;
        vertices_nuc(:,3) = vertices_nuc(:,3) - zcnucleus;
    else

    end
    xcnucleolus = xcnucleolus - xcnucleus;
    ycnucleolus = ycnucleolus - ycnucleus;
    zcnucleolus = zcnucleolus - zcnucleus;
    xbNPC = xbNPC - xcnucleus;
    ybNPC = ybNPC - ycnucleus;
    zbNPC = zbNPC - zcnucleus;
end

% Apply the scaling to each axes that transforms the nucleus ellipsoid into sphere of
% radius 1
if 1==1
    disp('scaling to transform nucleus ellipsoid into sphere of radius 1..');
    vertices_nuc(:,1) = vertices_nuc(:,1)/Rx;
    vertices_nuc(:,2) = vertices_nuc(:,2)/Ry;
    vertices_nuc(:,3) = vertices_nuc(:,3)/Rz;
    xcnucleolus = xcnucleolus/Rx;
    ycnucleolus = ycnucleolus/Ry;
    zcnucleolus = zcnucleolus/Rz;
    xbNPC = xbNPC/Rx;
    ybNPC = ybNPC/Ry;
    zbNPC = zbNPC/Rz;
end

% Rotation about the z-axis that puts all nucleoli centroids in the (x,z)
% plane (y=0) on the side of positive x
% TO DO: Use the function rotate3d instead ??????
if 1==1
    disp('rotating  around z-axis to put nucleoli centroid in the y=0 (x>0) plane..');
    [theta_nucleolus r_nucleolus] = cart2pol(xcnucleolus,ycnucleolus);
    [theta_vertnuc r_vertnuc] = cart2pol(vertices_nuc(:,1),vertices_nuc(:,2));
    [vertices_nuc(:,1) vertices_nuc(:,2)] = pol2cart(theta_vertnuc-theta_nucleolus,r_vertnuc);
    [theta_bNPC r_bNPC] = cart2pol(xbNPC,ybNPC);
    [xbNPC ybNPC] = pol2cart(theta_bNPC-theta_nucleolus,r_bNPC);
    [xcnucleolus ycnucleolus] = pol2cart(0,r_nucleolus);
end

% Rotation about the y-axis that puts all nucleoli centroids on the x-axis (y=z=0) on
% the side of positive x
if 1==1
    disp('rotating nucleolus around y-axis to put nucleoli centroid on the x-axis (x>0)..');
    [theta_nucleolus r_nucleolus] = cart2pol(xcnucleolus,zcnucleolus);
    [theta_vertnuc r_vertnuc] = cart2pol(vertices_nuc(:,1),vertices_nuc(:,3));
    [vertices_nuc(:,1) vertices_nuc(:,3)] = pol2cart(theta_vertnuc-theta_nucleolus,r_vertnuc);
    [xbNPC zbNPC] = pol2cart(theta_bNPC-theta_nucleolus,r_bNPC);
    [xcnucleolus zcnucleolus] = pol2cart(0,r_nucleolus);
end

% create patch
p = patch('Faces',faces_nuc,'Vertices',vertices_nuc);
% Show isosurface
set(p,'FaceColor','red','EdgeColor','none');
alpha(0.1);
lighting gouraud;
hold on;

if spheres == 'y'
    % Show bNPCs as small green spheres
    [xs,ys,zs] = sphere(10);
    rs = 1/50;
    for i=1:length(xgene)
        surf(xbNPC(i)+xs*rs,ybNPC(i)+ys*rs,zbNPC(i)+zs*rs,'FaceColor','g','EdgeColor','none');
        text(xbNPC(i),ybNPC(i),zbNPC(i),num2str(i));
        alpha(0.3);
        hold on;
    end
    % Show nucleolus center as small red sphere
    NbNPCs = NbNPCs+length(xbNPC);
    for i=1:length(xbNPC)
        surf(xcnucleolus+xs*rs,ycnucleolus+ys*rs,zcnucleolus+zs*rs,'FaceColor','r','EdgeColor','none');
        text(xcnucleolus,ycnucleolus,zcnucleolus,num2str(i));
    end
else
    plot3(xcnucleolus,ycnucleolus,zcnucleolus,'ro');
    hold on
    plot3(xbNPC,ybNPC,zbNPC,'go');
end

% show sphere
[xs,ys,zs] = sphere(50);
surf(xs*R0,  ys*R0, zs*R0,'FaceColor','yellow','EdgeColor','none');
axis equal
xlabel('x (mu)');
ylabel('y (mu)');
zlabel('z (mu)');
