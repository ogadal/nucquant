% compute the spatial transformations required by align_nucleolus to
% generate a composite image of many nucleoli properly aligned to allow
% interpretation. Specifically, the transformations does the following:
%
%  .................

function [Tvox, Tphys] = align_nucleoli_tform(x0,y0,z0,R0,xcnucleus,ycnucleus,zcnucleus,xcnucleolus,ycnucleolus,zcnucleolus,Rx,Ry,Rz,dx,dy,dz,xmin,ymin,zmin,parameters)


% for DEBUG and TEST purposes
AI3=[1 0 0; 0 1 0; 0 0 1; 0 0 0];
I3 = maketform('affine',AI3);

% 1a) Define the translation that moves the nucleus center to the given fixed
% point (x0, y0, z0)
if parameters.translation
Ttrans = translation_tform(x0, y0, z0, xcnucleus, ycnucleus, zcnucleus);
else
    Ttrans = I3;
end

% 1b) Apply the translation to the nucleus and nucleolus centers
[xcnucleus1, ycnucleus1, zcnucleus1] = tformfwd(Ttrans,[xcnucleus ycnucleus zcnucleus]);
[xcnucleolus1, ycnucleolus1, zcnucleolus1] = tformfwd(Ttrans,[xcnucleolus ycnucleolus zcnucleolus]);


% 2a) Define the box transform that transforms the ellipsoid (Rx,Ry,Rz) into to
% sphere of radius R0
if parameters.boxtransform
    Tell2sph0 = ellipsoid2sphere_tform(Rx,Ry,Rz,R0);
else
    Tell2sph0 = I3;
end
Tell2sph = maketform('composite',translation_tform(x0,y0,z0,0,0,0), Tell2sph0, translation_tform(0,0,0,x0,y0,z0));

% 2b) Apply the dilation to the center of the nucleus and the center of the
% nucleolus 
[xcnucleus2, ycnucleus2, zcnucleus2] = tformfwd(Tell2sph,[xcnucleus1 ycnucleus1 zcnucleus1]);
[xcnucleolus2, ycnucleolus2, zcnucleolus2] = tformfwd(Tell2sph,[xcnucleolus1 ycnucleolus1 zcnucleolus1]);

% 3) Define the rotation that moves the nucleolus center onto the x-axis going
% through the point (x0,y0,z0)
if parameters.rotation
    Trot0 = rotation_tform(xcnucleolus2-x0, ycnucleolus2-y0, zcnucleolus2-z0);
else
    Trot0 = I3;
end
Trot = maketform('composite',translation_tform(x0,y0,z0,0,0,0), Trot0, translation_tform(0,0,0,x0,y0,z0) );

% Full transformation in physical space
Tphys = maketform('composite',Trot,Tell2sph,Ttrans);
% Tphys = maketform('affine',AI3);

% Define the transformations from voxel coordinates (matrix indices) into "physical
% coordinates", i.e. in microns
Tvox2phys = voxel2phys_tform(dx,dy,dz,xmin,ymin,zmin);
Tphys2vox = phys2voxel_tform(dx,dy,dz,xmin,ymin,zmin);

% Full transformation in voxel space
% Tvox = maketform('composite',Tscalinginv,Tphys,Tscalingfwd);
Tvox = maketform('composite',Tphys2vox,Tphys,Tvox2phys);


% % for DEBUG TESTS
% xt1 = xcnucleus
% yt1 = ycnucleus
% zt1 = zcnucleus + Rz
% [xt2, yt2, zt2] = tformfwd(Tphys,[xt1 yt1 zt1])

% for DEBUG
if 1==0
    disp('WARNING: using identity transformation in align_nucleoli_tform for TEST only!!');
    Tphys = I3;
    Tvox = maketform('composite',Tphys2vox,Tphys,Tvox2phys);
end

% computes the transformation from voxel space into the corresponding physical space
function T = voxel2phys_tform(dx,dy,dz,xmin,ymin,zmin)
A = [dx     0       0;
    0       dy      0;
    0       0       dz;
    xmin-dx     ymin-dy     zmin-dz];
T = maketform('affine',A);


% computes the transformation from voxel space into the corresponding physical space
function T = phys2voxel_tform(dx,dy,dz,xmin,ymin,zmin)
A = [1/dx     0       0;
    0       1/dy      0;
    0       0       1/dz;
    1-xmin/dx   1-ymin/dy   1-zmin/dz];
T = maketform('affine',A);


% computes the scaling transformation to take into account non-cubic voxels
function T = scalingxyz_tform(dx,dy,dz);
A = [   dx      0       0;
    0       dy      0;
    0       0       dz;
    0        0       0];
T = maketform('affine',A);


% Computes the scaling transformation that transforms the ellipsoid
% of semi-axes Rx,Ry,Rz into a sphere of radius R0
function T = ellipsoid2sphere_tform(Rx,Ry,Rz,R0)
A = [R0/Rx  0       0;
    0     R0/Ry 0;
    0         0       R0/Rz;
    0        0       0];

T = maketform('affine',A);


% Computes the translation that moves point (x1,y1,z1) to point (x0,y0,z0)
function T = translation_tform(x0,y0,z0,x1,y1,z1)

A=[1 0 0;
    0 1 0;
    0 0 1;
    (x0-x1) (y0-y1) (z0-z1)];
T = maketform('affine',A);


% Computes the rotation around the origin
% that moves point (x1,y1,z1) onto the semi axis y=0, z=0, x>0
function T = rotation_tform(x1,y1,z1)

% first make the rotation about the z-axis that puts the point into the y=0 plane with x>0
[theta r] = cart2pol(x1,y1);

Rz = [cos(theta) -sin(theta) 0;
    sin(theta) cos(theta) 0;
    0                0            1;
    0               0              0];

TRz = maketform('affine',Rz);

% now make the rotation about the y-axis that puts the point on the x-axis, x>0
[x2,y2,z2] = tformfwd(TRz,[x1 y1 z1]);
[theta r] = cart2pol(x2,z2);

Ry = [cos(theta) 0   -sin(theta);
    0               1   0;
    sin(theta)  0  cos(theta);
    0               0    0];

TRy = maketform('affine',Ry);

T = maketform('composite',TRy,TRz);
