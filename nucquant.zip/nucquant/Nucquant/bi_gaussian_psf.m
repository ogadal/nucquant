% Returns value at (x,y,z) of a double - Gaussian approximation of the
% 3D point-spread function (PSF)
% The PSF is centered at (0,0,0)
%
% psf(x,y,z) =   1/( (2*pi)^(3/2) * sigma_z * sigma_xy^2 ) * exp( ....)
% sigma2_xy is the sigma of the Gaussian in the horizontal plane squared
% sigma2_z is the sigma of the Gaussian in the axial direction squared

function psf = bi_gaussian_psf(x,y,z,sigma_z,sigma2_xy,sigma2_z)


r2 = x.*x + y.*y;
z2 = z.*z;

if 1==1 % PSF peak equals 1
    psf = exp( -0.5*( r2/sigma2_xy + z2/sigma2_z ) ) ;
else
    psf = exp( -0.5*( r2/sigma2_xy + z2/sigma2_z ) ) / ( 15.7496 * sigma_z * sigma2_xy );
end


if any(isnan(psf))
    error('??????');
end

end