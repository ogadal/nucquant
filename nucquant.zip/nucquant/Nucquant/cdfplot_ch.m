function cdfplot_ch(x)
% plot the cdf (matlab function)
cdfplot(x);
hold on;

% compute and plot the (normalized) kernel density estimation
[f,xi,u] = ksdensity(x); % kernels
f = f/max(f); %normalize the peak so that the cdf and the ks density fit on the same graph
plot(xi,f,'m');

% compute and plot the (normalized) histogram
nbins = 50;
[h,xout] = hist(x,nbins);
h = h/max(h); % normalize the peak
stairs(xout,h,'r-');

legend('cdf',['ksdens (u=',num2str(u),')'],'histogram');

title(['(n=',num2str(length(x)),')']);
end