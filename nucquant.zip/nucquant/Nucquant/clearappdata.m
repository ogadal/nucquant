function clearappdata

% The clearappdata function checks the different applications data and
% detroys them if existing (kind of destructor)

setappdata(0,'hGui',gcf);
hGui = getappdata(0,'hGui');

if isappdata(hGui,'IsImageLoaded')
    rmappdata(hGui,'IsImageLoaded');
end

if isappdata(hGui,'BColors')
    rmappdata(hGui,'BColors');
end

if isappdata(hGui,'outputformat')
    rmappdata(hGui,'outputformat');
end

if isappdata(hGui,'getmicrosettings')
    rmappdata(hGui,'getmicrosettings');
end

if isappdata(hGui,'FileName')
    rmappdata(hGui,'FileName');
end

if isappdata(hGui,'NTimes')
    rmappdata(hGui,'NTimes');
end

if isappdata(hGui,'PathName')
    rmappdata(hGui,'PathName');
end

if isappdata(hGui,'I3d')
    rmappdata(hGui,'I3d');
end

if isappdata(hGui,'dx')
    rmappdata(hGui,'dx');
end

if isappdata(hGui,'dy')
    rmappdata(hGui,'dy');
end
if isappdata(hGui,'dz')
    rmappdata(hGui,'dz');
end

if isappdata(hGui,'n')
    rmappdata(hGui,'n');
end

if isappdata(hGui,'NA')
    rmappdata(hGui,'NA');
end

if isappdata(hGui,'lambda')
    rmappdata(hGui,'lambda');
end

if isappdata(hGui,'Iinfo')
    rmappdata(hGui,'Iinfo');
end

if isappdata(hGui,'Nchannels')
    rmappdata(hGui,'Nchannels');
end

if isappdata(hGui,'input_parameters')
    rmappdata(hGui,'input_parameters');
end

if isappdata(hGui,'Ima')
    rmappdata(hGui,'Ima');
end

if isappdata(hGui,'NbrOfEffectiveCells')
    rmappdata(hGui,'NbrOfEffectiveCells');
end

if isappdata(hGui,'Boundaries')
    rmappdata(hGui,'Boundaries');
end

if isappdata(hGui,'Centroids')
    rmappdata(hGui,'Centroids');
end

if isappdata(hGui,'BThickness')
    rmappdata(hGui,'BThickness');
end

if isappdata(hGui,'BColors')
    rmappdata(hGui,'BColors');
end

if isappdata(hGui,'WidhtForCrops')
    rmappdata(hGui,'WidhtForCrops');
end

if isappdata(hGui,'HeightForCrops')
    rmappdata(hGui,'HeightForCrops');
end

if isappdata(hGui,'Mosaic_Of_Crops')
    rmappdata(hGui,'Mosaic_Of_Crops');
end

if isappdata(hGui,'CentroidsOfCrop')
    rmappdata(hGui,'CentroidsOfCrop');
end

if isappdata(hGui,'BoundariesOfCrop')
    rmappdata(hGui,'BoundariesOfCrop');
end

if isappdata(hGui,'CropRectangles')
    rmappdata(hGui,'CropRectangles');
end

if isappdata(hGui,'BThickness')
    rmappdata(hGui,'BThickness');
end

if isappdata(hGui,'CropTag')
    rmappdata(hGui,'CropTag')
end



