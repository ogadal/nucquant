% clone points  (xi,yi,zi) according to their relative weights. The
% weights are given by the array wi.

function [xi yi zi] = clone_points(xi,yi,zi,wi)

if size(xi)~=size(wi)
    error('xi and wi must have equal sizes !');
end

N1 = length(xi);
wmin = min(wi);
Nclones = min(round(wi/wmin),10); % the weighting is limited to a maximum of 10

xaux = NaN(1,sum(Nclones));
yaux = xaux;
zaux = xaux;

i1=1;
for i=1:N1
    i2 = i1+Nclones(i)-1;
    xaux(i1:i2) = xi(i);
    yaux(i1:i2) = yi(i);
    zaux(i1:i2) = zi(i);
    i1 = i2+1;
end
xi = xaux;
yi = yaux;
zi = zaux;