function [output,output_suppl] =  convert_structures_4nucquant(output,output_suppl)

if iscell(output)
    disp('converting structures for compatibility...');
    if 1==0
        [aux,N] = nonemptystructurearrayelement(output);
        N = sum(aux);
    else
        N = length(output);
        aux = output;
    end
    aux_suppl = output_suppl;
    clear output output_suppl;
    iempty = [];
    whos
    for i=1:N
        if ~isempty(aux{i})
            q = aux{i};
            output(i) = aux{i};
            output_suppl(i) = aux_suppl{i};
        else
            i_empty = [iempty i];
        end
    end
    if ~isempty(iempty)
        warning(['There were ',num2str(length(iempty)),' empty structures !!!']);
    end
else
    output = output;
    output_suppl = output;
end
