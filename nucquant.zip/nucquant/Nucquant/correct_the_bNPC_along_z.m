
% This script is the combination of correct z value and replace zNPC by new
% z value and refitting the reaidus of the nucleus.

clc; close all, clear all;
% Pick the input data
a=dir('QC_OK*');
inputfilename = a.name;
inputfolder = cd;
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
disp(aux);
wb = waitbar(0,aux);
load(inputfilename);
if ishandle(wb), delete(wb); end
parameters.inputfilename = inputfilename;
parameters.inputfolder = inputfolder;

clear *_all;

i=length(output);


%% correct zbNPC before and after.

% compute deltax, deltay and deltaz between bNPC and nucleus and dist_bNPC_nucleus/mean_R.
for j=1:i
dist_bNPC_nucleus_x=[]; dist_bNPC_nucleus_y=[]; dist_bNPC_nucleus_z=[];
dist_bNPC_nucleus_centroid=[];dist_bNPC_nucleus_centroid_relative=[];R=[];

% Import nuclei centers
    xcnucleus = []; ycnucleus = []; zcnucleus = [];
    xcnucleus = [output.xn];
    ycnucleus = [output.yn];
    zcnucleus = [output.zn];

% Import the position and the number of bNPCs
   xbNPC = []; ybNPC = []; zbNPC = [];
   xbNPC = [output.xbNPC];
   ybNPC = [output.ybNPC];
   zbNPC = [output.zbNPC];
   
   
% Import the half-axies of the nucleus ellipsoid
    Rx=[output.Rxfe];
    Ry=[output.Ryfe];
    Rz=[output.Rzfe];
    
disp('computing detax, detay and detaz between bNPC and nucleus center including the dist_bNPC_nucleus_relative...');
%a=sum(nbNPC(1:(j-1)))+1;b=sum(nbNPC(1:j)); % extract coordinates of NPCs to their corresponding nuclei
output(j).dist_bNPC_nucleus_centroid=distance3d(xbNPC(j),ybNPC(j),zbNPC(j),xcnucleus(j),ycnucleus(j),zcnucleus(j));
output(j).R=[Rx(j),Ry(j),Rz(j)];
output(j).dist_bNPC_nucleus_centroid_relative=output(j).dist_bNPC_nucleus_centroid/mean(output(j).R);
output(j).dist_bNPC_nucleus_x=xbNPC(j)-xcnucleus(j);
output(j).dist_bNPC_nucleus_y=ybNPC(j)-ycnucleus(j);
output(j).dist_bNPC_nucleus_z=zbNPC(j)-zcnucleus(j);

end

% Plot the origin figure
figure('Name','origin data analysis');
subplot(1,3,1);
x=[output.dist_bNPC_nucleus_x];
y=[output.dist_bNPC_nucleus_centroid_relative];
xlabel('deltaXbNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
plot(x,y,'r.','MarkerSize',4);
legend(['N=',num2str(length(x))]);

subplot(1,3,2);
x=[output.dist_bNPC_nucleus_y];
y=[output.dist_bNPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaYbNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);

subplot(1,3,3);
x=[output.dist_bNPC_nucleus_z];
y=[output.dist_bNPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaZbNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);

% Fitting the figure3 using polyfit
p=polyfit(x,y,2);
c=p(1);d=p(2);

% correct the z value.
for j=1:i
    
   zn=[];R_xy=[];R_xy_mean=[];R_mean=[];
   
   % import the position of the nucleus center
   output(j).R_mean=mean(output(j).R);
   output(j).R_xy=[output(j).Rxfe,output(j).Ryfe];
   output(j).R_xy_mean=mean(output(j).R_xy);
end

% Import the postion of all nucleus center(z) (new)
zcnucleus = [];R_mean_new=[];R_mean=[];

zcnucleus = [output.zn];
R_mean_new=[output.R_xy_mean];
R_mean=[output.R_mean];

   
% Import the position and the number of NPCs
xbNPC = []; ybNPC = []; zbNPC = []; 
xbNPC = [output.xbNPC];
ybNPC = [output.ybNPC];
zbNPC = [output.zbNPC];

% Import the deltax, deltay and deltaz
dist_bNPC_nucleus_x=[];dist_bNPC_nucleus_y=[];dist_bNPC_nucleus_z=[];
dist_bNPC_nucleus_x=[output.dist_bNPC_nucleus_x];
dist_bNPC_nucleus_y=[output.dist_bNPC_nucleus_y];
dist_bNPC_nucleus_z=[output.dist_bNPC_nucleus_z];

% Import the old distance between bNPC and nucleus center
dist_bNPC_nucleus_centroid_relative=[];dist_bNPC_nucleus_z_new=[];zbNPC_new=[];
dist_bNPC_nucleus_centroid_relative=[output.dist_bNPC_nucleus_centroid_relative];

dist_bNPC_nucleus_centroid_relative_new=[];dist_bNPC_nucleus_centroid_new=[];
for k=1:i
    dist_bNPC_nucleus_centroid_relative_new(k)=dist_bNPC_nucleus_centroid_relative(k)-c*(dist_bNPC_nucleus_z(k))^2-d*(dist_bNPC_nucleus_z(k));
    dist_bNPC_nucleus_centroid_new(k)=dist_bNPC_nucleus_centroid_relative_new(k)*R_mean(k);
if dist_bNPC_nucleus_z(k)<0
        dist_bNPC_nucleus_z_new(k)=-sqrt(abs((dist_bNPC_nucleus_centroid_new(k))^2-(dist_bNPC_nucleus_x(k))^2-(dist_bNPC_nucleus_y(k))^2));
else
    dist_bNPC_nucleus_z_new(k)=sqrt(abs((dist_bNPC_nucleus_centroid_new(k))^2-(dist_bNPC_nucleus_x(k))^2-(dist_bNPC_nucleus_y(k))^2));
end   % This part I think the z correction exist some question, we need to check.
zbNPC_new(k)=dist_bNPC_nucleus_z_new(k)+zcnucleus(k);
end

% Plot the figure
figure('Name','correctted data');
subplot(1,3,1);
x=dist_bNPC_nucleus_x;
y=dist_bNPC_nucleus_centroid_relative_new;
xlabel('deltaXbNPC-nucleus (mu)'),
ylabel('Distance'),
plot(x,y,'r.','MarkerSize',4);
legend(['N=',num2str(length(x))]);

subplot(1,3,2);
x=dist_bNPC_nucleus_y;
y=dist_bNPC_nucleus_centroid_relative_new;
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaYbNPC-nucleus (mu)'),
ylabel('Distance'),
legend(['N=',num2str(length(x))]);

subplot(1,3,3);
x=dist_bNPC_nucleus_z_new;
y=dist_bNPC_nucleus_centroid_relative_new;
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaZbNPC-nucleus-new (mu)'),
ylabel('Distance'),
legend(['N=',num2str(length(x))]);



%% Use new zbNPC replace the origin zbNPC.


for j=1:i
    disp('computing the new zbNPC...');
    output(j).zbNPC=zbNPC_new(j);
end



%% Refitting the radius by ellipsoid_3param method.
for j=1:i
    output(j).sbNPC=max(output(j).sNPC);
end

for j=1:i
    
if 1==1 %%% Use putative bNPC
        xNEp = output(j).xbNPC; yNEp = output(j).ybNPC; zNEp = output(j).zbNPC; sNEp = output(j).sbNPC;nbNEp=length(output(j).xbNPC);
end
if nbNEp>0
  disp('fitting a 3-parameter (Rx,Ry,Rz)  axes-aligned ellipsoid ..');
  [output(j).Rxfe,output(j).Ryfe,output(j).Rzfe,meandist_fn,residual,exitflag_fn] = fit_ellipsoid_3param(xNEp,yNEp,zNEp,sNEp,output(j).xc,output(j).yc,output(j).zc);
  [output(j).xn,output(j).yn,output(j).zn] = deal(output(j).xc,output(j).yc,output(j).zc);  
  disp(['result of fitting nucleus surface: meandist_fn=',num2str(meandist_fn),', exitflag=',num2str(exitflag_fn)]);
else
    Rxfe = NaN; Ryfe = NaN; Rzfe = NaN;
        [output(j).xn,output(j).yn,output(j).zn] = deal(output(j).xc,output(j).yc,output(j).zc); meandist_fn=NaN; exitflag_fn=NaN;
end
end

%% Delete the rest of the parameters during this caculation
clear R;
clear R_mean R_mean_new R_xy R_xy_mean Rx Ry Rz a b c d;
clear dist_bNPC_nucleus_centroid dist_bNPC_nucleus_centroid_new dist_bNPC_nucleus_centroid_relative dist_bNPC_nucleus_centroid_relative_new;
clear dist_bNPC_nucleus_x dist_bNPC_nucleus_y dist_bNPC_nucleus_z dist_bNPC_nucleus_z_new exitflag_fn i j k m meandist_fn nbNEp;
clear p residual sNEp x xNEp xbNPC xcnucleus xn_new y yNEp ybNPC ycnucleus yn_new zNEp zbNPC zbNPC_new zcnucleus zn zn_new;
clear a aux inputfilename inputfolder parameters wb;

save QC_OKauto_correction_nucquant_output_suppl.mat;

