% Compute the curvature of the intensity distribution of the 3D (or 2D) image I at
% pixel (i,j,k)
%
% (dx,dy,dz) are the dimensions of a voxel
%
% see blue lab note book p. 109 for the 3D case
%TODO: check the 2D case !

function kappa = curvature_thomann(I,i,j,k,dx,dy,dz)

if size(I,3)>1 % truly 3D image
    Dx2 = ( I(i+1,j,k) + I(i-1,j,k)  - 2*I(i,j) ) / (dx*dx);
    Dy2 = ( I(i,j+1,k) + I(i,j-1,k)  - 2*I(i,j) ) / (dy*dy);
    Dz2 = ( I(i,j,k+1) + I(i,j,k-1)  - 2*I(i,j) ) / (dz*dz);

    Dxy = ( I(i+1,j+1,k) + I(i-1,j-1,k) - I(i-1,j+1,k) - I(i+1,j-1,k) ) / (4*dx*dy);
    Dxz = ( I(i+1,j,k+1) + I(i-1,j,k-1) - I(i-1,j,k+1) - I(i+1,j,k-1) ) / (4*dx*dz);
    Dyz = ( I(i,j+1,k+1) + I(i,j-1,k-1) - I(i,j-1,k+1) - I(i,j+1,k-1) ) / (4*dy*dz);

    kappa = Dx2*Dy2*Dz2 + 2*Dxy*Dyz*Dxz - Dxz*Dxz*Dy2 - Dyz*Dyz*Dx2 - Dxy*Dxy*Dz2;

else % image is in fact 2D
    % CHECK THIS !
    Dx2 = ( I(i+1,j,k) + I(i-1,j,k)  - 2*I(i,j) ) / (dx*dx);
    Dy2 = ( I(i,j+1,k) + I(i,j-1,k)  - 2*I(i,j) ) / (dy*dy);
    Dxy = ( I(i+1,j+1,k) + I(i-1,j-1,k) - I(i-1,j+1,k) - I(i+1,j-1,k) ) / (4*dx*dy);

    kappa = Dx2*Dy2 - Dxy*Dxy;

end