function disp_nice(X)

if ~isstr(X)
    disp(X)
else
    aux = get(0,'CommandWindowSize');
    N = aux(1)-1;
    L = length(X);
    m = ceil(L/N);
    j = 1;
    for i=1:m
        disp(X(j:min(j+N,L)));
        j = j+N+1;
    end
end
    