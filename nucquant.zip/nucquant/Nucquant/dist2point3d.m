%%% Computes the signed euclidian distance (dist) between a voxel (i,j,k)
%%% and an object defined by the non-zero voxels of the 3D
%%% binary image Ibw.
%%% If the voxel is inside the object, i.e. if Ibw(i,j,k) is non-zero, returns minus the negative distance to the
%%% complementary of the object, i.e. to the nearest zero-valued voxel.
%%% Returns infinity if Ibw is identically zero, minus infinity if Ibw  has no zero values.
%%%
%%% the vectors (xx,yy,zz) define the image grid in true spatial coordinates.
%%% Also returns the indices (inn,jnn,knn) of the nearest  non-zero voxel
%%% (for positive distances) or zero voxel (for negative distances)

%%% TODO: could be slightly optimized by assuming that dx=dy, and using
%%% only the ratio dz/dx in the computations for each voxel (absolute
%%% values of dx and dz must then be used only once before returning the
%%% result)
function [dist,inn,jnn,knn] = dist2point3d(i,j,k,Ibw,xx,yy,zz)

[Ni Nj Nk] = size(Ibw);
dist2 = Inf;
inn = NaN; jnn = NaN; knn=NaN;

if any(isnan([i j k]))
    dist = NaN; inn = NaN; jnn = NaN; knn = NaN;
else
    % Scan the whole 3D image
    if Ibw(i,j,k) == 0 % The voxel is not inside the object
        % Scan the 3D image
        for ii=1:Ni
            for jj = 1:Nj
                for kk = 1:Nk
                    if Ibw(ii,jj,kk)~=0
                        aux = dist2_voxel_to_voxel(i,j,k,ii,jj,kk,xx,yy,zz);
                        if aux<dist2
                            dist2 = aux;
                            inn = ii;
                            jnn = jj;
                            knn = kk;
                        end
                    end
                end
            end
        end
        dist = sqrt(dist2);
    else % the voxel is inside the object
        for ii=1:Ni
            for jj = 1:Nj
                for kk = 1:Nk
                    if Ibw(ii,jj,kk)==0
                        aux = dist2_voxel_to_voxel(i,j,k,ii,jj,kk,xx,yy,zz);
                        if aux<dist2
                            dist2 = aux;
                            inn = ii;
                            jnn = jj;
                            knn = kk;
                        end
                    end
                end
            end
        end
        dist = -sqrt(dist2);
    end
end

%%% Returns the squared euclidian distance between voxels (i1,j1,k1) and  (i2,,j2,k2).
%%% (xx,yy,zz) define the image grid in true spatial coordinates.
function dist2 = dist2_voxel_to_voxel(i1,j1,k1,i2,j2,k2,xx,yy,zz)
dx = xx(i2) - xx(i1);
dy = yy(j2) - yy(j1);
dz = zz(k2) - zz(k1);
dist2 = dx*dx + dy*dy + dz*dz;