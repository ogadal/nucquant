function d = distance3d(x1,y1,z1,x2,y2,z2)
 
% N = length(x1);
% if N~=length(y1) || N~=length(z1) || length(y1)~=length(z1)
%     error('x1 y1 z1 must have equal lengths !');
% end
% 
% if N==1
%     d = sqrt((x1-x2).^2+(y1-y2).^2+(z1-z2).^2);
% else
%     for i = 1:N
%         d(i) = distance3d(x1(i),y1(i),z1(i),x2(i),y2(i),z2(i));
%     end
% end

d = sqrt( (x1-x2).^2 + (y1-y2).^2 + (z1-z2).^2 );

end