% Returns the  distance between the input point(s) and the
% axes-aligned ellipsoid centered on  (0,0,0)
% and with the three half axes (Rx,Ry,Rz).
% Also returns the coordinates (xn, yn, zn) of the closest point(s).
%
% The result depends on the 'method' option
% - 'true' returns a good approximation of the true euclidian distance
% - 'ch1' is my own variant
%
% NB: See function distance_point2ellipsoid_algebraic.m for the algebraic
% distance

function [d, xn, yn, zn] = distance_point2ellipsoid(x,y,z,Rx,Ry,Rz,method)

if Rx*Ry*Rz == 0
    error('distance_point2ellipsoid: Rx*Ry*Rz == 0!');
end

if any(isnan([x y z Rx Ry Rz]))
    d=NaN; xn=NaN; yn=NaN; zn=NaN;
else
    switch method
        case 'ch1'
            R= mean([Rx Ry Rz]);
            aux = sqrt((x/Rx).^2 + (y/Ry).^2 + (z/Rz).^2);
            d = (aux-1)*R;

            xn = NaN; yn = NaN; zn = NaN;
            %     case 'algebraic'
            %         d = (x/Rx).^2 + (y/Ry).^2 + (z/Rz).^2 - 1;

        case 'true' % very slow brute-force method - IMPROVE LATER !
            Np = length(x); % number of input points
            if Np>1 % if more than one points, recursively call the function for 1 point - TODO: inefficient ! discretized ellipsoid should be computed only once ! IMPROVE THIS LATER !!!
                for ip= 1:Np
                    [d(ip) xn(ip) yn(ip) zn(ip)]  = distance_point2ellipsoid(x(ip),y(ip),z(ip),Rx,Ry,Rz,'true');
                end
            else
                for ip=1:length(x)
                    % first, discretize the ellipsoid in the quadrant of the input
                    % point
                    if z>=0,
                        phimin = 0; phimax = pi/2;
                    else
                        phimin = -pi/2; phimax = 0;
                    end
                    if x>=0,
                        if y>=0, % quadrant 1
                            thetamin = 0; thetamax = pi/2;
                        else % quadrant 4
                            thetamin = -pi/2; thetamax = 0;
                        end
                    else
                        if y>=0, % quadrant 2
                            thetamin = pi/2; thetamax = pi;
                        else % quadrant 3
                            thetamin = pi; thetamax = 3*pi/2;
                        end
                    end
                    Ntheta = 300; % number of discretized theta angles
                    Nphi = Ntheta;
                    thetas = linspace(thetamin,thetamax,Ntheta);
                    phis = linspace(phimin,phimax,Nphi);
                    % Pick the point on the discretized ellipsoid portion
                    % that has the smallest distance to the input point
                    % (vectorized for speed)
                    % Note: parametric equation of ellipsoid:
                    % x = Rx cos(phi) cos(theta)
                    % y = Ry cos(phi) sin(theta)
                    % z = Rz sin(phi)
                    xe1 = Rx * cos(phis') * cos(thetas);
                    ye1 = Ry * cos(phis') * sin(thetas);
                    ze1 = Rz * sin(phis') * ones(size(thetas));
                    % convert matrices to vectors
                    xe = xe1(:); ye = ye1(:); ze = ze1(:);
                    de2 = (xe-x).^2 + (ye-y).^2 + (ze-z).^2;
                    % check vector length
                    if length(de2)~= Ntheta*Nphi
                        error('length of vector de2 incorrect !');
                    end
                    [dmin2, imin] = min(de2(:));
                    xn = xe(imin);
                    yn = ye(imin);
                    zn = ze(imin);
                end
                % use algebraic distance to determine if point inside or outside
                % ellipsoid
                d_alg = (x/Rx).^2 + (y/Ry).^2 + (z/Rz).^2 - 1;
                d = sign(d_alg).*sqrt(dmin2); % square root added Sept 20, 2006 (distances computed before this date were false !!!!)
            end

        otherwise
            error(['invalid method ',method,' in distance_point2ellipsoid !']);
    end
end
