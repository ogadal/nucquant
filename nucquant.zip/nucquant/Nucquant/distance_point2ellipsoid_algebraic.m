% Returns the  distance between the input point and the
% axes-aligned ellipsoid centered on  (0,0,0)
% and with the three half axes (Rx,Ry,Rz).
%
% The result depends on the 'method' option
% - 'true' returns a good approximation of the true euclidian distance
% - 'algebraic' is the (so-called) algebraic distance,
% - 'ch1' is my own variant
%

function d = distance_point2ellipsoid_algebraic(x,y,z,Rx,Ry,Rz)
%
% if Rx*Ry*Rz == 0
%     error('distance_point2ellipsoid: Rx*Ry*Rz == 0!');
% end

d = (x/Rx).^2 + (y/Ry).^2 + (z/Rz).^2 - 1;

end