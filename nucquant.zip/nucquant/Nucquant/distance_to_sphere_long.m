% Compute algebraic distances of points to a sphere (for use with fit_sphere.m)
% (xi,yi,zi) are three arrays containing the x,y,z coordinates of the
% points
% (xc,yc,zc) are the coordinates of the sphere center and
% R is its radius
function d = distance_to_sphere_long(xi,yi,zi,xc,yc,zc,R)


N = length(xi);

d = nan(size(xi));

for i=1:N
    x = xi(i);
    y = yi(i);
    z = zi(i);
    d(i) = sqrt((x-xc)^2+(y-yc)^2+(z-zc)^2)-R;
end