% Compute distances to object boundary of each object voxel of the 3D binary
% image Ibw.
% (xx,yy,zz) define the image grid in true spatial coordinates.

function dist   = distances_to_border(Ibw,xx,yy,zz)

Ibwcomp = imcomplement(Ibw);

[Ni Nj Nk] = size(Ibw);

dist = nan(1,Ni*Nj*Nk); % preallocation for speed

% Scan the whole 3D image
counts = 0;
for ii=1:Ni
    for jj = 1:Nj
        for kk = 1:Nk
            if Ibw(ii,jj,kk) == 0 % The voxel is not inside the object
                % do nothing
            else
                counts = counts+1;
                [dist(counts),inn,jnn,knn] = dist2point3d(ii,jj,kk,Ibwcomp,xx,yy,zz);
            end
        end
    end
end

dist = dist(1:counts);
