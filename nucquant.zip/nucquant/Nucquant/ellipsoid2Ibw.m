%%% Create a binary mask of the same size as I correponding to the interior of the ellipsoid
%%% centered at (xfn,yfn,zfn) with half-axes (Rxfe,Ryfe,Rzfe)

function Ibwnucleus = ellipsoid2Ibw(I,xx,yy,zz,xfn,yfn,zfn,Rxfe,Ryfe,Rzfe)

aux = zeros(size(I));
Nx = length(xx);
Ny = length(yy);
Nz = length(zz);

ii= 1:size(I,1);
jj = 1:size(I,2);
kk = 1:size(I,3);

xs = i2x(ii,xx);
ys = i2x(jj,yy);
zs = i2x(kk,zz);

for i = 1:size(I,1)
    x = xs(i);
    for j = 1:size(I,2)
        y = ys(j);
        for k = 1:size(I,3)
            z = zs(k);
            if 1==0  %  SLOW !
                aux(i,j,k) = (distance_point2ellipsoid(x-xfn,y-yfn,z-zfn,Rxfe,Ryfe,Rzfe,'true')<0);
            else
                aux(i,j,k) = ( ((x-xfn)/Rxfe).^2 + ((y-yfn)/Ryfe).^2 + ((z-zfn)/Rzfe).^2) <1; 
            end
        end
    end
end

Ibwnucleus = aux;

return;