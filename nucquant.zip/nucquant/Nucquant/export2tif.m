%%% export a 2D or 3D RGB or grey level image or a sequence of such images
%%% as  tif files
%%% assuming that the number of slices is given by the third dimension of
%%% the image array.

function flag = export2tif(image,filestem,nbdigits,dirname);

dir0 = pwd;
cd(dirname);
Nz = size(image,3);

for i= 1:Nz
	Iaux = squeeze(image(:,:,i,:));
	filename = [filestem,'_',int2str2(i,nbdigits),'.tif'];
	imwrite(Iaux,filename,'tif','Compression','none');
	disp(['Wrote image ',filename,' to disk.']);
end

flag = 1;