%%% Function that determines everything that's needed to export a 2D or 3D RGB or grey level image or
%%% a sequence of such images to tif files
%%% if options=0, ask lots of questions (works in general cases, but slow)
%%% if options=10, only asks to pick the folder containing the sequence
%%% (works in more restricted cases, but fast)

function [dirname,filestem,nbdigits] = export2tifinfo(options);

% assign default values
fstart = 0;
fskip = 1;
nbdigits = 3;

if options<10

	if options<8
		nbdigits = str2num(input2(['How many digits in the frame number  ?'],'4'));
	end
	%%% Get the 'stem' of the image file names
	filestem = input2('Enter the stem of the output file names','image');
else
	aux = uigetdir('*.*','Select folder for output images or cancel if done');
	if aux~=0
		dirname = [aux,'/'];
		filestem = 'image';
	else
		dirname=''; filestem=''; nbdigits=NaN;
	end
end