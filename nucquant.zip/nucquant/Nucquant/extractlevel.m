function CC=extractlevel(C)

if C(2,1)<5
    N(1)=C(2,3);bb=3;CC(1)=C(1,3);
    indg(1)=4;indd(1)=4;
else
    N(1)=C(2,1);bb=1;CC(1)=C(1,1);
    indg(1)=2;indd(1)=2;
    
end

fin=0;i=1;
while fin==0
        i=i+1;
        if bb+1+N(i-1)>=size(C,2)                    
            indg(i)=size(C,2);indd(i)=size(C,2);        
            fin=1;
        else  
            CC(i)=C(1,bb+1+N(i-1));
            N(i)=C(2,bb+1+N(i-1));    
            bb=bb+1+N(i-1);
            indg(i)=bb-1;indd(i)=bb+1;
            fin=0;
        end        
end
