
%%% Show 2D views of the raw 3D image I and a binary image of same size, Ibw
%%% (xx,yy,zz) define the image grid in true spatial coordinates.
%%%
%%% In addition, place a mark at (x,y,z)

function fig = fig_I_and_Ibw(I,Ibw,xx,yy,zz,namestring,x,y,z);

warning off MATLAB:Axes:NegativeDataInLogAxis

if isnan(x) || isnan(y) || isnan(z)
    warning('suppressed figure generation by fig_I_and_Ibw because coordinates are NaN!');
    fig = [];
    return;
end
    
    fig = figure('Name',namestring);
%        colormap(gray);
name_seg = ['segm. ',namestring];


% Show slices through the point defined by (x,y,z)
[i,jslice,kslice] = xyz2ijk(x,y,z,xx,yy,zz);


subplot(2,4,1);
show_slice(Ibw,xx,yy,zz,kslice,'xy',name_seg);
subplot(2,4,5);
show_slice(I,xx,yy,zz,kslice,'xy',namestring);
plot(x,y,'xr');
%
jslice= round(size(Ibw,2)/2);
subplot(2,4,2);
show_slice(Ibw,xx,yy,zz,jslice,'xz',name_seg);
subplot(2,4,6);
show_slice(I,xx,yy,zz,jslice,'xz',namestring);
plot(x,z,'xr');
%
subplot(2,4,3);
show_maxintproj(Ibw,xx,yy,zz,'xy',name_seg);
subplot(2,4,7);
show_maxintproj(I,xx,yy,zz,'xy',namestring);
plot(x,y,'xr');
%
subplot(2,4,4);
show_maxintproj(Ibw,xx,yy,zz,'xz',name_seg);
subplot(2,4,8);
show_maxintproj(I,xx,yy,zz,'xz',namestring);
plot(x,z,'xr');
