%%  find_duplicates: find duplicated vector entries or matrix rows
%%%
%%% Output variables:
%%%
%%% i1 = vector of indices of the first duplicated element in A for each set of
%%% duplicated elements (if A is a matrix, this is the index of the first
%%% row for each set of duplicated rows)
%%%
%%% Ndup = vector of the same size as i1. Ndup(i) is the number of
%%% entries equal to i1(i) in A (is >=2 by definition)
%%%
%%% ia = cell array of the same length as i1 and Ndup.
%%% ia{i} is a vector of length Ndup(i) containing the indices of ALL
%%% elements or rows in A equal to i1(i)
%%%
%%% m1 = as returned by [B, m1, n] = unique(A,..,'first');
%%%
%%% Ch. Zimmer, Aug. 2008


function [i1, Ndup, ia, m1] = find_duplicates(A)

if isvector(A)
    [B, m1, n] = unique(A,'first');
    [B, m2, n] = unique(A,'last');
else
    [B, m1, n] = unique(A,'rows','first');
    [B, m2, n] = unique(A,'rows','last');
end

i1 = m1(find(m2~=m1));

if isempty(i1)
    Ndup = []; ia = [];
else
    Nduptot = length(i1);

    for i = 1:Nduptot
        iaux = find(m1 == i1(i));
        aux = find(n == iaux);
        ia{i} = aux;
        Ndup(i) = length(aux);
        if Ndup(i)<2
            A
            m1
            m2
            n
            i
            error('this should not happen!');
        end
    end

    Ndup = Ndup';
    ia = ia';

end

end




