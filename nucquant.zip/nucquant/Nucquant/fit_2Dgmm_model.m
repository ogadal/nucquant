%%% this function fits the parameter of a 2D gaussian mixture model to fit the
%%% input image
%%%
%%% I = input image
%%% (xx,yy) are vectors containing the x,y axis coordinates in microns
%%% (xci0,yci0) are the initial coordinates of the spots used as starting point for
%%% the fitting procedure,
%%% Ai0 are the initial amplitudes,
%%% b0 is the initial value of the background.
%%% - method is either '1-step' or '2-step'. In the latter case, the
%%% optimization on the amplitudes of the gaussians is done first by
%%% holding the positions constant
%%%
%%% LATER: IL FAUDRA TENIR COMPTE DANS L'OPTIMISATION DES CONTRAINTES
%%% DE POSITIVITE SUR LES AMPLITUDES ET LE FOND!

function [xci,yci,Ai,b] = fit_2Dgmm_model(I,xx,yy,xci0,yci0,Ai0,b0,method)

global Ai_fixed;
global b_fixed;
global xci_fixed;
global yci_fixed;
global zci_fixed;

verbose = 0;

if verbose
    disp(['fit_thomann_model: initial parameters are:']);
    disp(['xc0  yc0 A0, b0=',num2str(b0)]);
    disp([xci0 yci0 Ai0]);
end

%%% make one big vector containing the x,y of all pixels in the image (this
%%% is required by the Matlab function lsqcurvefit)
%%% the length of this vector is twice the number of pixels
positions = xy2positions(xx,yy);

%%% make one big vector out of the image intensities
intensities = I(:);

%%% make one vector out of the initial model parameters
param0 = gmm2Dparameter2vector(xci0,yci0,Ai0,b0);

%%% lower bounds and upper bounds of the parameter
    paramlb = gmm2Dparameter2vector(xci0*0+xx(1),yci0*0+yy(1),Ai0*0,0);
    paramub = gmm2Dparameter2vector(xci0*0+xx(end),yci0*0+yy(end),Ai0*Inf,Inf);

if 1==0
    options = optimset('Display','iter','TolFun',1e-20,'TolX',1e-20,'Diagnostics','on');
else
    options = optimset('Display','off');
    %     options = [];
end
% disp('starting least squares minimization ...');
switch method
    case '1-step'
        [param,resnorm,residual] = lsqcurvefit(@gaussian_2D_mixture_model_wrapper,param0,positions,intensities,paramlb,paramub,options);
        if verbose
            disp(['lsqcurvefit returns resnorm=',num2str(resnorm)]);
        end

    case '2-step' % Do the optimization on the two different types of parameters (positions and amplitudes) separately !!!!
        error('Not implemented yet !!!');
        % First optimize on the amplitudes
        param0 = gmm_2D_positions_parameter2vector(xci0,yci0);
        [param,resnorm,residual] = lsqcurvefit(@gaussian_2D_positions_wrapper,param0,positions,intensities,[],[],options);
        % TO BE WRITTEN !!!!!!!!!!!!
end

%%% extract the fitted model parameters from the vector returned by
%%% lsqcurvefit
[xci,yci,Ai,b] = vector2gmm2Dparameter(param);
if verbose
    disp(['final parameters are :']);
    disp(['xc  yc A, b=',num2str(b)]);
    disp([xci yci Ai]);
end
