%%% Similar to fit_sphere_radius, but here the sphere is replaced by an
%%% ellipsoid centered on (xc,yc,zc) and aligned with the 3 coordinates axes.
% % % The unknown parameters are the three half-axes of the ellipsoid:
% % % Rx, Ry and Rz

function [Rx,Ry,Rz,mean_dist,residual,exitflag] = fit_ellipsoid_3param(xi,yi,zi,wi,xc,yc,zc)


% Initial parameter guess for the fit
Rx0 = max(abs(xi-xc));
Ry0 = max(abs(yi-yc));
Rz0 = max(abs(zi-zc));
ellipsoid_0 = [Rx0 Ry0 Rz0];

% If weight vector is not empty, duplicate points according to their relative
% weights
if ~isempty(wi)
    [xi yi zi] = clone_points(xi,yi,zi,wi);
end


% Do the fit
[ellipsoid,aux,residual,exitflag] = lsqnonlin(@(ellipsoid) distance_to_ellipsoid_short(xi-xc,yi-yc,zi-zc,ellipsoid), ellipsoid_0);
Rx = ellipsoid(1);
Ry = ellipsoid(2);
Rz = ellipsoid(3);

% Compute distances of original points to the fitted ellipsoid
if 1==0
    d_points_ellipsoid = abs(distance_point2ellipsoid(xi-xc,yi-yc,zi-zc,Rx,Ry,Rz,'algebraic'));
else
    d_points_ellipsoid = abs(distance_point2ellipsoid_algebraic(xi-xc,yi-yc,zi-zc,Rx,Ry,Rz));
end

mean_dist = mean(d_points_ellipsoid);

end

%%%

function d= distance_to_ellipsoid_short(xi,yi,zi,ellipsoid)

Rx = ellipsoid(1);
Ry = ellipsoid(2);
Rz = ellipsoid(3);

d = distance_to_ellipsoid(xi,yi,zi,Rx,Ry,Rz);

end

% Compute distances of points to the axes-aligned ellipsoid centered on (0,0,0)
% and with the three half axes (Rx,Ry,Rz)
% (xi,yi,zi) are three arrays containing the x,y,z coordinates of the
% points
function d = distance_to_ellipsoid(xi,yi,zi,Rx,Ry,Rz)

N = length(xi);

for i=1:N
    x = xi(i);
    y = yi(i);
    z = zi(i);

    d(i) = distance_point2ellipsoid_algebraic(x,y,z,Rx,Ry,Rz);
end

end