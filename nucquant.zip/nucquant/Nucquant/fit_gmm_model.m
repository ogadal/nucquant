%%% this function fits the parameter of a 3D gaussian mixture model to fit the
%%% input image
%%%
%%% I = input image
%%% (xx,yy,zz) are vectors containing the x,y,z axis coordinates in microns
%%% (xci0,yci0,zci0) are the initial coordinates of the spots used as starting point for
%%% the fitting procedure,
%%% Ai0 are the initial amplitudes,
%%% b0 is the initial value of the background.
%%% - method is either '1-step' or '2-step'. In the latter case, the
%%% optimization on the amplitudes of the gaussians is done first by
%%% holding the positions constant
%%%
%%% LATER: IL FAUDRA TENIR COMPTE DANS L'OPTIMISATION DES CONTRAINTES
%%% DE POSITIVITE SUR LES AMPLITUDES ET LE FOND!

function [xci,yci,zci,Ai,b] = fit_gmm_model(I,xx,yy,zz,xci0,yci0,zci0,Ai0,b0,method)

global Ai_fixed;
global b_fixed;
global xci_fixed;
global yci_fixed;
global zci_fixed;

verbose = 0;

if verbose
    disp(['fit_thomann_model: initial parameters are:']);
    disp(['xc0  yc0 zc0 A0, b0=',num2str(b0)]);
    disp([xci0 yci0 zci0 Ai0]);
end

%%% make one big vector containing the x,y,z of all voxels in the image (this
%%% is required by the Matlab function lsqcurvefit)
%%% the length of this vector is 3 times the number of voxels
positions = xyz2positions(xx,yy,zz);

%%% make one big vector out of the image intensities
intensities = I(:);

%%% make one vector out of the initial model parameters
param0 = gmmparameter2vector(xci0,yci0,zci0,Ai0,b0);

%%% lower bounds and upper bounds of the parameter
if length(zz)>1
    paramlb = gmmparameter2vector(xci0*0+xx(1),yci0*0+yy(1),zci0*0+zz(1),Ai0*0,0);
    paramub = gmmparameter2vector(xci0*0+xx(end),yci0*0+yy(end),zci0*0+zz(end),Ai0*Inf,Inf);
else
    paramlb = gmmparameter2vector(xci0*0+xx(1),yci0*0+yy(1),zci0*0-Inf,Ai0*0,0);
    paramub = gmmparameter2vector(xci0*0+xx(end),yci0*0+yy(end),zci0*0+Inf,Ai0*Inf,Inf);
end

if 1==0
    options = optimset('Display','iter','TolFun',1e-20,'TolX',1e-20,'Diagnostics','on');
else
    options = optimset('Display','off');
    %     options = [];
end
% disp('starting least squares minimization ...');
switch method
    case '1-step'
        [param,resnorm,residual] = lsqcurvefit(@gaussian_mixture_model_wrapper,param0,positions,intensities,paramlb,paramub,options);
        if verbose
            disp(['lsqcurvefit returns resnorm=',num2str(resnorm)]);
        end

    case '2-step' % Do the optimization on the two different types of parameters (positions and amplitudes) separately !!!!
        error('Not implemented yet !!!');
        % First optimize on the amplitudes
        param0 = gmm_positions_parameter2vector(xci0,yci0,zci0);
        [param,resnorm,residual] = lsqcurvefit(@gaussian_positions_wrapper,param0,positions,intensities,[],[],options);
        % TO BE WRITTEN !!!!!!!!!!!!
end

%%% extract the fitted model parameters from the vector returned by
%%% lsqcurvefit
[xci,yci,zci,Ai,b] = vector2gmmparameter(param);
if verbose
    disp(['final parameters are :']);
    disp(['xc  yc zc A, b=',num2str(b)]);
    disp([xci yci zci Ai]);
end
