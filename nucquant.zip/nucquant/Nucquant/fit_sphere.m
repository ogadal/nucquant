%%% Fit a sphere to a set of points (xi,yi,zi), optionnally using weights wi
%%%
%%% xbounds is a 2-element vector specifying the lower and upper bound of
%%% possible values for the x-coordinate of the sphere center, and
%%% similarly for ybounds and zbounds.
%%%
%%% mean_dist is the mean distance of the input points to the fitted sphere

function [xc,yc,zc,R,mean_dist,residual,exitflag] = fit_sphere(xi,yi,zi,wi,xbounds,ybounds,zbounds);


%  Initial parameter guess for the fit
xc0 = median(xi);
yc0 = median(yi);
zc0 = median(zi);

R0 = max([max(xi)-min(xi) max(yi)-min(yi) max(zi)-min(zi)])/2;
sphere0 = [xc0; yc0; zc0; R0];

% If weight vector is not empty, duplicate points according to their relative
% weights
if ~isempty(wi)
   [xi yi zi] = clone_points(xi,yi,zi,wi);
end


% Get upper and lower bounds fot the sphere parameters
sphere_lb = [min(xbounds) min(ybounds) min(zbounds) 0];
sphere_ub = [max(xbounds) max(ybounds) max(zbounds) Inf];

% Do the fit
[sphere,resnorm,residual,exitflag] = lsqnonlin(@(sphere) distance_to_sphere(xi,yi,zi,sphere), sphere0,sphere_lb,sphere_ub);

% Return fitted sphere parameter
xc = sphere(1);
yc = sphere(2);
zc = sphere(3);
R = sphere(4);

% Compute distances of original points to the fitted sphere 
aux = distance3d(xi,yi,zi,xc,yc,zc);
d_points_sphere = abs(aux-R);
mean_dist = mean(d_points_sphere);



% Compute distances of points to a sphere (for use with fit_sphere.m)
% (xi,yi,zi) are three arrays containing the x,y,z coordinates of the
% points
% sphere is a 4x1 array containing the sphere parameters, i.e. the center (xc,yc,zc) and the radius R:
% sphere(1) = xc 
% sphere(2) = yc
% sphere(3) = zc
% sphere(4) = R
%
function d = distance_to_sphere(xi,yi,zi,sphere)


N = length(xi);
% sphere center
xc = sphere(1);
yc = sphere(2);
zc = sphere(3);
% sphere radius
R = sphere(4);

d = distance_to_sphere_long(xi,yi,zi,xc,yc,zc,R);