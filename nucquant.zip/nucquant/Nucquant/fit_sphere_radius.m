%%% Similar to fit_sphere, but here the center of the sphere is given by (xc,yc,zc), and
%%% only the radius is fitted.

function [R,mean_dist,residual,exitflag] = fit_sphere_radius(xi,yi,zi,wi,xc,yc,zc);


%  Initial parameter guess for the fit
R0 = max([max(xi)-min(xi) max(yi)-min(yi) max(zi)-min(zi)])/2;

% If weight vector is not empty, duplicate points according to their relative
% weights
if ~isempty(wi)
   [xi yi zi] = clone_points(xi,yi,zi,wi);
end


% Do the fit
[R,resnorm,residual,exitflag] = lsqnonlin(@(R) distance_to_sphere_long(xi,yi,zi,xc,yc,zc,R),R0);

% Compute distances of original points to the fitted sphere 
aux = distance3d(xi,yi,zi,xc,yc,zc);
d_points_sphere = abs(aux-R);
mean_dist = mean(d_points_sphere);

