%% Return the folder hierarchy downstream of the input folder and including
%% this folder
function [top_folder folders_rel_name] = folder_hierarchy(fullfoldername);

dir0 = cd;

[top_folder, short_folder_name, ext] = fileparts(fullfoldername);

cd(fullfoldername);
cd ..;
subfolders = all_subfolders(short_folder_name);

folders{1} = short_folder_name;
folders_rel_name = [folders all_subfolders(folders{1})];

cd(dir0);

end

%% Return all subfolders
% the input argument "folder" can be the full path of the input folder or the simple folder
% name.
% the output folder names will contain the relative path of all folders downstream
% of "folder"
%
function asf = all_subfolders(folder)

if ~isdir(folder)
    error(['"',folder,'" does not seem to be a folder !']);
end


if isempty(folder)
    asf = [];
else
    if ~isdir(folder)
        warning(['"',folder,' is not a directory !']);
        asf = [];
    else
        dsf = direct_subfolders(folder);

        if isempty(dsf)
            asf = [];
        else
            subsubf = [];
            for i=1:length(dsf)
                current_dsf = dsf{i};
                asf1 = all_subfolders(current_dsf);
                if ~isempty(asf1)
                    subsubf = [subsubf asf1];
                end
            end
            asf = [dsf subsubf];
        end
    end

end

end

%% Return direct subfolders

function dsf = direct_subfolders(folder)

aux = dir(folder);
ii = find([aux.isdir]==1); % this selects the subfolders
if ~isempty(ii)
    i=1;
    for j=1:length(ii)
        aux2 = aux(ii(j)).name;
        if aux2(1)~='.',
            dsf{i} = fullfile(folder,aux2);
            i=i+1;
        end
    end
    if ~exist('dsf','var')
%         disp('There seems to be no valid subfolder here !');
        dsf = [];
    end
else
%     disp('No subfolder here !');
    dsf = [];
end

end
