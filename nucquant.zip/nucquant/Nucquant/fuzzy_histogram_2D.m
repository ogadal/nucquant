%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute a 2D fuzzy histogram from "fuzzy positions" in the plane
%
% Ipd is an image containing blurred positions
% H is the histogram matrix
% Xbinedges and Ybinedges are vectors containing the x and y coordinates of
% the grid lines that define the histogram bins
%
% if grid_type is 'uniform', the grid is uniformly spaced, with all bins of
% constant size (dx,dy)
% if grid_type is 'volume-preserving', the grid is non-uniform, with a non-constant y-
% dimension of bins. The y-dimension of the bins is calculated such that the volume of space
% projected in each bin (by cylindrical projection around the x-axis) is
% constant.
%
function [H,Xbinedges,Ybinedges] = fuzzy_histogram_2D(Ipd,xx1,yy1,dx,dy,grid_type)

xxcenters = (xx1(1:end-1)+xx1(2:end))/2;
yycenters = (yy1(1:end-1)+yy1(2:end))/2;

if (length(yy1)~=size(Ipd,1)+1) || (length(xx1)~=size(Ipd,2)+1)
    whos
    error('Sizes of Ipd, xx1 and yy1 do not match !');
end

xmin = xx1(1);
xmax = xx1(end);
ymin = yy1(1);
ymax = yy1(end);

Xbinedges = floor(xmin/dx)*dx:dx:ceil(xmax/dx)*dx;
Nbinsx = length(Xbinedges)-1;

if grid_type
    grid = 'volume-preserving';
else
    grid = 'uniform';
end

if strcmp(grid,'uniform') % equally spaced bins
    Ybinedges = floor(ymin/dy)*dy:dy:ceil(ymax/dy)*dy;
    Nbinsy = length(Ybinedges)-1;
elseif strcmp(grid,'volume-preserving') % bin sizes are adapted to take into account cylindrical projection effect
    aux1  = ceil((ymax/dy)^2);
    aux2 = ceil((ymin/dy)^2);
    Ybinedges = dy*[-sqrt(aux2:-1:0) sqrt(1:aux1)]';
    Nbinsy = length(Ybinedges)-1;
else
    error(['this value of grid (=',grid,') is not valid !']);
end

H = NaN(Nbinsy,Nbinsx);

for iy = 1:Nbinsy
    iy1 = find(yycenters>=Ybinedges(iy) & yycenters<Ybinedges(iy+1));
    %     iy1leftin = iy1(1);
    %     iy1rightin = iy1(end);
    %     yy1_leftin = yy1(iy1leftin);
    %     yy1_rightin = yy1(iy1rightin);
    %     yy1_leftout = yy1(iy1leftin-1);
    %     yy1_rightout = yy1(iy1rightin+1);
    %
    %     fract_left = ( yy1_leftin - Ybinedges(iy))/( yy1_leftin - yy1_leftout )
    %     fract_right = ( Ybinedges(iy+1) - yy1_rightin)/( yy1_rightout - yy1_rightin )

    DeltaY = Ybinedges(iy+1)-Ybinedges(iy);

    for ix = 1:Nbinsx
        ix1 = find( xx1 >= Xbinedges(ix) & xx1 < Xbinedges(ix+1) );

        DeltaX = Xbinedges(ix+1) - Xbinedges(ix);

        clear aux;
        ix1 = ix1(ix1<=size(Ipd,2)); % CHECK THIS
        iy1 = iy1(iy1<=size(Ipd,2)); 
        
            aux = Ipd(iy1,ix1);

        % TODO: this does not account for small pixels that overlap the
        % grid of the histogram !!!!!! IMPROVE THIS LATER !!!

        H(iy,ix) = sum(aux(:));  %* DeltaX * DeltaY;
    end
end


