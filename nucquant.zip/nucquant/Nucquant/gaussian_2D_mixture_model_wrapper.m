% this auxiliary function is basically an interface of the function
% 'gaussian_mixture_model'. ........
function model_intensities = gaussian_2D_mixture_model_wrapper(parametervector,positionvector)

[xci,yci,Ai,b] = vector2gmm2Dparameter(parametervector);

[x,y] = positionvector2xy(positionvector);

aux   = gaussian_2D_mixture_model(x,y,xci,yci,Ai,b);

model_intensities = aux;