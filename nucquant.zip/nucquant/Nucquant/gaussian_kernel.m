% 3D Gaussian kernel with different standard deviations in horizontal
% and vertical directions
%
% if normalization_method == 'peak', then normalize the kernel to a peak
% value of 1
% if normalization_method == 'energy', then normalize the kernel to a total
% sum (energy) of 1



function kernel = gaussian_kernel(sigma_xieta,sigma_zeta,normalization_method)

nz = ceil(3*sigma_zeta); % at x = 3 sigma, exp(-x*x/(2*sigma*sigma)) = exp(-4.5) = 0.0111
nxy = ceil(3*sigma_xieta);

sigma2_xieta = sigma_xieta*sigma_xieta;
sigma2_zeta = sigma_zeta*sigma_zeta;
aux = zeros(2*nxy+1,2*nxy+1,2*nz+1);

for i = -nxy:nxy
    for j = -nxy:nxy
        for k = -nz:nz
            r2 = i.*i + j.*j;
            z2 = k.*k;
            aux(i+nxy+1,j+nxy+1,k+nz+1) = exp( -0.5 * (r2/sigma2_xieta + z2/sigma2_zeta) );
        end
    end
end

% normalize in the manner specified by the input argument 'normalization_method'
switch normalization_method
    
    case 'peak'
        aux0 = max(aux(:));
        
    case 'energy'
        aux0 = sum(aux(:));
        
    otherwise
        error(['normalization_method = ',normalization_method,' is not a valid option in gaussian_kernel !']);
        
end

kernel = aux/aux0;
