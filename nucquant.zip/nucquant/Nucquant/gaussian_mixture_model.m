% Gaussian 3D mixture model
%
% x, y and z  are 1D arrays containing the coordinates of the points where the model is evaluated
% xci, yci, zci  are 1D arrays containing the coordinates of the center of the
% Gaussians
% A is a 1D array containing the amplitude of each Gaussian
% b is the constant background value
%
% the output M has the same dimension as x

function M = gaussian_mixture_model(x,y,z,xci,yci,zci,Ai,b)

global sigma_xy2;
global sigma_z2;
global Ngmm; % number of gaussians in the Gaussian mixture model

% make sure number of variables is correct
if (length(xci)~=Ngmm) || (length(yci)~=Ngmm) || (length(zci)~=Ngmm) || (length(Ai)~=Ngmm)
    Ngmm
    xci
    yci
    zci
    Ai
    error('gaussian_mixture_model: length(xci or yci or zc or Aii)~=Ngmm !');
end

if isempty(sigma_xy2) || isempty(sigma_z2)
    error('gaussian_mixture_model: sigma_xy2 or sigma_z2 are empty !');
end

if 1==1
    aux = b*ones(size(x));
else %%% TEMPORARY
    aux = zeros(size(x));
end

for ig=1:Ngmm
    xc = xci(ig);
    yc = yci(ig);
    zc = zci(ig);
    aux = aux + Ai(ig) * exp( -0.5*(((x-xc).^2+(y-yc).^2 )/sigma_xy2 + (z-zc).^2/sigma_z2)  );
end

if 1==0 % DEBUG
    mean(x)
    mean(y)
    mean(z)
    xci
    yci
    zci
    Ai
    b
    Ngmm
    max(aux)
    stop;
end

M = aux;