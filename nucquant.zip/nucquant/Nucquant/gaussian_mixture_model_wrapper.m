% this auxiliary function is basically an interface of the function
% 'gaussian_mixture_model'. ........
function model_intensities = gaussian_mixture_model_wrapper(parametervector,positionvector)

[xci,yci,zci,Ai,b] = vector2gmmparameter(parametervector);

[x,y,z] = positionvector2xyz(positionvector);

aux   = gaussian_mixture_model(x,y,z,xci,yci,zci,Ai,b);

model_intensities = aux;