% this function scans all vertical lines in the 3D image I3d and returns
% the depth z of the two local maxima for each line

function [z1 z2 I1 I2] = get_maxima_along_lines(I3d,zz);

w = size(I3d,1);
h = size(I3d,2);
d = size(I3d,3);

k1 = NaN(w,d);
k2 = NaN(w,d);
for i=1:w
    for j=1:h
        line = squeeze(I3d(i,j,:));
        [km1, km2, Im1, Im2] = two_local_max(line);
        zm1 = i2x(km1,zz);
        zm2 = i2x(km2,zz);
        z1(i,j) = zm1;
        z2(i,j) = zm2;
        I1(i,j) = Im1;
        I2(i,j) = Im2;
    end
end

% TODO: use intensity weighting around the local maximum pixel to get
% subpixel accuracy !