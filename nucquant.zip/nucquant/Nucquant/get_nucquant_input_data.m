function [mat_file_rel_path, dir_in] = get_nucquant_input_data(dir_def);

%% Get list of folder containing input data
dir_in=uigetdir(dir_def,'Select the directory containing ALL the INPUT data');%=cd;
cd(dir_in);

disp('Retrieving folder hiearchy ...');
[top_folder, folders] = folder_hierarchy(dir_in);

N_folders = length(folders);
disp(['Folder "',num2str(dir_in),'" has ',num2str(N_folders),' subfolders (including itself):']);
if 1==0
for i=1:N_folders,
    disp(['Folder #',num2str(i),': ',folders{i}]);
end
end

%% Get the entire list of crop regions (nuclei) to be processed
disp('Retrieving the list of files to be processed ...');
[N_per_folder, Ntot, mat_file_rel_path] = valid_mat_files_from_folders(folders,top_folder);

for i=1:N_folders
    disp(['N=',num2str(N_per_folder(i)),' valid files found in folder #',num2str(i),': ',folders{i}]);
end
disp(['Total: N=',num2str(Ntot),' valid files found in ',num2str(sum(N_per_folder>0)),' folders.']);

% allmatfiles = [];
% imatfiles = 0;
% for i_folder = 1:N_folders
%     folder = folders{i_folder};
%     folder2 = fullfile(folder,'cropped_matlab');
%     cd(dir_in); if exist(folder2,'file'), folder = folder2; end;
%     if ~isempty(folder), cd(folder); end
%     %     disp(['====Moved to folder ',folder,'(folder ',num2str(i_folder),' out of ',num2str(N_folders),')']);
%     % Retrieve list of relevant *.mat input files
%     mat_files = valid_mat_files(folder);
%     Nmatfiles = size(mat_files,1);
%     if Nmatfiles==0
%         disp(['Folder ',folder,' does not contain any file to be processed !']);
%     else
%         for imat = 1:Nmatfiles
%             imatfiles = imatfiles + 1;
%             mat_file_rel_path{imatfiles} = fullfile(dir_in,folder,mat_files(imat).name);
%         end
%     end
% end
% if ~exist('mat_file_rel_path','var')
%     mat_file_rel_path = [];
% end

end

%% Return list of valid mat-files from folder list
function [N_per_folder, Ntot, files] = valid_mat_files_from_folders(folders,top_folder)

files = [];

Nfolders = length(folders);
for i=1:Nfolders
    currentfolder = folders{i};
    [N_per_folder(i), files_currentfolder] = valid_mat_files(currentfolder,top_folder);
    files = [files files_currentfolder];
end

Ntot = sum(N_per_folder);

end

%% Get valid mat-files from folder

function [N, files] = valid_mat_files(folder,top_folder)

aux = dir(fullfile(top_folder,folder,'*t0001.mat'));

if isempty(aux)
    aux = dir(fullfile(top_folder,folder,'*_out.mat'));
end
% if isempty(aux)
%     aux = dir(fullfile(folder,'*.mat'));
% end
if isempty(aux)
    N=0;
    files = [];
else
    N = length(aux);
    for imat = 1:N
        files{imat} = fullfile(top_folder,folder,aux(imat).name);
    end

    N = length(files);
end

end