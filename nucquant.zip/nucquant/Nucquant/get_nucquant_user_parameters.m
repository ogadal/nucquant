% this function should now be obsolete thanks to the GUI "nucquant_gui"
function parameters = get_nucquant_user_parameters(parameters);

% Ask user if figures should be saved
answer = questdlg('Save figures for each nucleus (slower) ?','','Yes','No','Yes');
if strcmp(answer,'No')
    parameters.save_figures = 'n';
else
    parameters.save_figures = 'y';
end

% Ask user if nucleolus should be analyzed
answer = questdlg('Analyse nucleolus if exists (slower) ?','','Yes','No','Yes');
if strcmp(answer,'No')
    parameters.process_nucleolus = 'n';
else
    parameters.process_nucleolus = 'y';
end

% Ask user if NPC clusters should be detected
answer = questdlg('Detect NPC clusters (slower) ?','','Yes','No','Yes');
if strcmp(answer,'No')
    parameters.detect_NPC = 'n';
else
    parameters.detect_NPC = 'y';
end

% Ask user if nuclear envelope should be analyzed
if parameters.detect_NPC == 'n'
    parameters.detect_envelope = 'n';
else
    answer = questdlg('Detect nuclear envelope (slower) ?','','Yes','No','Yes');
    if strcmp(answer,'No')
        parameters.detect_envelope = 'n';
    else
        parameters.detect_envelope = 'y';
    end
end

% Ask user how many genes are present
answer = questdlg('How many bNPCs per nucleus?','','1','2','1');
parameters.nb_bNPCs = answer;

% Request the type of nuclear staining
answer = questdlg('How is the nucleus stained ?','','Nuclear envelope','Nucleoplasm','Nuclear envelope');
parameters.nuclear_staining = answer;

% Ask user if tabular output (text or Excel file) should be generated
if 1==0
    answer = questdlg('Generate tabular output ?','','Yes','No','Yes');
    if strcmp(answer,'No')
        parameters.save_tabular = 'n';
    else
        parameters.save_tabular = 'y';
        if ispc
            answer = warndlg('Please make sure that Excel is not running');
        end
    end
else
    parameters.save_tabular = 'n';
end