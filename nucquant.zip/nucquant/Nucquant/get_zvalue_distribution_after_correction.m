% Get the distribution of the new NPC position along z axis. the y value is
% the relative distance, the x value is the delta z of NPC and nucleus
% center.

clc; close all, clear all;
% Pick the input data
a=dir('QC_OKcorrect*');
inputfilename = a.name;
inputfolder = cd;
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
disp(aux);
wb = waitbar(0,aux);
load(inputfilename);
if ishandle(wb), delete(wb); end
parameters.inputfilename = inputfilename;
parameters.inputfolder = inputfolder;

clear *_all;

i=length(output);

for j=1:i
    % import the nuclei center and NPc position
    xcnucleus = [output.xn];
    ycnucleus = [output.yn];
    zcnucleus = [output.zn];
    xNPC = [output.xNPC];
    yNPC = [output.yNPC];
    zNPC = [output.zNPC];
    nbNPC = [output.nbNPC];
    % Import the half-axies of the nucleus ellipsoid
    Rx=[output.Rxfe];
    Ry=[output.Ryfe];
    Rz=[output.Rzfe];
    
    disp('computing detax, detay and detaz between NPC and nucleus center including the dist_NPC_nucleus_relative...');
    a=sum(nbNPC(1:(j-1)))+1;b=sum(nbNPC(1:j)); % extract coordinates of NPCs to their corresponding nuclei
    output(j).dist_NPC_nucleus_centroid=distance3d(xNPC(a:b),yNPC(a:b),zNPC(a:b),xcnucleus(j),ycnucleus(j),zcnucleus(j));
    output(j).R=[Rx(j),Ry(j),Rz(j)];
    output(j).dist_NPC_nucleus_centroid_relative=output(j).dist_NPC_nucleus_centroid/mean(output(j).R);
    output(j).dist_NPC_nucleus_x=xNPC(a:b)-xcnucleus(j);
    output(j).dist_NPC_nucleus_y=yNPC(a:b)-ycnucleus(j);
    output(j).dist_NPC_nucleus_z=zNPC(a:b)-zcnucleus(j);
end

% Plot the origin figure
figure('Name','origin data analysis');
subplot(1,3,1);
x=[output.dist_NPC_nucleus_x];
y=[output.dist_NPC_nucleus_centroid_relative];
xlabel('deltaXNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
plot(x,y,'r.','MarkerSize',4);
legend(['N=',num2str(length(x))]);

subplot(1,3,2);
x=[output.dist_NPC_nucleus_y];
y=[output.dist_NPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaYNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);

subplot(1,3,3);
x=[output.dist_NPC_nucleus_z];
y=[output.dist_NPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaZNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);
    