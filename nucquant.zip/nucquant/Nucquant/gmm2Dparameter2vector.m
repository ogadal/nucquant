function pv = gmm2Dparameter2vector(xci,yci,Ai,b)

pv = [xci(:);yci(:);Ai(:);b];
