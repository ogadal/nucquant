function pv = gmmparameter2vector(xci,yci,zci,Ai,b);

pv = [xci(:);yci(:);zci(:);Ai(:);b];
