%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute a 2D histogram of (x,y) points in the plane
%
% H is the histogram matrix
% Xbinedges and Ybinedges are vectors containing the x and y coordinates of
% the grid lines that define the histogram bins
%
% if volume_preserving grid is 0, the grid is uniformly spaced, with all bins of
% constant size (dx,dy)
% if volume_preserving is 1, the grid is non-uniform, with a non-constant y-
% dimension of bins. The y-dimension of the bins is calculated such that the volume of space 
% projected in each bin (by cylindrical projection around the x-axis) is
% constant.
%
function [H,Xbinedges,Ybinedges] = histogram_2D(x,y,dx,dy,xmin,ymin,xmax,ymax,volume_preserving)

Xbinedges = floor(xmin/dx)*dx:dx:ceil(xmax/dx)*dx;
Nbinsx = length(Xbinedges)-1;

if volume_preserving
    grid = 'volume-preserving';
else
    grid = 'uniform';
end

if strcmp(grid,'uniform') % equally spaced bins
    Ybinedges = floor(ymin/dy)*dy:dy:ceil(ymax/dy)*dy;
    Nbinsy = length(Ybinedges)-1;
elseif strcmp(grid,'volume-preserving') % bin sizes are adapted to take into account cylindrical projection effect
    aux1  = ceil((ymax/dy)^2);
    aux2 = ceil((ymin/dy)^2);
    Ybinedges = dy*[-sqrt(aux2:-1:0) sqrt(1:aux1)]';
    Nbinsy = length(Ybinedges)-1;
else
    error(['this value of grid (=',grid,') is not valid !']);
end

H = NaN(Nbinsy,Nbinsx);

for ix = 1:Nbinsx
    ix1 = find(x>=Xbinedges(ix) & x<Xbinedges(ix+1));
    x1 = x(ix1);
    y1 = y(ix1);
    for iy = 1:Nbinsy
        clear aux;
        aux = find(y1>=Ybinedges(iy) & y1<Ybinedges(iy+1));
        H(iy,ix) = length(aux);
    end
end


