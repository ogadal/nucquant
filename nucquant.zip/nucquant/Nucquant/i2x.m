
% Convert index i into x-coordinate on a x-axis specified by xx

function x = i2x(i,xx)

Nx = length(xx);


ii=1:Nx;

if i==round(i)
    x = xx(i);
else
    x = interp1(ii,xx,i);
end
