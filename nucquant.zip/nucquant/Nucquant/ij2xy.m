% converts 2D matrix  indices into spatial coordinates
%
% Usage: ij2xy(i,j,xx,yy)  or  ij2xy(i,j,xx,yy,Nx,Ny)


function [x,y] = ij2xy(varargin)

i = varargin{1};
j = varargin{2};
xx = varargin{3};
yy = varargin{4};

if length(varargin)==6
    Nx = varargin{5};
    Ny = varargin{6};
else
    Nx = length(xx);
    Ny = length(yy);
end


ii=1:Nx;
jj = 1:Ny;

if i==round(i)
    x = xx(i);
else
    x = interp1(ii,xx,i);
end

if j==round(j)
    y = yy(j);
else
    y = interp1(jj,yy,j);
end