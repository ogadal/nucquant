% converts 3D matrix  indices into spatial coordinates
%
% Usage: ijk2xyz(i,j,k,xx,yy,zz)  or  ijk2xyz(i,j,k,xx,yy,zz,Nx,Ny,Nz)


function [x,y,z] = ijk2xyz(varargin)

i = varargin{1};
j = varargin{2};
k = varargin{3};
xx = varargin{4};
yy = varargin{5};
zz = varargin{6};

if length(varargin)==9
    Nx = varargin{7};
    Ny = varargin{8};
    Nz = varargin{9};
else
    Nx = length(xx);
    Ny = length(yy);
    Nz = length(zz);
end


ii=1:Nx;
jj = 1:Ny;
kk = 1:Nz;

if i==round(i)
    x = xx(i);
else
    x = interp1(ii,xx,i);
end

if j==round(j)
    y = yy(j);
else
    y = interp1(jj,yy,j);
end


if k==round(k)
    z = zz(k);
else
    z = interp1(kk,zz,k);
end
