% Crop a 3D image

function Icrop = imcrop3d(I3d,crop_rectangle)


Nz = size(I3d,3);
Nchannels = size(I3d,4);

aux = imcrop(squeeze(I3d(:,:,1,1)),crop_rectangle);

% pre-allocate for speed
Icrop = zeros(size(aux,1),size(aux,2),Nz,Nchannels);

for ich = 1:Nchannels

    if (ich>1) || (ich>2)
        aux = imcrop(squeeze(I3d(:,:,1,ich)),crop_rectangle);
    end

    Icrop(:,:,1,ich) = aux;

    % crop the slices
    for iz=2:Nz
        Icrop(:,:,iz,ich) = imcrop(squeeze(I3d(:,:,iz,ich)),crop_rectangle);
    end


end