% Compute the convolution of the 3-dimensional image I with a 3D
% double-gaussian convolution kernel of mean square deviations sigx in the
% x and y direction and sigz in the z-direction
function If = imfilter3d_doublegaussian(I,sigx,sigz)


n = size(I,1);
m = size(I,2);
p = size(I,3);


zk = -ceil(3*sigz):ceil(3*sigz);
nzk = length(zk);
nzk2 = (nzk-1)/2;

xk = -ceil(3*sigx):ceil(3*sigx);
nxk = length(xk);
nxk2 = (nxk-1)/2;

if 1==1
    kz = exp(-zk.^2/(2*sigz^2));
     kz = kz/sum(kz);
    kx = exp(-xk.^2/(2*sigx^2));
     kx = kx/sum(kx);
else
    kx = [1 2 3 2 1];
    kz = kx;
end

% Convolution along the x - dimension
aux = imfilter1d(I,kx,1);

% Convolution along the y - dimension
aux = imfilter1d(aux,kx,2);

% Convolution along the z - dimension
If = imfilter1d(aux,kz,3);


% Compute the convolution of the 3-dimensional image I with the 1D convolution kernel h
% along the dimension dim
function If = imfilter1d(I,h, dim);

if ndims(I)~=3
    error('I must have 3 dimensions in imfilter1d!');
end

nh = length(h);
nh2 = (nh-1)/2;

padsize = [0 0 0];
padsize(dim) = nh2;

Ipadded = padarray(I,padsize,'replicate','both');

Ipaddedfiltered = filter(h,1,Ipadded,[],dim);

switch dim
    case 1
        If = Ipaddedfiltered(nh:end,:,:);
    case 2
        If = Ipaddedfiltered(:,nh:end,:);
    case 3
        If = Ipaddedfiltered(:,:,nh:end);
end

