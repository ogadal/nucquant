%%% import a 3D image stack from a sequence of single tif frames as
%%% exported by the Andor software
%%% If the image has more than 1 channel, the file names must obey the format as illustrated in this example:
%%%  150108_6R3L_5_t0032_z0014_w0001.tif
%%% this designates the frame corresponding to time point # 32, z-slice #
%%% 14, and channel #2.
%%% If the image has only 1 channel, the file names must obey the format as :
%%%  150108_6R3L_5_t0032_z0014.tif
%%%
%%% filename designates the first frame in the sequence

function [I3d,info] = importAndorstack(filename,Nchannels,Nz,itime)


if ~exist(filename,'file')
    error(['File "',filename,'" does not seem to exist here !']);
end

info = imfinfo(filename,'tif');

Nx = info(1).Width;
Ny = info(1).Height;

% pre-allocation for speed
I = zeros(Ny,Nx,Nz,Nchannels,'uint16');

% get file stem
aux = info.Filename;
[pathstr, name, ext] = fileparts(aux);
aux = 18;
if Nchannels==1
    aux = aux-6;
end
if Nz==1
    aux = aux-6;
end
filestem = name(1:end-aux);

info.imagenamestem = filestem;

% now read in each frame
hwb = waitbar(0,['Reading ',filestem,'* (',num2str(Nchannels),' channels, ',num2str(Nz),' slices) ...']);

Nframes = Nchannels*Nz;

iframe = 1;
for iz = 1:Nz
    for ich = 1:Nchannels
        if Nchannels>1
            if Nz>1
                framefilename = [filestem,'_t',int2str2(itime-1,4),'_z',int2str2(iz-1,4),'_w',int2str2(ich-1,4),ext];
            else
                framefilename = [filestem,'_t',int2str2(itime-1,4),'_w',int2str2(ich-1,4),ext];
            end
        else
            if Nz>1
                framefilename = [filestem,'_t',int2str2(itime-1,4),'_z',int2str2(iz-1,4),ext];
            else
                framefilename = [filestem,'_t',int2str2(itime-1,4),ext];
            end
        end
        fullframefilename = fullfile(pathstr,framefilename);
        if exist(fullframefilename,'file')==0
            error(['File ',fullframefilename,' not found in importAndorstack.m !']);
        end
        Iaux = imread(framefilename);
        I3d(:,:,iz,ich) = Iaux; % get the red channel only
        waitbar(iframe/Nframes,hwb,['Reading ',filestem,'* (slice ',num2str(iz-1),', channel ',num2str(ich),' ) ...']);
        iframe = iframe +1;
    end
end
