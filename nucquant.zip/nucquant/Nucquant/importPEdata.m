%%% import 2-D or 3-D Perkin-Elmer image data

function  I3d = importPEdata(dirname,imagenamestem,Nchannels,width,height,Nz,Ntimes,time)

cd(dirname);

% preallocation of output image data
if 1==1
    I3d = zeros(height,width,Nz,Nchannels,'uint16');
else
    I3d = squeeze(zeros(height,width,Nz,3,'uint16'));
end

if Ntimes <= 1
    %     disp('static image');
    switch Nchannels
        case 1
            if Nz>1
                I3d(:,:,:,1) =  readrawimagestack(imagenamestem,height,width,Nz,'2');
            else
                I3d(:,:,1) =  readrawimagestack(imagenamestem,height,width,Nz,'2');
            end
        case 2
            if Nz>1
                I3d(:,:,:,1) = readrawimagestack(imagenamestem,height,width,Nz,'3');
                I3d(:,:,:,2) = readrawimagestack(imagenamestem,height,width,Nz,'4');
            else
                aux = readrawimagestack(imagenamestem,height,width,Nz,'3');
                size(aux)
                I3d(:,:,1) = readrawimagestack(imagenamestem,height,width,Nz,'3');
                I3d(:,:,2) = readrawimagestack(imagenamestem,height,width,Nz,'4');
            end
        otherwise
            disp(['WRITE THE CODE FOR THIS CASE !']);
            stop;
    end
else
    %    disp('time sequence !');
    switch Nchannels
        case 1
            I3d(:,:,:,1) = readrawimagestack(imagenamestem,height,width,Nz,dec2hex(time+1));
        otherwise
            error('This program does not handle the dynamic multi-channel case yet.');
    end
end
depth = Nz;

%%% TEMPORARY !
dx=NaN; dy=NaN;dz=NaN; lambdas=NaN;

if 1==0
    figure,
    redmax = max(I3d_red,[],3);
    greenmax = max(I3d_green,[],3);
    figure,imagesc(redmax),title('red max');
    figure,imagesc(greenmax),title('green max');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Ntimes,width,height,Nz,Nchannels] = getinfofromtimfile(timfile)

% open tim file
name = timfile;
%name = timfile(1:end-1);   % Required for Unix ???
id = fopen(name,'r');
if id<0,
    error(['Could not open file ',name]);
end

% read first line
line1 = readline(id);
aux = sscanf(line1,'%d',4);   % NOTE: valid for specific data types only ! GENERALIZE LATER !
Nlast = aux(1);
% Get number of slices per stack
Nz = aux(4);

% Get width and height (from lines 2 and 3 of the .tim file)
aux = fscanf(id,'%d',2);
width = aux(1);
height = aux(2);

% Get the number of channels by
% looking for 'A' and 'B' characters in the .tim file
if 1==0  % DOESNT SEEM TO WORK FOR 1 CHANNEL CASE and I dont know why !!
    [aux,N_A] = fscanf(id,'%d [A]',1)
    if N_A==0
        error('Problem in getinfofromtimfile: there seems to be no "A" in the .tim file !');
    else
        fclose(id);
        id = fopen(name,'r');
        if id<0,
            error(['Could not open file ',name]);
        end
        [aux,N_B] = fscanf(id,'%d [B]',1);
        Nchannels = N_A + N_B;
        fclose(id);
    end
else
    % convert timfile to a long string
    aux = fscanf(id,'%s',Inf); fclose(id);
    N_A = any(aux=='A');
    N_B = any(aux=='B');
    Nchannels = N_A + N_B;
end

% Get number of time points
% NOTE: 2 channel images only !!!!  GENERALIZE LATER !
Ntimes = Nlast/Nchannels-1;

%aux = readline(id); aux = readline(id); % skip two lines
% read wavelengths from lines 6 and 7
%line6 = readline(id);
% TO DO : read wavelengths and times for 4D images !

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function I3d = readrawimagestack(stem,height,width,Nz,postfix)

% preallocation to increase speed
aux = zeros(height,width,Nz,'uint16');
if Nz>1
    hwb = waitbar(0,['Reading stack ',stem,'.',postfix,' (',num2str(Nz),' slices) ...']);
    for iz=0:Nz-1
        filename = [stem,'_',int2str2(iz,3),'.',postfix];
        waitbar(iz/(Nz-1),hwb,['Reading stack ',stem,'.',postfix,' (slice ',num2str(iz),'/',num2str(Nz-1),') ...']);
        [I2d,width2,height2]  = readrawimage(filename);
        if width2~=width || height2~=height
            error('Image size incompatibility in readrawimagestack !');
        end
        %imagesc(I2d'), colormap(gray),axis equal; axis tight; title(['Slice #',num2str(iz+1),'/',num2str(Nz)]);
        aux(:,:,iz+1) = I2d';
    end
    close(hwb);
else
    filename = [stem,'.',postfix];
    disp(['Reading image ',filename,' ...']);
    aux = readrawimage(filename)';
end
I3d = aux;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [I,width,height] = readrawimage(filename)
id = fopen(filename,'r','l');
if id<0
    error(['Could not open file ',filename,': id=',num2str(id)]);
end
aux = fread(id,3,'int16');
width = aux(2);
height = aux(3);
if width*height==0
    disp(['Error occurred in reeadrawimage: width=',num2str(width),', height=',num2str(height)]);
end
[I N]=fread(id,[width height],'int16=>uint16');
fclose(id);

if N~=width*height
    disp('Error occurred in readrawimage.');
    stop;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% returns the next line of the file as string
function line = readline(id)
aux = textscan(id,'%s',1,'delimiter','EOL');
line = char(aux{1});
