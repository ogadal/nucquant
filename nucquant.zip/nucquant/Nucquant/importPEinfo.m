%%% import information about Perkin-Elmer data, but not the images
%%% themselves
%%%
%%% TO DO: retrieve dx,dy,dz (voxel dimensions), lambdas ..

function  [Nchannels,width,height,Nz,Ntimes,lambdas,imagenamestem] = importPEinfo(dirname)

cd(dirname);

%%% Retrieve list of .files in current directory
if ispc
    list = dir;
    Nf = size(list,1);
else
    %[s,list] = unix(['ls -m *.',fileextension]);
    [s,list] = unix('ls -m');
    filename = strread(list,'%s','delimiter',',');
    Nf = size(filename,1);
end

% Get the stem name from the *.HTM file
if ispc
    aux1 = dir('*.HTM');
    aux = aux1.name;
    [aux2,imagenamestem,aux3]= fileparts(aux);
else
    [s,aux] = unix('ls *.HTM');
    imagenamestem = aux(1:end-5);
end
disp(['Image name stem=',imagenamestem]);

% Get information out of the .tim file
if ispc
    aux = dir('*.tim');
    timfile = aux.name;
else
    [s,timfile] = unix('ls *.tim');
end
[Ntimes,width,height,Nz,Nchannels] = getinfofromtimfile(timfile);

disp(['Number of channels = ',num2str(Nchannels),' (CHECK!!)']);
disp(['Image width = ',num2str(width)]);
disp(['Image height = ',num2str(height)]);
disp(['Number of slices=',num2str(Nz)]);
disp(['Number of time points = ',num2str(Ntimes),' (CHECK!!)']);

% TO DO: retrieve this from files !!
lambdas = NaN;
dx = NaN; dy = NaN; dz = NaN;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Ntimes,width,height,Nz,Nchannels] = getinfofromtimfile(timfile)

% open tim file
if ispc
    name = timfile;
else
    name = timfile(1:end-1);   % apparently required for Unix  !
end
id = fopen(name,'r');
if id<0,
    error(['Could not open file ',name]);
end

% read first line
line1 = readline(id);
aux = sscanf(line1,'%d',4);
Nlast = aux(1);
% Get number of slices per stack
if numel(aux) ==4
    Nz = aux(4);
else
    Nz = 1; % CHECK !!
end

% Get width and height (from lines 2 and 3 of the .tim file)
aux = fscanf(id,'%d',2);
width = aux(1);
height = aux(2);

% Get the number of channels by
% looking for 'A' and 'B' characters in the .tim file
if 1==0  % DOESNT SEEM TO WORK FOR 1 CHANNEL CASE and I dont know why !!
    [aux,N_A] = fscanf(id,'%d [A]',1)
    if N_A==0
        error('Problem in getinfofromtimfile: there seems to be no "A" in the .tim file !');
    else
        fclose(id);
        id = fopen(name,'r');
        if id<0,
            error(['Could not open file ',name]);
        end
        [aux,N_B] = fscanf(id,'%d [B]',1);
        Nchannels = N_A + N_B;
        fclose(id);
    end
else
    % convert timfile to a long string
    aux = fscanf(id,'%s',Inf); fclose(id);
    N_A = any(aux=='A');
    N_B = any(aux=='B');
    Nchannels = N_A + N_B;
end

% Get number of time points
% NOTE: 2 channel images only !!!!  GENERALIZE LATER !
Ntimes = Nlast/Nchannels-1;

%aux = readline(id); aux = readline(id); % skip two lines
% read wavelengths from lines 6 and 7
%line6 = readline(id);
% TO DO : read wavelengths and times for 4D images !


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% returns the next line of the file as string
function line = readline(id)
aux = textscan(id,'%s',1,'delimiter','EOL');
line = char(aux{1});
