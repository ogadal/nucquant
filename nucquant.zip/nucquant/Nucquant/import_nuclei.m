% Interactively crop Perkin-Elmer or Andor image stacks and convert them into .mat files, together with
% acquisition input_parameters


clc;
clear all;
close all hidden;

% Startup directory
dir0 = cd;

disp('================================================================');
disp('import_nuclei:');
disp(['Import and crop 3D or 3D+time image data from Perkin-Elmer or Andor microscopy']);
disp('================================================================');

%% Request user input
if 1==0 % Ask several questions
    PEdata = input2('Import from Perkin-Elmer data (otherwise from .tif files)','y');
    outputformat = input2('Choose export format: tif or matlab (t/m)','m');     if outputformat=='t', outputformat = 'tif'; else outputformat = 'matlab'; end;
    getmicrosettings = input2('Take into account microscope settings ?','y');
    swapRG = input2('Say y to visualize first channel in green and second in red','y');
    input_parameters = [];
else
    % Ask user for data format
    input_parameters.data_format = questdlg('What is the data source ?','','Perkin-Elmer','Andor','Andor (fluo+trans)','Andor (fluo+trans)');
    if strcmp(input_parameters.data_format,'Perkin-Elmer')
        swapRG = 'y';
    else
        swapRG = 'y';
    end
    outputformat = 'matlab';
    getmicrosettings = 'y';
end

%% Ask user for acquisition parameter
if getmicrosettings == 'y'

    prompt = {'Enter refractive index n of the sample medium:', ...
        'Enter numerical aperture NA of the objective lens:', ...
        'Enter emission wavelength in microns', ...
        'Enter voxel dimension along x in microns', ...
        'Enter voxel dimension along y in microns',...
        'Enter voxel dimension along z in microns'};
    if  strcmp(input_parameters.data_format,'Andor') || strcmp(input_parameters.data_format,'Andor (fluo+trans)')
        prompt = [prompt  'Number of color channels'];
    end
    if strcmp(input_parameters.data_format,'Perkin-Elmer')
        default_values = {'1.33', '1.4', '0.5', '0.0645', '0.0645', '0.25'};
    else
        default_values = {'1.33', '1.4', '0.5', '0.065', '0.065', '0.25', '2'};
    end
    answer = inputdlg(prompt,'Check microscopy parameters',1,default_values);
    n = str2num(answer{1});
    NA = str2num(answer{2});
    lambda = str2num(answer{3});
    dx = str2num(answer{4});
    dy = str2num(answer{5});
    dz = str2num(answer{6});
    if  strcmp(input_parameters.data_format,'Andor') || strcmp(input_parameters.data_format,'Andor (fluo+trans)')
        Nchannels = str2num(answer{7});
    end
else
    n = NaN;
    NA = NaN;
    lambda = NaN;
    dx = NaN; dy = NaN; dz = NaN;
end

finished_all_datasets = 'n';

%% Do the interactive cropping and saving
while finished_all_datasets~='y'
    % Import the images
    switch input_parameters.data_format
        case 'Perkin-Elmer' % Import from Perkin-Elmer data
            dir_input = uigetdir(dir0,'Select folder containing the Perkin-Elmer data');
            disp('importing data...');
            [Nchannels,width,height,Nz,Ntimes,lambdas,imagenamestem] = importPEinfo(dir_input);
            I3d = importPEdata(dir_input,imagenamestem,Nchannels,width,height,Nz,Ntimes,1);
            Iinfo = [];
        case 'Andor' % Import from tif files
            aux = questdlg('Is the image in a single tif file ?','','Yes','No','Yes');
            if strcmp(aux,'Yes')
                [tiffile,dir_input] = uigetfile('*.*','Select the single tif image file');     cd(dir_input);
                Ntimes = 1;
                [I3d, Iinfo] = importtif(tiffile,Nchannels);
                [aux,imagenamestem,aux2] = fileparts(tiffile);
                Nz = size(I3d,3);
            else
                [tiffile,dir_input] = uigetfile('*.*','Select the 1st tif image file from the sequence');     cd(dir_input);
                aux = inputdlg({'Number of channels','Number of time points','Number of z slices'},'',1,{'2','50','25'});
                Nchannels = str2num(aux{1});
                Ntimes = str2num(aux{2});
                Nz = str2num(aux{3});
                tiffile = fullfile(dir_input,tiffile);
                [I3d, Iinfo] = importAndorstack(tiffile,Nchannels,Nz,1);
                imagenamestem = Iinfo.imagenamestem;
            end
        case 'Andor (fluo+trans)'
            [tiffile,dir_input] = uigetfile('*.*','Select the fluorescence only image');     cd(dir_input);
            [tiffile1,dir_input1] = uigetfile('*.*','Select the fluorescence+transmission image');     cd(dir_input1);
            Ntimes = 1;
            % import the fluorescence only image
            [I3d, Iinfo] = importtif(tiffile,Nchannels);
            [aux,imagenamestem,aux2] = fileparts(tiffile);
            Nz = size(I3d,3);
            % import the fluorescence + transmission image
            [I3d1, Iinfo1] = importtif(tiffile1,Nchannels);
            [aux,imagenamestem1,aux2] = fileparts(tiffile1);
            Nz1 = size(I3d1,3);
        otherwise
            error('unacceptable data format !');
    end

    % Handle empty channels
    if 1==0 % Not needed because the image is preallocated with zeros !
        I3d = add_empty_channels(I3d,Nchannels);
    end

    %% Show histogram and detect saturation TO BE DONE !
    if 1==0
        fig_hist = figure('Name','histogram');
    end

    %% Compute maximum intensity projection
    hwb = waitbar(0,'Computing max. int. proj. ...'); drawnow;
    if Nz>1
        aux = squeeze(max(I3d,[],3));
        if size(aux,3) == 2
            disp('padding third dimension of image with zeros..');
            aux(:,:,3) = zeros(size(aux(:,:,1)));
        end
        Imaxproj = imadjust(aux,stretchlim(aux,[0.01 0.999]),[]);
        clear aux;
        if exist('I3d1','var')
            aux = squeeze(max(I3d1,[],3));
            if size(aux,3) == 2
                disp('padding third dimension of image with zeros..');
                aux(:,:,3) = zeros(size(aux(:,:,1)));
            end
            Imaxproj1 = imadjust(aux,stretchlim(aux,[0.01 0.999]),[]);
            clear aux;
        end
    else
        Imaxproj = imadjust(I3d,stretchlim(I3d,[0.01 0.999]),[]);
        if exist('I3d1','var')
            Imaxproj1 = imadjust(I3d1,stretchlim(I3d1,[0.01 0.999]),[]);
        end
    end
    delete(hwb);
    if swapRG=='y' && Nchannels>1
        hwb = waitbar(0,'Swapping channels ....');
        aux = Imaxproj(:,:,1);
        Imaxproj(:,:,1) = Imaxproj(:,:,2);
        Imaxproj(:,:,2) = aux;
        close(hwb);
        if exist('Imaxproj1','var')
            hwb = waitbar(0,'Swapping channels ....');
            aux = Imaxproj1(:,:,1);
            Imaxproj1(:,:,1) = Imaxproj1(:,:,2);
            Imaxproj1(:,:,2) = aux;
            close(hwb);
        end
    end

    % Get axes
    [Nx Ny Nz aux] = size(I3d);
    xx = 0:dx:(Nx-1)*dx + dx/2;
    yy = 0:dy:(Ny-1)*dy + dy/2;
    zz = 0:dz:(Nz-1)*dz  + dz/2;

    % Allow user to select crop regions
    if 1==0
        crop = input2('Do you want to crop the image(s) ?','y');
    else
        crop = 'y';
    end
    if crop=='y'
        % Interactive cropping tool
        if exist('Imaxproj1','var')
            fig_aux = figure('Name','Fluorescence only image','Toolbar','none','Menubar','none','NumberTitle','off');
            imagesc(Imaxproj);
            place_figure(fig_aux,1,1,1,1);
            axis equal tight off;
            [fig_whole,crop_rectangle] = zoomandcrop(Imaxproj1);
        else
            [fig_whole,crop_rectangle] = zoomandcrop(Imaxproj);
        end

        % Now do the actual cropping
        %
        % Strategy: because the complete 3D+time data set is typically too big
        % for the memory, I only load one 3D stack at a time, then remove
        % it from memory before loading the next 3D stack.
        % Once one 3D stack is loaded, the cropping is done sequentially
        % for all selected cropping regions,  and each cropped 3D stack is saved as a distinct mat-file
        %
        % First, specify the names of the output files (one for each
        % crop region and for each time point)
        Ncrops = length(crop_rectangle);
        for  icrop =1:Ncrops
            for time_index=1:Ntimes
                outputfilename{icrop,time_index} = [imagenamestem,'_cr',int2str2(icrop,3),'_t',int2str2(time_index,4)];
            end
        end
        % Do the crops for the first time point, and save the cropped
        % images together with some acquisition parameters
        hwb = waitbar(0,['Cropping and saving ',num2str(Ncrops),' regions...']);
        for  icrop =1:Ncrops
            Icrop = imcrop3d(I3d,crop_rectangle{icrop});
            % Compute axes of the cropped image - MODIFY LATER TO
            % MEMORISE POSITION WITHIN LARGE IMAGE !
            [Nx Ny Nz aux] = size(Icrop); xx = 0:dx:(Nx-1)*dx; yy = 0:dy:(Ny-1)*dy;  zz = 0:dz:(Nz-1)*dz;
            % Save cropped image to disk
            switch outputformat
                case 'matlab'
                    disp(['saving cropped image and acquisition parameters as matlab file ',outputfilename{icrop,1},'...']);
                    cd(dir_input);
%                     if exist('cropped_matlab')~=7,
                        mkdir('cropped_matlab');
%                     end
                    cd('./cropped_matlab');
                    save(outputfilename{icrop,1},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes','Iinfo','input_parameters');
                case 'tif'
                    disp(['about to save cropped image and acquisition parameters as tif files named ',outputfilestem,'...']);
                    [outdirname,aux,nbdigits] = export2tifinfo(10);
                    flag = export2tif(Icrop,outputfilestem,nbdigits,outdirname);
            end
            wbcrop = waitbar(icrop/Ncrops,hwb,['Cropping and saving region ',num2str(icrop),'/',num2str(Ncrops),'...']);
            clear Icrop;
        end
        if exist('wbcrop','var'), delete(wbcrop); end
        %         delete(hwb);
        % Clear the 3D image data of the first time point from memory
        clear I3d;
        % Now handle the remainder of the time sequence
        % Initialize waitbar
        if Ntimes>1
            wbtime = waitbar(0,'Now cropping remainder of time sequence...');
            NbMonitors = size(get(0,'MonitorPosition'),1);
            if NbMonitors>1
                aux = get(wbtime,'Position');
                scrsz = get(0,'ScreenSize');
                set(wbtime,'Position',[scrsz(4) scrsz(3)/2-80 aux(3) aux(4)]);
            end
        end
        for time_index = 2:Ntimes
            % Update waitbar
            if Ntimes>1
                text4waitbar = ['Cropping and saving time point ',num2str(time_index),'/',num2str(Ntimes),' ...'];
                waitbar((time_index-0.5)/Ntimes,wbtime,text4waitbar);
            end
            % Load the 3D image of the current time point
            cd(dir_input);
            switch input_parameters.data_format
                case 'Perkin-Elmer' % Import from Perkin-Elmer data
                    I3d = importPEdata(dir_input,imagenamestem,Nchannels,width,height,Nz,Ntimes,time_index);
                case 'Andor' % Import from tif files
                    [I3d, Iinfo] = importAndorstack(tiffile,Nchannels,Nz,time_index);
            end
            % Handle empty channels
            if 1==0
                I3d = add_empty_channels(I3d,Nchannels);
            end
            % Sequentially crop each cropping rectangle
            for  icrop =1:Ncrops
                Icrop = imcrop3d(I3d,crop_rectangle{icrop});
                % Compute axes of the cropped image - MODIFY LATER TO
                % MEMORISE POSITION WITHIN LARGE IMAGE !
                [Nx Ny Nz aux] = size(Icrop); xx = 0:dx:(Nx-1)*dx; yy = 0:dy:(Ny-1)*dy;  zz = 0:dz:(Nz-1)*dz;
                % Save cropped image to disk
                switch outputformat
                    case 'matlab'
                        disp(['saving cropped image and acquisition parameters as matlab file ',outputfilename{icrop,time_index},'...']);
                        cd(dir_input);
                        cd('./cropped_matlab');
                        save(outputfilename{icrop,time_index},'Icrop','crop_rectangle','Nchannels','xx','yy','zz','dx','dy','dz','Nx','Ny','Nz','lambda','NA','n','Ntimes');
                    case 'tif'
                        disp(['about to save cropped image and acquisition parameters as tif files named ',outputfilestem,'...']);
                        [outdirname,aux,nbdigits] = export2tifinfo(10);
                        flag = export2tif(Icrop,outputfilestem,nbdigits,outdirname);
                end
                clear Icrop;
            end
            % Clear current 3D image from memory
            clear I3d;
        end

        %% Save the figure showing crop rectangle locations on disk
        figure(fig_whole); title('Overview of cropped regions');
        disp('Saving overview to disk:');
        switch outputformat
            case 'tif'
                [outdirname,outputfilestem,nbdigits] = export2tifinfo(10);
                outputfilestem = imagenamestem;
                flag = export2tif(Icrop,outputfilestem,nbdigits,outdirname);
            case 'matlab'
                if 1==0
                    saveas(fig_whole,'crop_overview','jpg');
                else % recreate the overview  with the rectangles (because I can't seem to get the zoom factor right)
                    fig_overview = figure;
                    if exist('Imaxproj1','var')
                        imagesc(Imaxproj1);
                    else
                        imagesc(Imaxproj);
                    end
                    axis equal; axis tight;  title(['Crop regions of image.']); % title(['Crop regions of image "',tiffile,'"']);
                    for i=1:length(crop_rectangle)
                        rect = crop_rectangle{i};
                        rectangle('Position',rect,'EdgeColor','y','LineWidth',1);
                        text(rect(1),rect(2),num2str(i),'Color','y','FontSize',8,'VerticalAlignment','Bottom');
                    end
                    overview_file_name = [imagenamestem,'_crop_overview'];
                    saveas(fig_overview,overview_file_name,'jpg');
                    saveas(fig_overview,overview_file_name,'emf');
                    saveas(fig_overview,overview_file_name,'fig');
                end
                if exist('crop_rectangle','var'), save([imagenamestem,'_crop_rectangles.mat'],'crop_rectangle'); end
        end
    else
        save_large_image = input2('Do you want to save the whole image field ?','n');
        if save_large_image == 'y'
            % Save whole image  and acquisition information to disk
            outputfilestem = imagenamestem;
            switch outputformat
                case 'matlab'
                    outputfilename = [outputfilestem,'.mat'];
                    disp(['saving the whole image and acquisition parameters as matlab file ',outputfilename,'...']);
                    cd(dir_input);
                    % Save image and acquisition information to disk
                    disp('saving large image and acquisition parameters as matlab file real_image.mat ...');
                    save real_image I3d Nchannels xx yy zz dx dy dz Nx Ny Nz lambda NA n;
                case 'tif'
                    disp(['about to save whole image and acquisition parameters as tif files named ',outputfilestem,'...']);
                    [outdirname,aux,nbdigits] = export2tifinfo(10);
                    flag = export2tif(I3d,outputfilestem,nbdigits,outdirname);
            end
        else
            disp('Ok, I dont save anything.');
        end
    end
    close all hidden;
    answer = questdlg('Import another data set with the same microscope settings','','Yes','No','No');
    if strcmp(answer,'No')
        finished_all_datasets = 'y';
    else
        finished_all_datasets = 'n';
    end

    if finished_all_datasets ~='y'
        close all;
        clear I* Nx Ny Nz crop* depth height icrop imagenamestem outputfilestem outfilename xx yy zz iz;
    end
    dir0 = dir_input;
end
close all hidden;
disp('End of program.');


