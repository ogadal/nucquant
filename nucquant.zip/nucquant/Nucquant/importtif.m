% Import a multi-layer tif image

function [I,info] = importtif(filename,Nchannels)

if ~exist(filename,'file')
    error(['File "',filename,' does not seem to exist here !']);
end

info = imfinfo(filename,'tif');

Nz = length(info)/Nchannels; % number of slices
% Ntimes = 

Nx = info(1).Width;
Ny = info(1).Height;

% pre-allocation for speed
I = zeros(Ny,Nx,Nz,Nchannels,'uint16');

% now read in each frame
hwb = waitbar(0,['Reading stack ',filename,' (',num2str(Nchannels),' channels, ',num2str(Nz),' slices) ...']);

Nframes = Nchannels*Nz;

iframe = 1;

for iz = 1:Nz
    for ich=1:Nchannels
        waitbar(iframe/Nframes,hwb,['Reading stack ',filename,' (slice ',num2str(iz),', channel ',num2str(ich),' ) ...']);
        %         I(:,:,iz,ich)= imread(filename,'tif',iframe);
        I(:,:,iz,ich)= im2uint16(imread(filename,'tif',iframe));
        iframe = iframe+1;
    end
end

close(hwb);
