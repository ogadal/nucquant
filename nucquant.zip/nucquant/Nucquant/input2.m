function R = input2(string,default)
% Modification of the 'input' function that returns the specified default reply 
% if the user presses 'return'.
% (I use this function in order to avoid getting the Matlab warning 
% "Warning: Future versions will return empty for empty == scalar comparisons"
% when comparing an empty reply in an if-statement)

aux = input([string,' [',default,'] --> '],'s');
if isempty(aux)
    disp(default);
    R = default;
else
    R = aux;
end
