%%% Compute intensity weighted  mass center (centroid) of a 3D voxel
%%% neighborhood of size (2*di+1)*(2*dj+1)*(2*dk+1)  centered on
%%% the voxel (i,j,k) of image I
%%% using only pixels whose intensity exceeds the max. intensity over the
%%% neighborhood multiplied by threshold (threshold should be <1 and >=0)
%%% (xx,yy,zz) are vectors defining the axes coordinates corresponding to
%%% the image voxels

function [x,y,z,Isum,Imin] = intensity_centroid(i,j,k,I,di,dj,dk,xx,yy,zz,threshold)

% Handle case where i, j, k are vectors
N = length(i);

if N~=length(j) || N~=length(k) || length(j)~=length(k)
    error('i j k must have equal lengths !');
end

if N>1
    for ig =1:N
        [x(ig),y(ig),z(ig)] = intensity_centroid(i(ig),j(ig),k(ig),I,di,dj,dk,xx,yy,zz,threshold);
    end
else

    aux = 0;
    xaux = 0;
    yaux = 0;
    zaux = 0;

    imin = max(1,i-di);
    jmin = max(1,j-dj);
    kmin = max(1,k-dk);
    imax = min(size(I,1),i+di);
    jmax = min(size(I,2),j+dj);
    kmax = min(size(I,3),k+dk);

    % Get maximum intensity over the neighborhood
    aux = I(imin:imax,jmin:jmax,kmin:kmax);
    Imax = max(aux(:));

    Ithresh = 0.8 * Imax;   % intensity threshold for computation of centroid

    % Compute intensity weighted averages of each coordinate in the voxel
    % neighborhood

    if 1==0
        total_weight = 0;
        for ii = imin : imax
            for jj = jmin : jmax
                for kk = kmin : kmax
                    Iloc = I(ii,jj,kk);
                    weight = max(0,Iloc-Ithresh);
                    q(ii-imin+1,jj-jmin+1,kk-kmin+1) = weight;      % for DEBUG
                    [xloc,yloc,zloc] = ijk2xyz(ii,jj,kk,xx,yy,zz);
                    xaux = xaux + xloc*weight;
                    yaux = yaux + yloc*weight;
                    zaux = zaux + zloc*weight;
                    total_weight = total_weight + weight;
                end
            end
        end
        x = xaux/total_weight;
        y = yaux/total_weight;
        z = zaux/total_weight;

    else % vectorizing this for speed !   % TODO: CHECK why this doesnt exactly give the same results as above !!!

        Iloc = I(imin:imax, jmin:jmax, kmin:kmax);
        xxx = xx(imin:imax);
        yyy = yy(jmin:jmax);
        zzz = zz(kmin:kmax);
        [xloc, yloc, zloc] = ndgrid(xxx,yyy,zzz);
        weights = max( Iloc - Ithresh*ones(size(Iloc)), zeros(size(Iloc)) );
        total_weight = sum(weights(:));
        % weighted coordinates
        xw = xloc.*weights;
        yw = yloc.*weights;
        zw = zloc.*weights;
        % means of the weighted coordinates
        x = sum(xw(:)) / total_weight;
        y = sum(yw(:)) / total_weight;
        z = sum(zw(:)) / total_weight;
        % total intensity over the local window
        Isum = sum(Iloc(:));
        % minimum intensity over the local window
        Imin = min(Iloc(:));
    end
end

if 1==0  % for TESTS
    q
    qmin = min(q(:));
    qmax = max(q(:));
    disp(['intensity_centroid: min(q)=',num2str(qmin),', max(q)=',num2str(qmax),' max(q)/min(q)=',num2str(qmax/qmin)]);

end