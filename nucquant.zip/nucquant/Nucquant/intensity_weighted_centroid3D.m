% Compute intensity weighted centroid of a given region within a 3D grey scale image
% Input quantities:
%   I = grey scale image
%   Ibw = corresponding binary image that defines the region of interest
%
% Output quantities:
%   (ic,jc,kc) = indices of the centroid
%   Nvox = number of voxels inside region of interest


% TODO: rationalize this with the more general function intensity_centroid
% this function is redundant !

function [ic,jc,kc,Nvox] = intensity_weighted_centroid3D(I,Ibw)
if size(I)~=size(Ibw),
    error('sizes of I and Ibw do not match in function intensity_weighted_centroid3D !');
end

Nx = size(I,1);
Ny = size(I,2);
Nz = size(I,3);

cum_ic = 0;
cum_jc = 0;
cum_kc = 0;
cumintensity = 0;
Nvox = 0;
for i = 1:Nx
    for j = 1:Ny
        for k= 1:Nz
            if Ibw(i,j,k)  % if inside region of interest
                Nvox = Nvox+1;
                intensity = double(I(i,j,k));
                cumintensity = cumintensity+intensity;
                cum_ic = cum_ic + intensity*i;
                cum_jc = cum_jc + intensity*j;
                cum_kc = cum_kc + intensity*k;
            end
        end
    end
end

if Nvox >0
    ic = cum_ic/cumintensity;
    jc = cum_jc/cumintensity;
    kc = cum_kc/cumintensity;
else
    disp('The region of interest is apparently empty in intensity_weighted_centroid3D !');
    ic = NaN;
    jc= NaN;
    kc = NaN;
end


