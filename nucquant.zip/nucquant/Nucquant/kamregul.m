function [S,U2]=kamregul(U,G0,N)

    S=[];U2=U;SG=[];
    for i=1:N
        U1=unique(U,'rows');
        dv1=delaunayn(U1);
        tr1=TriRep(dv1,U1);
        [trv1,vb1]=freeBoundary(tr1);
        for j=1:size(trv1,1)
            P1=vb1(trv1(j,1),:);P2=vb1(trv1(j,2),:);P3=vb1(trv1(j,3),:);
            G=kamgravit(P1,P2,P3,G0);SG=[SG;G];
            B=kamsym(G,G0,P1,P2,P3);
            S=[S;B];
        end
        U=[U1;S];
    end
    %figure;scatter3(U2(:,1),U2(:,2),U2(:,3),'ro');hold on
    %scatter3(S(:,1),S(:,2),S(:,3),'go');hold on;
    %scatter3(SG(:,1),SG(:,2),SG(:,3),'ko')
    clear U U1;
end

function G=kamgravit(P1,P2,P3,G0)
    
   % 3G0G=-P1G0-P2G0-P3G0=G0P1+G0P2+G0P3
   xg=(P1(1)+P2(1)+P3(1)-3*G0(1))/3+G0(1);
   yg=(P1(2)+P2(2)+P3(2)-3*G0(2))/3+G0(2);
   zg=(P1(3)+P2(3)+P3(3)-3*G0(3))/3+G0(3);
   
   G=[xg yg zg];
   
end


function B=kamsym(G,G0,P1,P2,P3)


    a=G(1)-G0(1);b=G(2)-G0(2);c=G(3)-G0(3);
    d=mean([norm(P1-G0) norm(P2-G0) norm(P3-G0)]);
    
    r(1)=d/sqrt(a*a+b*b+c*c);r(2)=-d/sqrt(a*a+b*b+c*c);
    X=a*r+G0(1);Y=b*r+G0(2);Z=c*r+G0(3);
    
    P11=[X(1) Y(1) Z(1)];P12=[X(2) Y(2) Z(2)];
    
    e1=norm(P11-P1);e2=norm(P12-P1);
    
    if e1<e2
         B=[X(1) Y(1) Z(1)];
    else
        B=[X(2) Y(2) Z(2)];
    end



end


