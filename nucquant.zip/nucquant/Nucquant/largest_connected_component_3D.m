% Remove all but the largest connected component from a binary 3D image and
% return the volume in voxels of this largest cc.
function [Ibw3d_res,Vol_vx] = largest_connected_component_3D(Ibw3d);
if ndims(Ibw3d)~=3
    error('Ibw3d must have dimension 3!');
end

% Label and count connected components
disp('labeling connected components ...');
[Icc,Ncc] = bwlabeln(Ibw3d);

disp(['I found ',num2str(Ncc),' connected components']);

switch Ncc
    case 0
        error('Ncc=0 should not happen !!');
    case 1
        Ibw3d_res = Ibw3d;
        Vol_vx = sum(Ibw3d(:));
    otherwise
        % Count the number of voxels in each connected component
        for i=1:Ncc
            Nvox(i) = sum(Icc(:)==i);
            if Nvox(i)==0
                error('Nvox(i)=0 should not happen unless the labeling of connected components uses inconsistent numbers!');
            end
        end
        % Find the connected component with the largest number of voxels
        [Vol_vx, iccmax] = max(Nvox);
        disp(['The largest labelled component has number #',num2str(iccmax)]);
        Ibw3d_res = (Icc==iccmax);
end
