
% Define a local image around (x0,y0) 

function [Iloc,xxloc,yyloc] = local_2Dimage(I,xx,yy,x0,y0,sigma_xy)

if ndims(I)~=2
    error('I must be 2D !');
end

if size(I)~= [length(xx) length(yy)]
    error('sizes do not match !');
end

Dx = 3*sigma_xy;
Dy = Dx;

xmin = max(x0 - Dx, xx(1));
xmax = min(x0 + Dx, xx(end));
ymin = max(y0 - Dy, yy(1));
ymax = min(y0 + Dy, yy(end));

[imin ,jmin] = xy2ij(xmin,ymin,xx,yy);
[imax ,jmax] = xy2ij(xmax,ymax,xx,yy);


iloc = imin:imax;
jloc = jmin:jmax;

Iloc = I(iloc, jloc);

[xxloc, yyloc] = ij2xy(iloc,jloc,xx,yy);


end