
% Define a local image around (x0,y0,z0) 

function [Iloc,xxloc,yyloc,zzloc] = local_image(I,xx,yy,zz,x0,y0,z0,sigma_xy,sigma_z)

if ndims(I)~=3 || size(I,1)~=length(xx) || size(I,2)~=length(yy) || size(I,3)~=length(zz)
    error('sizes do not match !');
end

Dx = 3*sigma_xy;
Dy = Dx;
Dz = 3*sigma_z;

xmin = max(x0 - Dx, xx(1));
xmax = min(x0 + Dx, xx(end));
ymin = max(y0 - Dy, yy(1));
ymax = min(y0 + Dy, yy(end));
zmin = max(z0 - Dz, zz(1));
zmax = min(z0 + Dz, zz(end));

[imin ,jmin, kmin] = xyz2ijk(xmin,ymin,zmin,xx,yy,zz);
[imax ,jmax, kmax] = xyz2ijk(xmax,ymax,zmax,xx,yy,zz);


iloc = imin:imax;
jloc = jmin:jmax;
kloc = kmin:kmax;

Iloc = I(iloc, jloc, kloc);

[xxloc, yyloc, zzloc] = ijk2xyz(iloc,jloc,kloc,xx,yy,zz);


end