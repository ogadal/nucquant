% Returns the indices of the local maxima of the 3D input image I
% (should be faster than local_maxima_thomann)
% Differs from the function local_maxima only by the fact that the
% intensity at the local maximum must be strictly greater than that of all
% neighbouring pixels

function [ilocmax,jlocmax,klocmax] = local_maxima_strict(I)

[Nx Ny Nz] = size(I);

if Nz==1    % the image is in fact 2D
       I = squeeze(I);
end

Issd = NaN(size(I));
sizeIssd = size(Issd);

if Nz>1  % real 3D image
disp('locating local maxima in 3D image..');
    for i=2:Nx-1
        for j=2:Ny-1
            for k=2:Nz-1

                aux = I(i,j,k);

                Issd(i,j,k) = ...
                    (aux>I(i-1,j-1,k-1))  && (aux>I(i-1,j-1,k ))    && (aux>I(i-1,j-1,k+1)) ...
                    && (aux>I(i-1,j  ,k-1))  && (aux>I(i-1,j  ,k ))    && (aux>I(i-1,j,k+1)) ...
                    && (aux>I(i-1,j+1,k-1)) && (aux>I(i-1,j+1,k ))  && (aux>I(i-1,j+1,k+1)) ...
                    && (aux>I(i  ,j-1,k-1))  && (aux>I(i  ,j-1 ,k  ))    && (aux>I(i,j-1,k+1)) ...
                    && (aux>I(i  ,j  ,k-1))                        && (aux>I(i,j,k+1)) ...
                    && (aux>I(i  ,j+1,k-1)) && (aux>I(i ,j+1 ,k  ))    && (aux>I(i,j+1,k+1)) ...
                    && (aux>I(i+1,j-1,k-1)) && (aux>I(i+1,j-1 ,k ))   && (aux>I(i+1,j-1,k+1)) ...
                    && (aux>I(i+1,j  ,k-1)) && (aux>I(i+1,j  ,k))    && (aux>I(i+1,j,k+1)) ...
                    && (aux>I(i+1,j+1,k-1)) && (aux>I(i+1,j+1,k))  && (aux>I(i+1,j+1,k+1));

            end
        end
    end
    
[ilocmax,jlocmax,klocmax] = ind2sub(size(Issd),find(Issd==1));

else % the image is in fact 2D
disp('locating local maxima in 2D image..');

     for i=2:Nx-1
        for j=2:Ny-1
            aux = I(i,j);
            Issd(i,j) = ...
                (aux>I(i-1,j-1))  &&  (aux>I(i-1,j))  &&  (aux>I(i-1,j+1))  && ...
                (aux>I(i  ,j-1))  &&  (aux>I(i  ,j+1))  && ...
                (aux>I(i+1,j-1))  &&  (aux>I(i+1,j))  &&  (aux>I(i+1,j+1))  ;
        end
     end

    [ilocmax,jlocmax] = ind2sub(size(Issd),find(Issd==1));
    klocmax = ones(size(ilocmax));
end

%           % Alternative vectorized computation
%           % Unfortunately this is actually slower than the nested loops above, probably because AND operator on arrays does not short-circuit?
%
%     ii0 = 1:Nx-2;
%     ii1 = 2:Nx-1;
%     ii2 = 3:Nx;
%     jj0 = 1:Ny-2;
%     jj1 = 2:Ny-1;
%     jj2 = 3:Ny;
%     kk0 = 1:Nz-2;
%     kk1 = 2:Nz-1;
%     kk2 = 3:Nz;
%
%
%     I000   = I(ii0, jj0, kk0);
%     I001   = I(ii0, jj0, kk1);
%     I002   = I(ii0, jj0, kk2);
%     I010   = I(ii0, jj1, kk0);
%     I011   = I(ii0, jj1, kk1);
%     I012   = I(ii0, jj1, kk2);
%     I020   = I(ii0, jj2, kk0);
%     I021   = I(ii0, jj2, kk1);
%     I022   = I(ii0, jj2, kk2);
%     I100   = I(ii1, jj0, kk0);
%     I101   = I(ii1, jj0, kk1);
%     I102   = I(ii1, jj0, kk2);
%     I110   = I(ii1, jj1, kk0);
%     I111   = I(ii1, jj1, kk1);
%     I112   = I(ii1, jj1, kk2);
%     I120   = I(ii1, jj2, kk0);
%     I121   = I(ii1, jj2, kk1);
%     I122   = I(ii1, jj2, kk2);
%     I200   = I(ii2, jj0, kk0);
%     I201   = I(ii2, jj0, kk1);
%     I202   = I(ii2, jj0, kk2);
%     I210   = I(ii2, jj1, kk0);
%     I211   = I(ii2, jj1, kk1);
%     I212   = I(ii2, jj1, kk2);
%     I220   = I(ii2, jj2, kk0);
%     I221   = I(ii2, jj2, kk1);
%     I222   = I(ii2, jj2, kk2);
%
%     if 1==0
%         Iaux = and(I111 > I000, ...
%             and(I111 > I001, ...
%             and(I111 > I002, ...
%             and(I111 > I010, ...
%             and(I111 > I011, ...
%             and(I111 > I012, ...
%             and(I111 > I020, ...
%             and(I111 > I021, ...
%             and(I111 > I022, ...
%             and(I111 > I100, ...
%             and(I111 > I101, ...
%             and(I111 > I102, ...
%             and(I111 > I110, ...
%             and(I111 > I112, ...
%             and(I111 > I120, ...
%             and(I111 > I121, ...
%             and(I111 > I122, ...
%             and(I111 > I200, ...
%             and(I111 > I201, ...
%             and(I111 > I202, ...
%             and(I111 > I210, ...
%             and(I111 > I211, ...
%             and(I111 > I212, ...
%             and(I111 > I220, ...
%             and(I111 > I221, I111 > I222)))))))))))))))))))))))));
%
%         Issd = zeros(size(I));
%         Issd(2:Nx-1, 2:Ny-1, 2:Nz-1) = Iaux;
%     else
% %         Ilog000 = I111 > I000;
% %         Ilog001 = I111 > I001;
% %         Ilog002 = I111 > I002;
% %         Ilog010 = I111 > I010;
% %         Ilog011 = I111 > I011;
% %         Ilog012 = I111 > I012;
% %         Ilog020 = I111 > I020;
% %         Ilog021 = I111 > I021;
% %         Ilog022 = I111 > I022;
% %         Ilog100 = I111 > I100;
% %         Ilog101 = I111 > I101;
% %         Ilog102 = I111 > I102;
% %         Ilog110 = I111 > I110;
% %         Ilog112 = I111 > I112;
% %         Ilog120 = I111 > I120;
% %         Ilog121 = I111 > I121;
% %         Ilog122 = I111 > I122;
% %         Ilog200 = I111 > I200;
% %         Ilog201 = I111 > I201;
% %         Ilog202 = I111 > I202;
% %         Ilog210 = I111 > I210;
% %         Ilog211 = I111 > I211;
% %         Ilog212 = I111 > I212;
% %         Ilog220 = I111 > I220;
% %         Ilog221 = I111 > I221;
% %         Ilog222 = I111 > I222;
%
%     end
%
%
% end



Nlocmax = length(ilocmax);
Nvox = size(I,1)*size(I,2)*size(I,3);
disp(['found ',num2str(Nlocmax),' local maxima (',num2str(Nlocmax/Nvox*100),' % of all ',num2str(Nvox),' voxels or pixels)']);


