% Ad-hoc Script to localize TetraSpec beads in different color channels
% to evaluate chromatic aberration

function locate_beads
clc, clear all, close all;

global Ngmm;
global Nvox;
global sigma_xy2;
global sigma_z2;
global swapRG;

disp('Detect multi-labeled beads to assess chromatic shifts');
disp('Warning: this program is still experimental !');

%% User settings

real_or_simulated_beads = questdlg('What kind of bead image ?','','Real beads','Simulated beads','Real beads');
if strcmp(real_or_simulated_beads,'Real beads')

    [tiffile,dir_input] = uigetfile('*.*','Select the single tif image file');     cd(dir_input);
    Nchannels = str2num(questdlg('How many channels (1,2 or 3) ?','','1','2','3','1'));
    if Nchannels == 3
        default_values = {'1.33', '1.4', '3', '0.0773', '0.0773', '0.15','0.37','0.37','0.5','0.5','0.58','0.58'};
    else
        default_values = {'1.33', '1.4', num2str(Nchannels) , '0.0645', '0.0645', '0.2','0.57','0.57','0.56','0.6','','','0','10','100','0.5'};
    end

else
    [matfile,dir_input] = uigetfile('*.*','Select the matlab file of the simulated beads');     cd(dir_input);
    disp('loading file..');
    load(matfile);
    disp('file loaded');
    default_values = {num2str(n),num2str(NA),'1',num2str(dx),num2str(dy),num2str(dz),num2str(sim_params.lambda1ex),num2str(sim_params.lambda1em),num2str(sim_params.lambda2ex),num2str(sim_params.lambda2em),'','','0','10','100','0.5'};
    info = matfile;
end

prompt = {'refractive index n of the sample medium:', ...
    'numerical aperture NA of the objective lens:', ...
    'number of channels', ...
    'voxel dimension along x in microns', ...
    'voxel dimension along y in microns',...
    'voxel dimension along z in microns', ...
    'excitation wavelength for channel 1 in microns', ...
    'emission wavelength for channel 1 in microns', ...
    'excitation wavelength for channel 2 in microns', ...
    'emission wavelength for channel 2 in microns', ...
    'excitation wavelength for channel 3 in microns', ...
    'emission wavelength for channel 3 in microns', ...
    ' IGNORE ', ...
    'maximum number of beads possible per subfield', ...
    'max. width and height of subfield in pixels', ...
    'maximum lateral distance between beads for nearest neighbour matching (mu)'
    };
answer = inputdlg(prompt,'Check microscopy parameters',1,default_values);
n = str2num(answer{1});
NA = str2num(answer{2});
Nchannels = str2num(answer{3});
dx = str2num(answer{4});
dy = str2num(answer{5});
dz = str2num(answer{6});
lambda1ex = str2num(answer{7});
lambda1em = str2num(answer{8});
lambda2ex = str2num(answer{9});
lambda2em = str2num(answer{10});
lambda3ex = str2num(answer{11});
lambda3em = str2num(answer{12});
lambdasex = [lambda1ex lambda2ex lambda3ex];
lambdasem = [lambda1em lambda2em lambda3em];
nb_beads_rescue = str2num(answer{13});
nb_beads_max = str2num(answer{14});
subfield_width_max = str2num(answer{15});
max_dist_NNmatch = str2num(answer{16});

detrend = questdlg('Detrend using other bead image ?','','Yes','No','No');
if strcmp(detrend,'Yes')
    [other_bead_matfile,dir_input] = uigetfile('*.*','Select the matlab file produced for the other bead images');     dir0 = cd; cd(dir_input); load(other_bead_matfile,'CSx_a','CSx_b','CSx_c','CSy_a','CSy_b','CSy_c','CSz_a','CSz_b','CSz_c'); cd(dir0);
end

%% Import the images
if strcmp(real_or_simulated_beads,'Real beads')
    disp('loading the image ...');
    if Nchannels == 3
        [Icrop, Iinfo] = importtif2(tiffile,3);
    else
        [Icrop, Iinfo] = importtif(tiffile,Nchannels);
        swapRG = 1;
    end
    info = Iinfo(1).Filename;
end

Nx = size(Icrop,1);
Ny = size(Icrop,2);
Nz = size(Icrop,3);
Nvox = Nx*Ny*Nz;

%% Define axes
xx = 0:dx:(Nx-1)*dx;
yy = 0:dy:(Ny-1)*dy;
zz = 0:dz:(Nz-1)*dz;

%% Show bead image
wb =    waitbar(0,'Displaying image..');
fig_each_channel = figure('Name','Original image by channel (projections)');
for ich =1:Nchannels
    subplot(2,Nchannels,ich); show_maxintproj(Icrop(:,:,:,ich),xx,yy,zz,'xy',['channel ',num2str(ich)]);
    subplot(2,Nchannels,Nchannels + ich); show_maxintproj(Icrop(:,:,:,ich),xx,yy,zz,'xz',['channel ',num2str(ich)]);
end

%% Show maximum intensity projections
figxy = figure('Name','Multi-color image (xy projection) with detection and chromatic shift');
show_maxintproj(Icrop,xx,yy,zz,'xy',info); %colormap(jet)
title('all channels');

figxz = figure('Name','Multi-color image (xz projection) with detection and chromatic shift');
show_maxintproj(Icrop,xx,yy,zz,'xz',info); %colormap(jet)
axis normal;
title('all channels');

%% Compute PSF kernels
for ich =1:Nchannels
    [sigma_xy(ich), sigma_z(ich)] = sigma_PSF_BoZhang(lambdasex(ich),lambdasem(ich),NA,n,'widefield');
    [sigmas_xy2(ich), sigmas_z2(ich)] = deal(sigma_xy(ich)^2, sigma_z(ich)^2);
    PSFkernel{ich} = gaussian_kernel(sigma_xy(ich)/dx,sigma_z(ich)/dz,'energy');
end

%% Now detect beads independently in each color channel
wb = waitbar(0,'Starting detection..');
% I = zeros(size(squeeze(Icrop(:,:,:,1))),'double'); % pre-allocation to avoid memory errors (??)
% Ismooth = I;
Nsf_rows = ceil(Nx/subfield_width_max);
Nsf_cols = ceil(Ny/subfield_width_max);
Nx_sf = floor(Nx/Nsf_rows);
Ny_sf = floor(Ny/Nsf_cols);
N_subfields = Nsf_cols * Nsf_rows ;
[xbeads1_all ybeads1_all zbeads1_all Abeads1_all xbeads2_all ybeads2_all zbeads2_all Abeads2_all xbeads3_all ybeads3_all zbeads3_all Abeads3_all ] = deal([],[],[],[],[],[],[],[],[],[],[],[]);
[CSx_all_nm CSy_all_nm CSz_all_nm] = deal([],[],[]);
for isf = 1:N_subfields
    %% Get subfield
    [irow_sf, icol_sf] = ind2sub([Nsf_rows Nsf_cols],isf);
    [i1, i2, j1, j2] = deal((irow_sf-1)*Ny_sf+1, min(irow_sf*Ny_sf,Nx), (icol_sf-1)*Nx_sf+1, min(icol_sf*Nx_sf, Ny));
    xx_sf = xx(i1:i2); yy_sf = yy(j1:j2);
    % Highlight subfield
    if 1==1, figure(figxy), [x1 y1 z1] = ijk2xyz(i1,j1,1,xx,yy,zz); [x2 y2 z2] = ijk2xyz(i2,j2,1,xx,yy,zz); rectangle('Position',[x1, y1, x2-x1, y2-y1],'Curvature',[0.1 0.1],'EdgeColor','c'); end
    for ich = 1:Nchannels
        aux = ['Processing subfield ',num2str(isf),'/',num2str(N_subfields),', channel ',num2str(ich),'/',num2str(Nchannels),'....'];
        waitbar(0,wb,aux); disp(aux);

        Isf = double(Icrop(i1:i2,j1:j2,:,ich));
        if 1==1
            [nb_beads, ibead, jbead, kbead, xbead_rough, ybead_rough, zbead_rough, Abead_rough, failed] = predetect_spots(Isf,PSFkernel{ich},sigma_xy(ich),sigma_z(ich),dx,dy,dz,xx_sf,yy_sf,zz,nb_beads_max,'spottiness');
        else
            [nb_beads, ibead, jbead, kbead, xbead_rough, ybead_rough, zbead_rough, Abead_rough, failed] = predetect_spots(Isf,PSFkernel{ich},sigma_xy(ich),sigma_z(ich),dx,dy,dz,xx_sf,yy_sf,zz,nb_beads_max,'NP');
        end

        %% Refine the position and intensity of the beads
        switch 3
            case 1
                parameters.bead_localization_method = 'model fitting';
            case 2
                parameters.bead_localization_method = 'single particle fit';
            case 3
                parameters.bead_localization_method = 'intensity-weighted';
        end
        parameters.bead_centroid_threshold_percentage = 0;

        aux = 'Refining bead locations ..'; waitbar(0,wb,aux); disp(aux);
        clear xbead ybead zbead Abead B;
        sigma_xy2 = sigmas_xy2(ich); sigma_z2 = sigmas_z2(ich); 
        [xbead, ybead, zbead, Abead, B] = subpixelic_spot_localization(ibead,jbead,kbead,xbead_rough,ybead_rough,zbead_rough,Abead_rough,Isf,sigma_xy(ich),sigma_z(ich),dx,dy,dz,xx_sf,yy_sf,zz,parameters.bead_localization_method,parameters.bead_centroid_threshold_percentage);

        % Plot detected positions on image
        if ich==1
            xbeads1_sf = xbead; ybeads1_sf = ybead; zbeads1_sf = zbead; Abeads1_sf = Abead;
            figure(figxy),plot(xbead,ybead,'+g');
            text(x1+(x2-x1)/2,y1+(y2-y1)/2,num2str(nb_beads),'Color','g','HorizontalAlignment','left');
        elseif ich==2
            xbeads2_sf = xbead; ybeads2_sf = ybead; zbeads2_sf = zbead; Abeads2_sf = Abead;
            figure(figxy),plot(xbead,ybead,'or');
            text(x1+(x2-x1)/2,y1+(y2-y1)/2,num2str(nb_beads),'Color','r','HorizontalAlignment','right');
        elseif ich==3
            xbeads3_sf = xbead; ybeads3_sf = ybead; zbeads3_sf = zbead; Abeads3_sf = Abead;
        end
    end

    %% Compute chromatic shifts
    if Nchannels>1
        if ~isempty(xbeads1_sf) && ~isempty(xbeads2_sf)
            aux = 'Doing nearest neighbour matching between detected beads of channels 1 and 2..';
            waitbar(0,wb,aux); disp(aux);
            % do a permutation on the detected positions to get a close match
            [xbeads1_sf ybeads1_sf zbeads1_sf xbeads2_sf ybeads2_sf zbeads2_sf Nunmatched] = nearest_neighbour_matching(xbeads1_sf,ybeads1_sf,zbeads1_sf,xbeads2_sf,ybeads2_sf,zbeads2_sf, max_dist_NNmatch);

            if Nunmatched>0, disp(['Could not match ',num2str(Nunmatched),' out of ',num2str(length(xbeads1_sf)),' beads !']); end

            if 1==1 % show segments between detected pairs
                figure(figxy);
                for i=1:min(length(xbeads1_sf),length(xbeads2_sf)), line([xbeads1_sf(i) xbeads2_sf(i)],[ybeads1_sf(i) ybeads2_sf(i)],'Color','y'); end
            end

            %% Compute Chromatic shift
            [CSx_sf_nm, CSy_sf_nm, CSz_sf_nm] = deal(1000*(xbeads2_sf-xbeads1_sf), 1000*(ybeads2_sf-ybeads1_sf), 1000*(zbeads2_sf-zbeads1_sf));
        else
            [CSx_sf_nm, CSy_sf_nm, CSz_sf_nm] = deal([],[],[]);
        end

    end

    %% Collect the results from the subfield
    xbeads1_all = [xbeads1_all xbeads1_sf]; ybeads1_all = [ybeads1_all ybeads1_sf]; zbeads1_all = [zbeads1_all zbeads1_sf]; Abeads1_all = [Abeads1_all Abeads1_sf];
    if exist('xbeads2_sf','var');
        xbeads2_all = [xbeads2_all xbeads2_sf]; ybeads2_all = [ybeads2_all ybeads2_sf]; zbeads2_all = [zbeads2_all zbeads2_sf]; Abeads2_all = [Abeads2_all Abeads2_sf];
    end
    if exist('CSx_sf_nm','var')
        CSx_all_nm = [CSx_all_nm CSx_sf_nm]; CSy_all_nm = [CSy_all_nm CSy_sf_nm]; CSz_all_nm = [CSz_all_nm CSz_sf_nm];
    end
end

%% Plot detected positions on image; for simulated images, also show ground
%% truth

if Nchannels==2
    detection_markers = {'sg', 'or'};
else
    detection_markers = {'dc', 'sg', 'or'};
end

%% Plot detections on the image (xy view)
if 1==0
    figure(figxy);
    plot(xbeads1_all,ybeads1_all,detection_markers{1},'MarkerSize',20);
    hold on;
    if exist('xbeads2','var')
        plot(xbeads2,ybeads2,detection_markers{2},'MarkerSize',20);
    end
    if exist('xbeads3','var') && ~isempty(xbeads3)
        plot(xbeads3,ybeads3,detection_markers{3},'MarkerSize',20);
    end

    if exist('groundtruth','var')
        plot(groundtruth.xgene,groundtruth.ygene,'+r','MarkerSize',20);
        title('red crosses show ground truth');
    end
end

%% Plot detections on the image (xz view)
if 1==0
    figure(figxz);
    plot(xbeads1_all,zbeads1_all,detection_markers{1},'MarkerSize',20);
    hold on;
    if exist('xbeads2','var')
        plot(xbeads2,zbeads2,detection_markers{2},'MarkerSize',20);
    end
    if exist('xbeads3','var') && ~isempty(xbeads3)
        plot(xbeads3,zbeads3,detection_markers{3},'MarkerSize',20);
    end
    if exist('groundtruth','var')
        plot(groundtruth.xgene,groundtruth.zgene,'+r','MarkerSize',20);
        title('red crosses show ground truth');
    end
end


%% Plot detected positions without the image
figure('Name','Detected bead positions  in 3D');
plot3(xbeads1_all,ybeads1_all,zbeads1_all,detection_markers{1},'MarkerSize',20);
hold on;
if exist('xbeads2_all','var')
    plot3(xbeads2_all,ybeads2_all,zbeads2_all,detection_markers{2},'MarkerSize',20);
end
if exist('xbeads3_all','var') && ~isempty(xbeads3_all)
    plot3(xbeads3_all,ybeads3_all,zbeads3_all,detection_markers{3},'MarkerSize',20);
end

axis equal;
xlabel('x(mu)'); ylabel('y(mu)'); zlabel('z(mu)'); xlim([min(xx) max(xx)]); ylim([min(yy) max(yy)]); zlim([min(zz) max(zz)]);

%% Display chromatic shifts
if Nchannels>1
    %% Remove outliers
    if 1==1
        aux = 'Removing outliers in chromatic shift..';
        waitbar(0,wb,aux); disp(aux);
        [CSx_filtered_nm, Noutx] = nanify_outliers(CSx_all_nm);
        disp(['removed ',num2str(Noutx),'/',num2str(length(CSx_all_nm)),' outliers for x-component of chromatic shift']);
        [CSy_filtered_nm, Nouty] = nanify_outliers(CSy_all_nm);
        disp(['removed ',num2str(Nouty),'/',num2str(length(CSy_all_nm)),' outliers for y-component of chromatic shift']);
        [CSz_filtered_nm, Noutz] = nanify_outliers(CSz_all_nm);
        disp(['removed ',num2str(Noutz),'/',num2str(length(CSz_all_nm)),' outliers for z-component of chromatic shift']);
    end

    %% Display several quiver plots of the chromatic shift
    figure(figxy);
    quiver(xbeads1_all,ybeads1_all,CSx_filtered_nm,CSy_filtered_nm,'Color','w');

    figure(figxz);
    quiver(xbeads1_all,zbeads1_all,CSx_filtered_nm,CSz_filtered_nm,'Color','w');

    %% Interpolating chromatic shifts across the field of view
    aux = 'interpolating over the field...'; disp(aux)
    [xxm,yym] = meshgrid(linspace(xx(1),xx(end),50),linspace(yy(1),yy(end),50));
    CSx_filtered_interp_nm = griddata(xbeads1_all,ybeads1_all,CSx_filtered_nm,xxm,yym);
    CSy_filtered_interp_nm = griddata(xbeads1_all,ybeads1_all,CSy_filtered_nm,xxm,yym);
    CSz_filtered_interp_nm = griddata(xbeads1_all,ybeads1_all,CSz_filtered_nm,xxm,yym);

    %% Display shifts as surfaces
    fig_surfchromshift = figure('Name','Surface plots of chromatic shifts');
    subplot(3,1,1); mesh(xxm,yym,CSx_filtered_interp_nm,'EdgeColor','k','FaceColor','interp'); title(['x-component of chromatic shift']);  xlabel('x (mu)'); ylabel('y (mu)');
    subplot(3,1,2); mesh(xxm,yym,CSy_filtered_interp_nm,'EdgeColor','k','FaceColor','interp'); title(['y-component of chromatic shift']);  xlabel('x (mu)'); ylabel('y (mu)');
    subplot(3,1,3); mesh(xxm,yym,CSz_filtered_interp_nm,'EdgeColor','k','FaceColor','interp'); title(['z-component of chromatic shift']);  xlabel('x (mu)'); ylabel('y (mu)');

    %% Display statistics on chromatic shifts
    fig_statchromshift = stat_plot(CSx_filtered_nm,CSy_filtered_nm,CSz_filtered_nm);
    set(fig_statchromshift,'Name','Statistics on chromatic shifts');

    %% Show quiver plots
    [fig_chromshift_xyz fig_chromshift_z fig_chromshift_xy] = quiverplots_chromshift(xbeads1_all,ybeads1_all,zbeads1_all,CSx_filtered_nm,CSy_filtered_nm,CSz_filtered_nm,'');


end


%% Display statistics on z-localization
if 1==1
    aux = 'Removing outliers in z-localization ..';
    waitbar(0,wb,aux); disp(aux);
    [zbeads1_filtered, Nout] = nanify_outliers(zbeads1_all);
    disp(['removed ',num2str(Nout),'/',num2str(length(zbeads1_all)),' outliers for z-position of channel 1']);
    [zbeads2_filtered, Nout] = nanify_outliers(zbeads2_all);
    disp(['removed ',num2str(Nout),'/',num2str(length(zbeads2_all)),' outliers for z-position of channel 2']);
end
fig_statsloc = figure('Name','Statistics on localization in z');
subplot(2,2,1); hist(zbeads1_filtered); xlabel('z (mu)'); legend('channel 1'); title(['mean = ',num2str(nanmean(zbeads1_filtered)),'mu, std = ',num2str(1000*nanstd(zbeads1_filtered)),'nm (N=',num2str(length(zbeads1_filtered)),')']);
subplot(2,2,2); hist(zbeads2_filtered); xlabel('z (mu)'); legend('channel 2'); title(['mean = ',num2str(nanmean(zbeads2_filtered)),'mu, std = ',num2str(1000*nanstd(zbeads2_filtered)),'nm (N=',num2str(length(zbeads2_filtered)),')']);


%% Correct for global trends
if Nchannels>1
    disp('Removing global linear trend to chromatic shifts..');
    % Make linear fits to the chromatic shifts
    % (a*x+b*y)
    if exist('CSx_a','var')
        disp('Using fit computed from another bead image !!!!');
    else
        disp('Computing the trend from this image !!!');
        [CSx_a CSx_b CSx_c] = fit_plane(CSx_filtered_nm,xbeads1_all,ybeads1_all);
        [CSy_a CSy_b CSy_c] = fit_plane(CSy_filtered_nm,xbeads1_all,ybeads1_all);
        [CSz_a CSz_b CSz_c] = fit_plane(CSz_filtered_nm,xbeads1_all,ybeads1_all);
    end
    disp(['Fitted parameters for x-component of chromatic shift: a=',num2str(CSx_a),'nm, b=',num2str(CSx_b),', c=',num2str(CSx_c)]);
    disp(['Fitted parameters for y-component of chromatic shift: a=',num2str(CSy_a),'nm, b=',num2str(CSy_b),', c=',num2str(CSy_c)]);
    disp(['Fitted parameters for z-component of chromatic shift: a=',num2str(CSz_a),'nm, b=',num2str(CSz_b),', c=',num2str(CSz_c)]);

    % Remove the fitted trends
    CSx_filtered_detrended_nm = CSx_filtered_nm - (CSx_c + CSx_a*xbeads1_all + CSx_b*ybeads1_all);
    CSy_filtered_detrended_nm = CSy_filtered_nm - (CSy_c + CSy_a*xbeads1_all + CSy_b*ybeads1_all);
    CSz_filtered_detrended_nm = CSz_filtered_nm - (CSz_c + CSz_a*xbeads1_all + CSz_b*ybeads1_all);

    %% Display statistics on chromatic shifts
    fig_statchromshift_detrended = stat_plot(CSx_filtered_detrended_nm,CSy_filtered_detrended_nm,CSz_filtered_detrended_nm);
    set(fig_statchromshift_detrended,'Name','Statistics on detrended chromatic shifts');

    %% Show quiver plots
    [fig_chromshift_detrended_xyz fig_chromshift_detrended_z fig_chromshift_detrended_xy] = quiverplots_chromshift(xbeads1_all,ybeads1_all,zbeads1_all,CSx_filtered_detrended_nm,CSy_filtered_detrended_nm,CSz_filtered_detrended_nm,' (detrended)');

end

%% For simulated images, analyse localization errors
if exist('groundtruth','var')
    % First, do a nearest neighbour matching of the detected beads and the
    % true positions
    [xgt, ygt, zgt, Agt, Bgt] = deal(groundtruth.xgene, groundtruth.ygene, groundtruth.zgene, groundtruth.Agene, groundtruth.Abackground);
    points1 = [xbeads1_all(:) ybeads1_all(:) zbeads1_all(:)];
    points2 = [xgt(:) ygt(:) zgt(:)];
    aux = 'doing nearest neighbour matching ..'; waitbar(0,wb,aux); disp(aux);
    sigma = pair_close_positions_2(points1,points2,Inf);
    % do a permutation on the detected positions to match the groundtruth
    % positions
    [xgt, ygt, zgt]  = deal( xgt(sigma), ygt(sigma), zgt(sigma)  );
    % Display numbers on  image to check nearest neighbour matching
    figure(figxy);
    for i=1:length(xbeads1_all), text(xbeads1_all(i),ybeads1_all(i),num2str(i),'Color','c');end
    for i=1:length(xgt), text(xgt(i),ygt(i),num2str(i),'Color','r','HorizontalAlignment','right');end
    % Compute error statistics
    xerr = xbeads1_all(:)' - xgt;
    yerr = ybeads1_all(:)' - ygt;
    zerr = zbeads1_all(:)' - zgt;
    Aerr_rel = (Abeads1_all(:)' - Agt)./Agt;
    disp(['Mean localization error in x = ',num2str(mean(xerr)*1000),' nm, std. dev. = ',num2str(round(std(xerr)*1000)),' nm']);
    disp(['Mean localization error in y = ',num2str(mean(yerr)*1000),' nm, std. dev. = ',num2str(round(std(yerr)*1000)),' nm']);
    disp(['Mean localization error in z = ',num2str(mean(zerr)*1000),' nm, std. dev. = ',num2str(round(std(zerr)*1000)),' nm']);
    disp(['Mean relative error in the spot intensity = ',num2str(Aerr_rel*100),' %, std. dev. = ',num2str(round(std(Aerr_rel)*100)),' %']);
end

%% For simulated images, reconstruct the theoretical bead image from the localization result
if exist('groundtruth','var')
    %%% Compute the estimated model image
    Ngmm = length(xbeads1_all);
        sigma_xy2 = sigma_xy(1)^2; sigma_z2 = sigma_z(1)^2; 
        for i=1:Nx, x = xx(i); for j = 1:Ny, y = yy(j);for k=1:Nz, z = zz(k);Imodel(i,j,k) = gaussian_mixture_model(x,y,z,xbeads1_all,ybeads1_all,zbeads1_all,Abeads1_all,B);end,end,end
    %%% Compute the model image from the groundtruth
    if 1==0
        for i=1:Nx,x = xx(i); for j = 1:Ny,y = yy(j);for k=1:Nz,z = zz(k);Imodel_gt(i,j,k) = gaussian_mixture_model(x,y,z,xgt,ygt,zgt,Agt,Bgt);end,end,end
    else

        Imodel_gt = Ispots(Bgt,xx,yy,zz,xgt,ygt,zgt,Agt,sigma_z,sigma_xy2,sigma_z2);
    end
    %    show_image_thomann(Imodel,xx,yy,zz,['model (Nspots=',num2str(Nspots),') image']);
    %%% Compute the residual of the estimated model image (difference with
    %%% the real image)
    Iresidual = abs(Icrop - Imodel);
    %%% Compute the theoretically expected residual of the model from the
    %%% ground truth
    Iresidual_gt = abs(Icrop - Imodel_gt);
    figmod = figure;
    subplot(2,2,1); show_maxintproj(Icrop,xx,yy,zz,'xy','Input image'); colorbar;
    subplot(2,2,2); show_maxintproj(Imodel,xx,yy,zz,'xy','Model image'); colorbar;
    subplot(2,2,3); show_maxintproj(Iresidual,xx,yy,zz,'xy','Residual'); colorbar;
    subplot(2,2,4); show_maxintproj(Iresidual_gt,xx,yy,zz,'xy','Theoretical residual'); colorbar;

end

%%  Save the results
if exist('tiffile','var');
    aux = tiffile;
else
    aux = matfile;
end
[pathstr, name, ext, versn] = fileparts(aux);
outputdirname = [name,'_results'];
waitbar(0,wb,['Saving processing results to folder ',outputdirname,'..']);
mkdir(outputdirname); cd(outputdirname); save;

delete(wb);
disp('saving figures ...');
save_all_figures;
disp('End of program');

end

%% Flag outliers with NaN
function [x,  Nout] = nanify_outliers(x);
[iout, Nout] = outliers(x);
x(iout) = NaN;
end

%% Return indices of outliers
function [iout, Nout] = outliers(x);
med = median(x);
aux = iqr(x);
x1= med-2*aux; x2 = med+2*aux;
iout = union(find(x<x1),find(x>x2));
Nout = length(iout);
end


%% Nearest neighbour matching
% Apply a permutation to the points (x1,y1,z1) or (x2,y2,z2) to get a best
% match of relative distances
% Nanify values that could not be matched within the specified maximum
% distance
function [x1out y1out z1out x2out y2out z2out Nunmatched] = nearest_neighbour_matching(x1,y1,z1, x2,y2,z2, max_dist);

points1 = [x1(:) y1(:)];
points2 = [x2(:) y2(:)];

if size(points2,1)<=size(points1,1)
    sigma = pair_close_positions_2(points1,points2, max_dist);

    % do a permutation on the detected positions to get a close match
    i_matched = ~isnan(sigma);

    x1out = x1(i_matched); y1out = y1(i_matched); z1out = z1(i_matched);
    sigma_matched = sigma(i_matched);
    x2out = x2(sigma_matched); y2out = y2(sigma_matched); z2out = z2(sigma_matched);
else
    sigma = pair_close_positions_2(points2,points1,max_dist);

    % do a permutation on the detected positions to get a close match
    i_matched = ~isnan(sigma);

    x2out = x2(i_matched); y2out = y2(i_matched); z2out = z2(i_matched);
    sigma_matched = sigma(i_matched);
    x1out = x1(sigma_matched); y1out = y1(sigma_matched); z1out = z1(sigma_matched);
end

Nunmatched = length(sigma)-length(i_matched);
end

%% Fit a plane to a set of scalars U(x,y) defined at positions (x,y)
function [a b c] = fit_plane(U,x,y);
x = x(:); y = y(:); U = U(:);
if length(x)~=length(U) || length(y)~=length(U) || length(x)~=length(y)
    whos
    error('Vector sizes must match!');
end
% remove NaN elements
ix = find(~isnan(x)); iy = find(~isnan(y)); iU = find(~isnan(U));
i = intersect(ix,intersect(iy,iU));
x = x(i); y = y(i); U = U(i);
% do linear least squares fit
X = [ones(size(x)) x(:) y(:)];
P = X\U;
[c a b] = deal(P(1),P(2),P(3));
end

%% Display statistics
function fig_stats = stat_plot(Cx,Cy,Cz);
fig_stats = figure;
subplot(3,3,1); hist(Cx); xlabel('x-shift (nm)'); title(['mean = ',num2str(nanmean(Cx)),'nm, std = ',num2str(nanstd(Cx)),'nm (N=',num2str(length(Cx)),')']);
subplot(3,3,2); hist(Cy); xlabel('y-shift (nm)');  title(['mean = ',num2str(nanmean(Cy)),'nm, std = ',num2str(nanstd(Cy)),'nm (N=',num2str(length(Cy)),')']);
subplot(3,3,3); hist(Cz); xlabel('z-shift (nm)');  title(['mean = ',num2str(nanmean(Cz)),'nm, std = ',num2str(nanstd(Cz)),'nm (N=',num2str(length(Cz)),')']);
subplot(3,3,4); boxplot(Cx,'orientation','horizontal'); xlabel('x-shift (nm)');
subplot(3,3,5); boxplot(Cy,'orientation','horizontal'); xlabel('y-shift (nm)');
subplot(3,3,6); boxplot(Cz,'orientation','horizontal'); xlabel('z-shift (nm)');
end


%% Create quiverplots
function [fig_chromshift_xyz fig_chromshift_z fig_chromshift_xy] = quiverplots_chromshift(xpos,ypos,zpos,Ux,Uy,Uz,label);
fig_chromshift_xyz = figure('Name',['Quiver plot of chromatic shifts',label]);
quiver3(xpos,ypos,zpos ,Ux,Uy,Uz);
%     for i=1:length(xbeads1),
%         text(xbeads(i),ybeads1(i),zbeads1(i),['(',num2str(round(CSx_all_nm(i))),',',num2str(round(CSy_all_nm(i))),',',num2str(round(CSz_all_nm(i))),')']);
%     end
xlabel('x (mu)');     ylabel('y (mu)');     zlabel('z (mu)');
axis equal;

fig_chromshift_z = figure('Name',['Axial chromatic shifts',label]);
quiver(xpos,ypos,0*Uz,Uz);
xlabel('x (mu)');     ylabel('y (mu)');     axis equal;
title(['Axial chromatic shift (max =',num2str(max(Uz)),' nm']);

fig_chromshift_xy = figure('Name',['Lateral chromatic shifts',label]);
quiver(xpos,ypos,Ux,Uy);
xlabel('x (mu)');     ylabel('y (mu)');     axis equal;
title(['Lateral chromatic shift (max =',num2str(max(Ux)),',', num2str(max(Uy)),' nm']);

end

%% Estimate background noise parameters (mean and standard deviation)
function [muN, sigmaN] = estimate_bk_noise(I);

% first nanify outliers (e.g. bright objects)
[I1,  Nout] = nanify_outliers(I(:));

% Get the mean and standard deviation of the remaining data
muN = nanmean(I1);
sigmaN = nanstd(I1);

end

%% Compute Neyman-Pearson threshold for the correlation image
function Ith = NP_correlation_threshold(S,muN,sigmaN,alpha);

% S is the expected signal
S1 = sum(S(:));
S2 = sqrt(sum(S(:).*S(:)));
Ith = muN*S1 + sigmaN*norminv(alpha,muN,sigmaN);

end


%% Spot predetection
function [nb_spots, ispot, jspot, kspot, xspot, yspot, zspot, Aspot, failed] = predetect_spots(I,PSFkernel,sigma_xy,sigma_z,dx,dy,dz,xx_sf,yy_sf,zz,nb_spots_max,method)

% Smooth the subimage using matched filter (PSF)
disp('smoothing the image ...');

if 1==1
    Ismooth = imfilter(I,PSFkernel,'replicate');
else
    Ismooth = imfilter3d_doublegaussian(I, sigma_xy/dx, sigma_z/dz);
end

%%% Find local maxima
[ilocmax,jlocmax,klocmax] = local_maxima_strict(Ismooth);

%%% Compute spottiness of all local maxima
if strcmp(method,'spottiness')
    aux = 'Computing scores...'; disp(aux);
    [s,kappa,Imean,ilocmax, jlocmax, klocmax, xlocmax, ylocmax, zlocmax] = spottiness(ilocmax, jlocmax, klocmax,Ismooth,sigma_xy,sigma_z,dx,dy,dz,xx_sf,yy_sf,zz);

    if 1==0 % display score ranks on image
        figure(figxy);
        for i=1:10, [x,y,z] = ijk2xyz(ilocmax(i),jlocmax(i),klocmax(i),xx(i1:i2),yy(j1:j2),zz); text(x,y,['#',num2str(i)],'Color','y'); end
    end

    %%% Threshold the scores
    aux = 'Automatic thresholding of scores..'; disp(aux);
    [s_th, gap, failed] = threshold_histogram(s,10,3)

    %%% show score histogram
    if 1==0
        fig_scores = score_histograms(s,s_th,kappa,Imean);
        aux = get(fig_scores,'Name'); set(fig_scores,'Name',[aux,' for channel ',num2str(ich)]);
    end

    nb_spots = length(s(s>=s_th));

elseif strcmp(method,'NP') % Use Neyman-Pearson thresholding of correlation image (= the smoothed image)
    % compute the correlation at the local maxima
    for i=1:length(ilocmax)
        Ismooth_locmax(i) = Ismooth(ilocmax(i),jlocmax(i),klocmax(i));
    end
    % sort the local maxima in order of decreasing correlation
    [Ismooth_locmax,i] = sort(Ismooth_locmax,'descend');
    [ilocmax, jlocmax, klocmax] = deal(ilocmax(i), jlocmax(i), klocmax(i));
    [xlocmax ylocmax zlocmax] = ijk2xyz(ilocmax,jlocmax,klocmax,xx_sf,yy_sf,zz);
    % threshold the correlation
    [muN, sigmaN] = estimate_bk_noise(I);
    alpha = 0.1 ; % TODO: move this parameter to the GUI !
    Ith = NP_correlation_threshold(PSFkernel,muN,sigmaN,alpha)
    nb_spots = length(Ismooth_locmax(Ismooth_locmax>=Ith))
    failed = 0;
    %     failed = (nb_spots==0)
    if 1==1
        figure,subplot(2,1,1);hist(Ismooth(:)); title('Ismooth'); subplot(2,1,2); hist(Ismooth_locmax); title('Ismooth_locmax');
    end
end


%%% If thresholding fails, take a specified number of spots
if failed
    nb_spots = min(nb_spots_max,length(ilocmax));
    disp(['Automated predetection failed ! I will just take the ',num2str(nb_spots),' best spots']);
end

if nb_spots>nb_spots_max
    disp(['Reducing the number of detected spots from ',num2str(nb_spots),' to ',num2str(nb_spots_max),' !!!']);
    nb_spots =nb_spots_max;
end

% disp([num2str(nb_spots),' spots detected in channel ',num2str(ich)]);
ispot = ilocmax(1:nb_spots);
jspot = jlocmax(1:nb_spots);
kspot = klocmax(1:nb_spots);
xspot = xlocmax(1:nb_spots);
yspot = ylocmax(1:nb_spots);
zspot = zlocmax(1:nb_spots);
Aspot = [];
for ib=1:nb_spots
    Aspot(ib) = I(ispot(ib),jspot(ib),kspot(ib));
end
% scorespot_rough = s(1:nb_spots);

end