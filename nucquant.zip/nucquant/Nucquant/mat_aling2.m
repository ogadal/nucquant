function [B11,B22,B33,C2]=mat_aling2(A1,A2,A3)

k=0;
for i=1:size(A1,1)
    for j=1:size(A1,2)
        k=k+1;
        B1(k)=A1(i,j);
    end
end
k=0;
for i=1:size(A2,1)
    for j=1:size(A2,2)
        k=k+1;
        B2(k)=A2(i,j);
    end
end
k=0;
for i=1:size(A3,1)
    for j=1:size(A3,2)
        k=k+1;
        B3(k)=A3(i,j);
    end
end

% i=0;
% while(B1(end-i)==0)
%     i=i+1;
% end
% k1=i;
i=0;
while(B2(end-i)==0)
    i=i+1;
end
k2=i;
i=0;
while(B3(end-i)==0)
    i=i+1;
end
k3=i;
% B11=B1(1:end-k1);
B11=B1;B22=B2(1:end-k2);B33=B3(1:end-k3);

L1=length(B22);L2=length(B33);

k=0;
for i=1:L2
    for j=1:L1
        k=k+1;
        C2(i,j)=B11(k);
    end
end