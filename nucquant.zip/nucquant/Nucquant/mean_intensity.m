% Returns the mean intensity of the image I in a volume of size Lx,Ly,Lz
% (in voxel units) centered on the voxel (i,j,k)

function Imean = mean_intensity(I,i,j,k,Lx,Ly,Lz)

[Nx Ny Nz] = size(I);

i1 = max([i-floor(Lx/2) 1]);
i2 = min([i+ceil(Lx/2) Nx]);

j1 = max([j-floor(Ly/2) 1]);
j2 = min([j+ceil(Ly/2) Ny]);

k1 = max([k-floor(Lz/2) 1]);
k2 = min([k+ceil(Lz/2) Nz]);

Iaux = I(i1:i2,j1:j2,k1:k2);

Imean = mean(Iaux(:));
