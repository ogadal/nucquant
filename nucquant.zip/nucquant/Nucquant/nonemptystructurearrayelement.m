% returns an array of Boolean flags telling if the corresponding element of the
% input structure array is empty (0 if empty, 1 if non empty) 
% also returns Nne, the number of non empty elements

function [flags, Nne] = nonemptystructurearrayelement(structure)

if ~isstruct(structure) 
    error('the input argument of nonemptystructurearrayelement must be a structure !');
end

N = length(structure);

aux = zeros(1,N);
for i=1:N
    aux(i) = ~isempty(structure(i));
end

Nne = sum(aux);
flags = aux;

    