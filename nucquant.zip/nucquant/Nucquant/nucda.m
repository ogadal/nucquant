% Nuclear localization data analysis

function nucda

close all; clear all; clc;

disp('__________________________________________');
disp(' ');
disp('nucda: Nuclear Localization Data Analysis');
disp('__________________________________________');

%% Open the mat file containing the output of nucquant_robot.m
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Please select the  result file ');
cd(PathName);


%% Ask user input
if 1==0
    aux = inputdlg({'Please enter the Z-shift due to chromatic aberration'},{'Z-shift (mu)'},1,{'0.05'});
    Zshift = str2num(aux);
else
    Zshift = str2num(input2('Please enter the Z-shift due to chromatic aberration (in microns)','0.05'));
end

%% Load file
wb = waitbar(0,['Loading ',FileName,'...']); drawnow;
disp(['Loading ',FileName,'...']);
load(FileName);
if ishandle(wb), delete(wb); end
disp([FileName,' loaded.']);

%% Convert output structure for compatibility !!
[output,output_suppl] =  convert_structures_4nucquant(output,output_suppl);

%% Import the names of the different classes
% Restrict to specific class
[aux,N] = nonemptystructurearrayelement(output);
[aux, nucleus_class, nuclei_classes] = indices_class(output,[]);

Nclasses = length(nuclei_classes);
disp(['I will show results for the following ',num2str(Nclasses),' classes:']);
for i=1:Nclasses,
    disp(nuclei_classes{i});
end


%% Show various plots
fig_cdf = figure('Name','various NPC distances');
fig_rho = figure('Name','cdf of radial distances vs. R^3');
fig_dist_NPC_nucleus = figure('Name','histogram of distance NPC-nucleus');
fig_chromatic_shift = figure('Name','z-shift between centers of nucleolus and nucleus');
% colors = 'brgcymk';
colors = jet(max(Nclasses,2));
for iclass = 1:Nclasses
    currentclass = nuclei_classes{iclass};
    [inuclei, nucleus_class, aux] = indices_class(output,currentclass);

    % Import nuclei centers
    xcnucleus = []; ycnucleus = []; zcnucleus = [];
    xcnucleus = [output(inuclei).xn];
    ycnucleus = [output(inuclei).yn];
    zcnucleus = [output(inuclei).zn];

    % Import the centroid of the nucleolus
    xcnucleolus = []; ycnucleolus = []; zcnucleolus = [];
    xcnucleolus = [output(inuclei).xcnuc] ;
    ycnucleolus = [output(inuclei).ycnuc] ;
    zcnucleolus = [output(inuclei).zcnuc] - Zshift;

    % Import the position, intensity and the number of NPCs 
    xNPC = []; yNPC = []; zNPC = []; nbNPC = [];
    xNPC = [output(inuclei).xNPC];
    yNPC = [output(inuclei).yNPC];
    zNPC = [output(inuclei).zNPC];
    ANPC = [output(inuclei).ANPC];
    nbNPC = [output(inuclei).nbNPC];
    
    % Import the half-axes of the nucleus ellipsoid
    if isfield(output(inuclei),'Rxfe')
        Rx = [output(inuclei).Rxfe];
        Ry = [output(inuclei).Ryfe];
        Rz = [output(inuclei).Rzfe];
    elseif isfield(output(inuclei),'Rfs')
        Rx = [output(inuclei).Rfs]; Ry = [output(inuclei).Rfs]; Rz = [output(inuclei).Rfs];
    else
        error('Could not find ellipsoid or sphere radius !');
    end

    % Import radial distance of NPC to nucleus center
    rho = [output(inuclei).rhoNPC];

    % compute distance between NPC and nucleus
    dist_NPC_nucleus = [];
    dist_nuclearcenter_nnNE = [];
    j=1;
    disp('computing distances of NPCs to nuclear envelope...');
    wb = waitbar(0,'computing distances NPC-NE...')
    for i2=inuclei
        a=sum(nbNPC(1:(j-1)))+1; b=sum(nbNPC(1:j)); % extract coordinates of NPCs to their corresponding nuclei
        waitbar(j/length(output),wb,['computing dist. NPC-NE for cell #',num2str(j),'/',num2str(length(output)),'...']);
        [dist_NPC_nucleus(a:b), xn, yn, zn]=distance_point2ellipsoid(xNPC(a:b)-xcnucleus(j),yNPC(a:b)-ycnucleus(j),zNPC(a:b)-zcnucleus(j),Rx(j),Ry(j),Rz(j),'true');
        output(i2).dist_NPC_nucleus = dist_NPC_nucleus(a:b);
        dist_nuclearcenter_nnNE(a:b) = sqrt(xn.^2 + yn.^2 + zn.^2);
        j=j+1;
    end
    delete(wb);

    % Import z-shift between nucleus and nucleolus
    zshift_nucleus_nucleolus = zcnucleus - zcnucleolus;

    % Compute distances between NPC and nucleolus centroid
    dist_NPC_nucleolus_centroid = [];
    for ii=inuclei
        aux = distance3d(output(ii).xNPC,output(ii).yNPC,output(ii).zNPC,output(ii).xcnuc,output(ii).ycnuc,output(ii).ycnuc);
        dist_NPC_nucleolus_centroid = [dist_NPC_nucleolus_centroid aux];
    end
    
    % Compute distances between NPC and nucleolus centroid
    dist_NPC_nucleus_centroid = [];
    
    disp('Computing the distance between NPC and nucleus center...');
    wb = waitbar(0,'computing distances NPC-NEcenter...');
    for ij=inuclei
    a=sum(nbNPC(1:(ij-1)))+1;b=sum(nbNPC(1:ij));% extract coordinates of NPCs to their corresponding nuclei
    output(ij).dist_NPC_nucleus_centroid=distance3d(xNPC(a:b),yNPC(a:b),zNPC(a:b),xcnucleus(ij),ycnucleus(ij),zcnucleus(ij));
    end
    delete(wb);

    % Histogram of distances from NPC to nucleus and others
    figure(fig_dist_NPC_nucleus);
    subplot(1,1,1);
    x=dist_NPC_nucleus;
    hist(x,100),
    xlabel('distance NPC-NE (mu)'),
    ylabel('counts'),
    legend(['N=',num2str(length(x))]);
    title(['median = ',num2str(median(x)),', iqr=',num2str(iqr(x)),' mean=',num2str(mean(x)),' std =',num2str(std(x))]);


    % Histogram of z-shifts between nuclear and nucleolar centers
    figure(fig_chromatic_shift);
    subplot(1,Nclasses,iclass);
    dz = zshift_nucleus_nucleolus;
    hist(dz,100),
    xlabel('z_{nucleus}-z_{nucleolus} (mu)'),
    ylabel('counts'),
    legend(['class = ',currentclass,' (N=',num2str(length(dz)),')']);
    title(['median = ',num2str(median(dz)),', iqr=',num2str(iqr(dz)),' mean=',num2str(mean(dz)),' std =',num2str(std(dz))]);
    % Fit a gaussian to this histogram and plot it
    if 1==0
        [muhat,sigmahat,muci,sigmaci] = normfit(x);
        aux = xlim; auxx = linspace(aux(1),aux(2)); auxy = normpdf(auxx,muhat,sigmahat); hold on; plot(auxx,auxy,'r-');
    end
    hold on;

    % Plot cdf of radial distance
    if any(~isnan(rho))
        figure(fig_rho);
        subplot(1,Nclasses,iclass);
        h = cdfplot(rho.^3);
        set(h,'Color',colors(iclass,:));
        hold on;
        xlabel('rho^3(NPC) in mu^3 ');

        figure(fig_cdf)
        subplot(3,1,1),
        h = cdfplot(rho);
        set(h,'Color',colors(iclass,:));
        hold on;
        xlabel('rho(NPC) in mu ');
    end

    subplot(3,1,2),
    if ~all(isnan(dist_NPC_nucleus))
        h = cdfplot(dist_NPC_nucleus);
        set(h,'Color',colors(iclass,:));
        hold on;
    else
        title('no data here');
    end
    xlabel('dist(NPC,nucleus) in microns');

    subplot(3,1,3),
    if exist('dist_NPC_nucleolus_centroid','var') && all(isnan(dist_NPC_nucleolus_centroid))==0
        h = cdfplot(dist_NPC_nucleolus_centroid);
        set(h,'Color',colors(iclass,:));
        hold on;
    else
        title('no data here');
    end
    xlabel('dist(NPC,nucleolus centroid) in microns');

    legend(nuclei_classes);
end




%% Compute signal-to-noise ratios
for i=1:length(output)
    aux1 = output(i).AbNPC;
    if isfield(output,'background')
        aux2 = output(i).background.std;
        output(i).SNR_bNPC_background  = aux1/aux2;
    else
        output(i).SNR_bNPC_background = NaN;
    end
end

%% Perform pair-wise KS tests and show cdf graphs for several quantities

[fig1,pKS1,ksstat1] = pairwise_KStests([output.dist_NPC_nucleus_centroid],nucleus_class,'distance NPC-nucleus center (mu)');
[fig2,pKS2,ksstat2] = pairwise_KStests([output.dist_NPC_nucleus],nucleus_class,'distance NPC-nuclear envelope (mu)');

if isfield(output,'Vnucleus_mu3')
    [fig3,pKS3,ksstat3] = pairwise_KStests([output.Vnucleus_mu3],nucleus_class,'nuclear volume (mu3)');
else
    warning(['nuclear volumes absent from this data file !']);
end
if isfield(output,'Vnuc_mu3')
    [fig4,pKS4,ksstat4] = pairwise_KStests([output.Vnuc_mu3],nucleus_class,'nucleolus volume (mu3)');
    [fig5,pKS5,ksstat5] = pairwise_KStests([output.Vnuc_mu3]./[output.Vnucleus_mu3],nucleus_class,'ratio V(nucleolus/nucleus)');
else
    warning(['nucleolar volumes absent from this data file !']);
end
if isfield(output,'Rxfe')
    [fig6,pKS6,ksstat6] = pairwise_KStests(([output.Rxfe]+[output.Ryfe]+[output.Rzfe])/3,nucleus_class,'mean radius (Rxfe+Ryfe+Rzfe)/3');
    [fig6a,pKS6a,ksstat6a] = pairwise_KStests([output.Rxfe],nucleus_class,'Rxfe');
    [fig6b,pKS6b,ksstat6b] = pairwise_KStests([output.Ryfe],nucleus_class,'Ryfe');
    [fig6c,pKS6c,ksstat6c] = pairwise_KStests([output.Rzfe],nucleus_class,'Rzfe');
else
    [fig7,pKS7,ksstat7] = pairwise_KStests([output.Rfs],nucleus_class,'sphere Rfs');
end

[fig8,pKS8,ksstat8] = pairwise_KStests([output.ANPC],nucleus_class,'A of NPC');

if isfield(output,'background')
    [fig9,pKS9,ksstat9] = pairwise_KStests([output.SNR_bNPC_background],nucleus_class,'SNR (=I(bNPC)/std(bk))');
end

if isfield(output,'nbNPC')
    [fig10,pKS10,ksstat10] = pairwise_KStests([output.nbNPC],nucleus_class,'number of "NPC"s');
end


%% Analysis of intensities
figure('Name','Intensities of NPCs, nucleoplasm and background');
A1 = [output.ANPC];
ANPCs = A1';


% Histogram of NPC intensities
if 1==0  % So the figure will be blank.
    subplot(3,3,1);
    hist(ANPCs);
    xlabel('A(NPC)');
    % Histogram of nucleoplasm intensities
    subplot(3,3,2);
    hist(Inp);
    xlabel('I(nucleoplasm)');
    NNPCs = size(ANPCs,2);
    if NNPCs>1
        Inprep = repmat(Inp,1,NNPCs);
    else
        Inprep = Inp;
    end
    % Histogram of background intensities
    subplot(3,3,3);
    if exist('Ibk','var')
        hist(Ibk);
    else
        title('not availabel!');
    end
    xlabel('I(background)');
    % Histogram of NPC intensity above nucleoplasm
    subplot(3,3,4);
    ANPC_minus_Inp = ANPCs-Inprep;
    hist(ANPC_minus_Inp);
    xlabel('A(NPC)- I(nucleoplasm)');
    % Histogram of NPC intensity relative to nucleoplasm intensity
    subplot(3,3,5);
    ANPC_over_Inp = (ANPCs-Inprep)./Inprep;
    hist(ANPC_over_Inp);
    xlabel('A(NPC)/I(nucleoplasm) - 1');
    if NNPCs>1, legend('NPC'); end
    % Scatter plot of NPC intensity vs. nucleoplasm intensity
    subplot(3,3,6);
    scatter(Inp,A1,'.')
    xlabel('I(nucleoplasm)');
    ylabel('A(NPC)');
    % Scatter plot of relative NPC intensity vs. nucleoplasm intensity
    subplot(3,3,7);
    scatter(Inp,ANPC_minus_Inp,'.')
    xlabel('I(nucleoplasm)');
    ylabel('A(NPC)-I(np)');
    % Histogram of nucleolus intensities
    subplot(3,3,8);
    if exist('Inucleolus','var')
        hist(nucleolus);
    else
        title('not available!');
    end
    xlabel('I(nucleolus)');
else
    Qintensities = diverse_quantities(output);
    fig_bp_intensities = boxplots({'Ibackground_green','Ibackground_red','Istdbackground_green','Istdbackground_red','Inucleoplasm','Inucleolus','AbNPC'},Qintensities);
end


%% Write statistics to Excel file
if 1==0
    write_statistics_to_Excel(Qintensities);
end

disp('Program finished.');
end

%% Box plots
function fig = boxplots(fields,quantities)

% Make a matrix out of the requested quantities for use in the Matlab function boxplot
Nfields = length(fields);

N = ceil(sqrt(Nfields));

aux = []; for i=1:length(fields), aux =[aux,fields{i},', ']; end

fig = figure('Name',['Boxplots of ',aux,'']);
for ifd = 1:Nfields
    subplot(N,N,ifd);
    field = fields{ifd};
    clear Q group;

    % retrieve the values, units and the label string
    if isfield(quantities(1),field)
        % retrieve the values
        for i = 1:length(quantities)
            if isfield(quantities(i),field)
                Q(i) = getfield(quantities(i),field,'value');
            end
            group{i} = getfield(quantities(i),'class');
        end
        % retrieve the units
        Qunit = getfield(quantities(1),field,'unit');
        % retrieve the label string
        Qlabel = getfield(quantities(1),field,'label');
    else
        warning(['There is no field "',field,'" here !']);
        for i = 1:length(quantities)
            Q(i) = NaN;
        end
        Qunit = NaN;
        Qlabel = 'NA !';
    end
    if ~all(isnan(Q))
        if any(isinf(Q))
            warning(['quantities "',aux,'" contain infinite numbers ! Skipping display !!']);
        else
            boxplot(Q,group','notch','on')
            line(xlim,xlim*0)
        end
    else
        legend(['All ',field,' are NaN!']);
    end
    ylabel([Qlabel,' (',Qunit,')']);
end

end

%% Gather diverse quantities
function Q = diverse_quantities(output);

for i=1:length(output)

    % Retrieve background intensities
    if isfield(output,'background') % for backwards compatibility !
        warning('the input file was generated using an old version of nucquant that does not compute background intensities for both color channels!');
        aux = output(i).background.quantiles;
        Q1 = add_quantity([],'Ibackground',aux(3),'grey level','I_background median',output(i).class);
    elseif isfield(output,'background_green')
        aux = output(i).background_green.quantiles;
        Q1 = add_quantity([],'Ibackground_green',aux(3),'grey level','I_background_green median',output(i).class);
        aux = output(i).background_red.quantiles;
        Q1 = add_quantity(Q1,'Ibackground_red',  aux(3),'grey level','I_background_red median',output(i).class);
    else
        Q1 = [];
    end

    % Retrieve standard deviation of background intensities
    if isfield(output,'background') % for backwards compatibility !
        Q1 = add_quantity(Q1,'Istdbackground',output(i).background.std,'grey level','std. dev. background ',output(i).class);
    elseif isfield(output,'background_green')
        Q1 = add_quantity(Q1,'Istdbackground_green',output(i).background_green.std,'grey level','std. dev. green background ',output(i).class);
        Q1 = add_quantity(Q1,'Istdbackground_red',output(i).background_red.std,'grey level','std. dev. red background ',output(i).class);
    end

    % Retrieve nucleoplasm intensity
    if isfield(output(i),'Inpquantiles')
        aux = output(i).Inpquantiles;
        Q1 = add_quantity(Q1,'Inucleoplasm',aux(2),'grey level','I_nucleoplasm quartile',output(i).class);
    else
        warning('Could not find Inpquantiles in this data set !');
    end

    % Retrieve nucleolus intensity
    if isfield(output(i),'Inucleolus_quantiles')
        aux = output(i).Inucleolus_quantiles;
        Q1 = add_quantity(Q1,'Inucleolus',aux(3),'grey level','I_nucleolus median',output(i).class);
    else
        warning('Could not find Inucleolus_quantiles in this data set !');
    end

    % Retrieve bNPC intensity
    Q1 = add_quantity(Q1,'AbNPC',output(i).AbNPC,'grey level','A_bNPC',output(i).class);

    % Retrieve Z-coordinate of nucleolus center
    Q1 = add_quantity(Q1,'zcnuc',output(i).zcnuc,'grey level','Z(nucleolus)',output(i).class);

    Q(i) = Q1;
end

end

%% Create Excel file with summary statistics of given quantities
function write_statistics_to_Excel(Qin)

[aux, class, classes] = indices_class(Qin,[]);

Nclasses = length(classes);
if Nclasses>1
    warning('write_statistics_to_Excel currently assumes 1 class ! Results may be rubbish !!!');
end

r = 2;
c = 1;

for ic = 1:Nclasses
    currentclass = classes{ic};
    [ii_class, aux, classes] = indices_class(Qin,currentclass);
    Q = Qin;
    Q = rmfield(Q,'class');

    M{1,1} = currentclass;
    M{5+r,1} = 'mean = ';
    M{6+r,1} = 'standard error of mean = ';
    M{7+r,1} = 'standard deviation = ';
    M{8+r,1} = 'N=';

    fields = fieldnames(Q);
    for i = 1:length(fields)
        q = [Qin(ii_class).(fields{i})];
        M{3,i+c} = q(1).label;
        M{4,i+c} = q(1).unit;
        [N,mean,sem,std] = grpstats([q.value],[],{'numel','mean','sem','std'});
        M{5+r,i+c} = mean;
        M{6+r,i+c} = sem;
        M{7+r,i+c} = std;
        M{8+r,i+c} = N;
    end

    xlswrite('nucda_statistics.xls',M, ic);

end

end


%% return class names and indices of structure array elements corresponding to a given class
function [i_class, class, classes] = indices_class(S,class1)

N = length(S);
for i=1:N,
    class{i} = S(i).class;
end
classes = unique(class);

Nclasses = length(classes);

if ~isempty(class1)
    i_class = find(ismember(class,class1));
else
    i_class = [];
end

end

%% plot histogram and statistics
function fig = histogram_and_stats(X,class,quantitystring)
x = X;
fig = figure('Name',['Histogram & stats of ',quantitystring]);
hist(x,100);
xlabel(quantitystring);
ylabel('counts');
title(['Mean = ',num2str(mean(x)),', median = ',num2str(median(x)),', std. dev. = ',num2str(std(x)),', iqr = ',num2str(iqr(x))]);
end
