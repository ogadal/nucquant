function [x,y,z, I] = nuclear_envelope_points(I3d,xx,yy,zz);

[z1 z2 I1 I2] = get_maxima_along_lines(I3d,zz);

% z1 = i2x(k1(:),zz);
% z2 = i2x(k2(:),zz);

% z1 = reshape(z1,size(I3d,1),size(I3d,2));
% z2 = reshape(z2,size(I3d,1),size(I3d,2));

x = repmat(xx(:),1,length(yy));
x = [x;x];
size(x)
x = x(:);


y = repmat(yy(:)',length(xx),1);
y = [y;y];
size(y)
y = y(:);

z= [z1;z2];
% z = z1;
size(z)
z = z(:);

I = [I1; I2];

I = I(:);


% Use intensity threshold
if 1==1
   
    Ithresh = quantile(I,0.95)/2;        % TODO: IMPROVE THIS LATER !!

    iaux = find(I>Ithresh);

    x = x(iaux);
    y = y(iaux);
    z = z(iaux);

end