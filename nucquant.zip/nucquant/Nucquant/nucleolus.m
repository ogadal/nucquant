%%% Nuclear localization and dynamics program

function [out,out_suppl] = nucleolus(parameters)


global sigma_xy2;
global sigma_z2;
global Nvox; % total number of voxels in the 3D image
global Ngmm; % number of gaussians in the gaussian mixture model
global xx; % defines the grid positions along the x-axis
global yy; % defines the grid positions along the y-axis
global zz; % defines the grid positions along the z-axis
global swapRG;
global I3d; % current volumic image for 3D rendering


% disp('Starting program nucleolus..');
matfilename_time1 = parameters.fullmatfilename;
[path, filestem, aux1] = fileparts(matfilename_time1);

% determine if this is a time sequence or a static image
dynamic = (filestem(end-4)=='t');

if dynamic
    % list the matlab files of the whole time sequence
    filestem = filestem(1:end-4);
    cd(path);% move to image folder
    % next two lines weed out folders from the listing
    aux = dir([filestem,'*']);
    %     aux1=[]; for i=1:length(aux), if aux(i).isdir==0, aux1 = [aux1 i]; end,  end
    matfiles = aux([aux.isdir]==0);
    Ntimes = length(matfiles);
    if Ntimes>1
        warning off;
        disp(['This appears to be a temporal sequence with ',num2str(Ntimes),' time steps.']);
        %         parameters.show_figures='n';
    end

    % Preallocation of output data structure for speed
    out_stat = cell(Ntimes,1);
    out_stat_suppl  = cell(Ntimes,1);
    % Initialize waitbar for time sequences
    if Ntimes>1
        wbtime = waitbar(0,'Starting time sequence ..');
        NbMonitors = size(get(0,'MonitorPosition'),1);
        if NbMonitors>1
            aux = get(wbtime,'Position');
            scrsz = get(0,'ScreenSize');
            set(wbtime,'Position',[scrsz(4) scrsz(3)/2-80 aux(3) aux(4)]);
        end
    end
    for i_time =1:Ntimes
        % Update waitbar
        if Ntimes>1
            % text for waitbar
            text4waitbar = ['Processing time point ',num2str(i_time),'/',num2str(Ntimes),' ...',];
            if i_time>1
                time_remaining_mean = seconds2timestring(ceil(mean(time_perframe)*(Ntimes-i_time+1)));
                text4waitbar = [text4waitbar,' time left ~ ',time_remaining_mean];
                if i_time>2
                    time_remaining_max = seconds2timestring(round(max(time_perframe)*(Ntimes-i_time+1)));
                    text4waitbar = [text4waitbar,' - ',time_remaining_max];
                end
            end
            waitbar((i_time-0.5)/Ntimes,wbtime,text4waitbar);
        end
        % Get mat file for this time step;
        currentmatfile = fullfile(path,matfiles(i_time).name);
        parameters.fullmatfilename = currentmatfile;
        time1 = clock;
        % Process current time point image as a static image
        [out_stat{i_time},out_stat_suppl{i_time}] = nucleolus_static(parameters);
        time_perframe(i_time) = etime(clock,time1);
        cd ..;
        if Ntimes>1, close all, end
    end
    if Ntimes==1
        out = out_stat{1}; out_suppl = out_stat_suppl{1};
    else
        out = out_stat; out_suppl = out_stat_suppl;
    end
    if exist('wbtime','var')
        delete(wbtime);
    end
    disp('finished the time sequence')
    disp(['Processing time per frame: min = ',num2str(min(time_perframe)),'s, mean = ', num2str(mean(time_perframe)),'s, max =',num2str(max(time_perframe)),' s']);
else
    [out,out_suppl] = nucleolus_static(parameters);
end
disp('------------------');


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [out, out_suppl] = nucleolus_static(parameters)

global sigma_xy2;
global sigma_z2;
global Nvox; % total number of voxels in the 3D image
global Ngmm; % number of gaussians in the gaussian mixture model
global xx; % defines the grid positions along the x-axis
global yy; % defines the grid positions along the y-axis
global zz; % defines the grid positions along the z-axis
global swapRG;
global I3d; % current volumic image for 3D rendering

% Settings
show_NPC = 'y';
show_fitted_nucleus = 'y';
show_NPC_slices = 'y';

%% Load the image and the acquisition parameters
mat_file = parameters.fullmatfilename;
disp(['Loading ',mat_file,'...']);
if parameters.cheat
    disp('!!!! Cheating !!!! (using simulation ground truth !)');
    load(mat_file,'Nx','Ny','Nz','dx','dy','dz','xx','yy','zz','input_parameters','groundtruth');
else
    load(mat_file,'Icrop','Nchannels','Nx','Ny','Nz','dx','dy','dz','xx','yy','zz','lambda','NA','n','input_parameters');
end

%% Swap the first two color channels if needed
if parameters.swap_redgreen
    disp('swapping the R and G color channels ... !!!');
    aux =     Icrop(:,:,:,1);
    Icrop(:,:,:,1) = Icrop(:,:,:,2);
    Icrop(:,:,:,2) = aux;
end

% swap display of channels for Perkin-Elmer data
swapRG =  ~exist('input_parameter','var') || ~isfield(input_parameters,'data_format') || strcmp(input_parameters.data_format,'Perkin-Elmer');

% If cheat modus used, get all results directly from the ground truth
if parameters.cheat
    [out, out_suppl] = nucleolus_cheat(xx,yy,zz,dx,dy,dz,parameters,groundtruth);
    return;
end

if 1==0 % CAUSES PROBLEMS !
    %%% If needed, fix the axes
    if xx(1)==0, xx = xx + dx/2;
        %     disp('Shifting x-axis coordinates by dx/2 !');
    end
    if yy(1)==0, yy = yy + dy/2;
        %     disp('Shifting y-axis coordinates by dy/2 !');
    end
    if zz(1)==0, zz = zz + dz/2;
        %     disp('Shifting z-axis coordinates by dz/2 !');
    end
end

Nvox = size(Icrop,1)*size(Icrop,2)*size(Icrop,3);

%% Determine if the image has one or two channels and extract the channels
if Nchannels==1
    nucleolus_exists = 'n';
    Ich1 = Icrop;
else
    nucleolus_exists = 'y';
    if Nchannels == 2 && size(Icrop,4)>2
        disp('removing empty image channels..');
        Icrop(:,:,:,3:end) = [];
    end
    Ich1 = Icrop(:,:,:,1);
    Ich2 = Icrop(:,:,:,2);
end

%% Show views of raw image
if parameters.show_figures
    fig2d_orig1 = show_2Dviews(Icrop,xx,yy,zz,'orig. image');
    place_figure(fig2d_orig1,2,2,1,1)
end

%% Smooth the image
% disp('smoothing image..');
% TODO: do this separately for the two color channels !!!
switch 1
    case 1  % Using matched filter (PSF)
        %     disp('(using gaussian PSF approximation)');
        [sigma_xy,sigma_z] = sigma_PSF_BoZhang(lambda,[],NA,n,'nipkow');
        sigma_xy2 = sigma_xy^2;
        sigma_z2 = sigma_z^2;
        I = double(Icrop);
        if 1==1
            kernel = gaussian_kernel(sigma_xy/dx,sigma_z/dz,'energy');
            %Ismoothed(:,:,:,1) = convn(Inuc,gauss_kern,'same');
            Ismooth = imfilter(I,kernel,'replicate');  % TODO: See if conversion to double required for precision !
            % TODO: see if the function smooth3 could be used instead (perhaps faster
            % ?)
        else % use my own separable (hopefully much faster) implementation of 3D gaussian filtering
            %             Ismooth = smooth3D_doublegaussian(I, sigma_xy/dx, sigma_z/dz);
            Ismooth = imfilter3d_doublegaussian(I, sigma_xy/dx, sigma_z/dz);
        end
        clear I;
    case 2   % Using averaging kernel
        disp('(using averaging kernel))');
        kernel = ones(3,3,3)/27;
end

if nucleolus_exists=='y'
    Ich2smooth = Ismooth(:,:,:,2);
end
Ich1smooth = Ismooth(:,:,:,1);

%%% Show smoothed image
if parameters.show_figures
    fig2d_smoothed= show_2Dviews(Ismooth,xx,yy,zz,'smoothed image');
    place_figure(fig2d_smoothed,2,2,2,1)
end

%% Segment the nucleolus, the NPC signal and the nucleoplasm
%if nucleolus_exists=='y' && (isfield(parameters,'process_nucleolus') && parameters.process_nucleolus)
    [Ibwnuc,threshnuc,Vnuc_vox,Inucleolus_quantiles] = segment_nucleolus(Ich2smooth,dx,dy,dz);
%end

%% Segment the nucleoplasm (green fluorescence)
[Ibwnp,threshnp,Vnp_vox,] = segment_nucleoplasm(Ich1smooth,dx,dy,dz,parameters);

% Get nucleoplasm intensities
Inpquantiles = intensity_quantiles_subcompartment(Ich1,Ibwnp);

% Volume of nucleoplasm
Vnp_mu3 = Vnp_vox*dx*dy*dz;
disp(['Volume of segmented nucleoplasm = ',num2str(Vnp_mu3),' mu3']);


%% Detect the bNPC(s) in the first channel
switch parameters.nb_bNPCs_ch1
    case {'0','1','2'}
        nb_bNPCs_ch1 = str2num(parameters.nb_bNPCs_ch1);
    otherwise
        errordlg(['number_of_bNPCs=',parameters.nb_bNPCs_ch1,' is an invalid option!']);
end

if nb_bNPCs_ch1>0
    [ibNPC,jbNPC,kbNPC,xbNPC,ybNPC,zbNPC,AbNPC,background,s,kappa,Imean,ilocmax,jlocmax,klocmax,xlocmax,ylocmax,zlocmax] = ...
        detect_bNPCs(Ich1smooth,Ich1,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,nb_bNPCs_ch1, ...
        parameters.bNPC_localization_method, parameters.bNPC_centroid_threshold_percentage);

    % Compute bNPC amplitude

    for ib=1:nb_bNPCs_ch1
        disp(['Detected bNPC #',num2str(ib),' at x=',num2str(xbNPC(ib)),', y=',num2str(ybNPC(ib)),', z=',num2str(zbNPC(ib)), ', A=',num2str(AbNPC(ib))]);
    end
else
    [xbNPC, ybNPC, zbNPC, AbNPC] = deal(NaN,NaN,NaN,NaN);
end

%% Detect the bNPC(s) in the second channel
%%% TO DO: take into account the longer wavelength !!
switch parameters.nb_bNPCs_ch2
    case {'0','1','2'}
        nb_bNPCs_ch2 = str2num(parameters.nb_bNPCs_ch2);
    otherwise
        errordlg(['number_of_bNPCs=',parameters.nb_bNPCs_ch2,' is an invalid option!']);
end

if nb_bNPCs_ch2>0
    [ibNPC_ch2,jbNPC_ch2,kbNPC_ch2,xbNPC_ch2,ybNPC_ch2,zbNPC_ch2,AbNPC_ch2,background_ch2,s_ch2,kappa_ch2,Imean_ch2,ilocmax_ch2,jlocmax_ch2,klocmax_ch2,xlocmax_ch2,ylocmax_ch2,zlocmax_ch2] = ...
        detect_bNPCs(Ich2smooth,Ich2,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,nb_bNPCs_ch2, ...
        parameters.bNPC_localization_method, parameters.bNPC_centroid_threshold_percentage);

    % Compute bNPC amplitude

    for ib=1:nb_bNPCs_ch2
        disp(['Detected bNPC #',num2str(ib),' (in channel 2) at x=',num2str(xbNPC(ib)),', y=',num2str(ybNPC(ib)),', z=',num2str(zbNPC(ib)), ', A=',num2str(AbNPC(ib))]);
    end
else
    [xbNPC_ch2, ybNPC_ch2, zbNPC_ch2, AbNPC_ch2] = deal(NaN,NaN,NaN,NaN);
end

%% Plot intensity profiles across the bNPC
%%% TO DO !

%% Detect the non-gene spots  (NPC candidates)
%%% Show histogram of scores
if parameters.detect_NPC
    if length(s)>nb_bNPCs_ch1
        s_thresh_spots = max(s(nb_bNPCs_ch1+1))*(parameters.NPC_min_score_percentage/100);
        if parameters.show_figures
            fig_histograms = score_histograms(s,s_thresh_spots,kappa,Imean);
            place_figure(fig_histograms,2,2,1,2);
        end

        [nbspot, ispot, jspot, kspot, xspot, yspot, zspot, Aspot, sspot, background] = ...
            detect_nongenespots(s,s_thresh_spots,nb_bNPCs_ch1,Imean,ilocmax,jlocmax,klocmax,xlocmax,ylocmax,zlocmax,Ich1smooth,Ich1,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,parameters.NPC_localization_method,parameters.bNPC_centroid_threshold_percentage);
    else
        disp('Could not find non-gene spots!');
        nbspot = 0;
        [ispot, jspot, kspot, xspot, yspot, zspot, Aspot, sspot, background] = deal([],[],[],[],[],[],[],[]);
    end
else
    [nbspot, ispot, jspot, kspot, xspot, yspot, zspot, Aspot, sspot] = deal([],[],[],[],[],[],[],[],[]);
end

%% Localize the centroid of the nucleoplasm and compute an estimate of the nucleoplasm intensity
if parameters.locate_nucleus_center
    [ic,jc,kc,Nvox] = intensity_weighted_centroid3D(Ich1,Ibwnp);
    [xc,yc,zc] =    ijk2xyz(ic,jc,kc,xx,yy,zz);
    disp(['Estimated centroid of the nucleoplasm : x=',num2str(xc),', y=',num2str(yc),', z=',num2str(zc)]);
else
    [xc,yc,zc] = deal(NaN,NaN,NaN);
end

%% Define NPC as spots that are not too close to the center
rho_spot = sqrt((xspot-xc).^2+(yspot-yc).^2+(zspot-zc).^2);
% Define NPC as spots that are between 0.7 and 1.8 micron from center
if parameters.detect_NPC && nbspot>0
    if parameters.NPC_are_peripheral
        disp('throwing out NPC that are not peripheral...');
        if nbspot>1
            rhoNPCmin   =    0;
            rhoNPCmax   =    5;
        else
            rhoNPCmin = rho_spot;
            rhoNPCmax = rho_spot;
        end
    else
        rhoNPCmin = 0;
        rhoNPCmax = 1000;
    end
    indexNPC = find(rho_spot>=rhoNPCmin);
    iNPCa = ispot(indexNPC);
    jNPCa = jspot(indexNPC);
    kNPCa = kspot(indexNPC);
    xNPCa = xspot(indexNPC);
    yNPCa = yspot(indexNPC);
    zNPCa = zspot(indexNPC);
    ANPCa = Aspot(indexNPC);
    sNPCa = sspot(indexNPC);
    nbNPCa = length(xNPCa);
    rho_spota = rho_spot(indexNPC);
    clear indexNPC;
    indexNPC = find(rho_spota<=rhoNPCmax);
    iNPC = iNPCa(indexNPC);
    jNPC = jNPCa(indexNPC);
    kNPC = kNPCa(indexNPC);
    xNPC = xNPCa(indexNPC);
    yNPC = yNPCa(indexNPC);
    zNPC = zNPCa(indexNPC);
    ANPC = ANPCa(indexNPC);
    sNPC = sNPCa(indexNPC);
    nbNPC = length(xNPC);
    clear iNPCa  jNPCa kNPCa xNPCa yNPCa zNPCa ANPCa sNPCa  nbNPCa
    disp(['I have found ',num2str(nbNPC),' putative NPCs']);

else
    nbNPC = 0;
end

if nbNPC==0
    %     iNPC = NaN; jNPC = NaN; kNPC = NaN;
    xNPC = NaN; yNPC = NaN; zNPC = NaN; ANPC = NaN; sNPC = 0;
end

%% Plot the radial distribution of non-gene spots and compare to a random distribution
if parameters.show_figures
    if nbspot>0
        fig_nongene_spots = figure('Name','Non-gene spots','WindowStyle','normal');
        place_figure(fig_nongene_spots,2,2,4,2);
        subplot(1,2,1);
        h = cdfplot(rho_spot); hold on; xlabel('rho (microns)');
        % theoretical distribution
        rho_max = max(rho_spot);
        aux =  linspace(0,rho_max,100);
        cdf_rho_random = (aux/rho_max).^3;
        % htheo = cdfplot(cdf_rho_random);     set(htheo,'LineSpec',':');
        plot(aux,cdf_rho_random,'g');
        legend('detected spots','theoretical, random');
        [H,p] = random_radii_in_sphere(rho_spot,0.05);
        if H==1
            aux = ['detected spots are non-randomly distributed (p=',num2str(p),')'];
        else
            aux = ['detected spots consistent with random distribution (p=',num2str(p),')'];
        end
        disp(aux);
        text(rho_max/2,0.2,aux);
        subplot(1,2,2);
        plot(rho_spot,sspot,'o');
        xlabel('rho (microns)'); ylabel('score');
    end
end

%%% Show the segmented nucleoplasm
if parameters.show_figures
    fig2d_segnp  = fig_I_and_Ibw(Ich1smooth,Ibwnp,xx,yy,zz,'nucleoplasm',xc,yc,zc);
    %     if ~isempty(fig2d_segnp), place_figure(fig2d_segnp,2,2,3,1); end
end

%% Extract the nuclear envelope

if parameters.detect_envelope
    if 1==1 %%% Use putative NPC
        xNEp = xNPC; yNEp = yNPC; zNEp = zNPC; sNEp = sNPC; nbNEp = nbNPC;

    else %%% Use the method suggested by Zvi Kam
        [xNEp,yNEp,zNEp, INEp] = nuclear_envelope_points(Ich1smooth,xx,yy,zz);
        sNEp = INEp;
        nbNEp = nbNPC;
        figure, plot3(xNEp,yNEp,zNEp,'.'), axis equal;
        set(gca,'XLim',[min(xx) max(xx)]);
        set(gca,'YLim',[min(yy) max(yy)]);
        set(gca,'ZLim',[min(zz) max(zz)]);
    end
    %%% Fit a sphere or ellipsoid to the Nuclear Envelope points
    if nbNEp>0
        %     disp('fitting parametric nucleus surface to the detected putative NPC...');
        switch parameters.nucleus_surface_fit
            case 'sphere_4param'  % Fit the 4 sphere parameters (3  coordinates of the center + radius)
                disp('(fitting both the sphere center and the radius)');
                [xn,yn,zn,Rfs,meandist_fn,residual,exitflag_fn] = fit_sphere(xNEp,yNEp,zNEp,sNEp,[xx(1) xx(end)],[yy(1) yy(end)],[zz(1) zz(end)]);
                Rxfe = Rfs;
                Ryfe = Rfs;
                Rzfe = Rfs;

            case 'sphere_1param' % Fit the sphere radius only, using the nucleoplasm centroid as the sphere center
                disp('(fitting only the sphere radius and using the center from the nucleoplasm segmentation)');
                [Rfs,meandist_fn,residual,exitflag_fn] = fit_sphere_radius(xNEp,yNEp,zNEp,sNEp,xc,yc,zc);
                [xn,yn,zn] = deal(xc,yc,zc);
                Rxfe = Rfs;
                Ryfe = Rfs;
                Rzfe = Rfs;

            case 'ellipsoid_3param' % Fit 3-parameter (Rx,Ry,Rz) axes-aligned ellipsoid
                disp('fitting a 3-parameter (Rx,Ry,Rz)  axes-aligned ellipsoid ..');
                [Rxfe,Ryfe,Rzfe,meandist_fn,residual,exitflag_fn] = fit_ellipsoid_3param(xNEp,yNEp,zNEp,sNEp,xc,yc,zc);
                [xn,yn,zn] = deal(xc,yc,zc);
        end
        nuclear_envelope_is_detected = 1;
        disp(['result of fitting nucleus surface: meandist_fn=',num2str(meandist_fn),', exitflag=',num2str(exitflag_fn)]);
    else
        Rxfe = NaN; Ryfe = NaN; Rzfe = NaN;
        [xn,yn,zn] = deal(xc,yc,zc); meandist_fn=NaN; exitflag_fn=NaN;
        nuclear_envelope_is_detected = 0;
    end
else
    nuclear_envelope_is_detected = 0;
    [xn,yn,zn] = deal(xc,yc,zc);
end

if exist('Rxfe','var')
    Vnucleus_mu3 = 4/3*pi*Rxfe*Ryfe*Rzfe;
    disp(['volume of nucleus = ',num2str(Vnucleus_mu3),' mu3']);
else
    Vnucleus_mu3 =NaN;
end

%%% Spherical coordinates
if exist('xbNPC','var')
    [thetabNPC,phibNPC,rhobNPC] = cart2sph(xbNPC-xn,ybNPC - yn,zbNPC-zn);
    [thetaNPC,phiNPC,rhoNPC] = cart2sph(xNPC-xn,yNPC - yn,zNPC-zn);
end

%% Show 3D views of segmented nucleolus or NPC
if parameters.show_figures
    if 1==1 && exist('Ibwnuc','var') % Show nucleolus and nucleoplasm
        Ibw = zeros(size(Ich1),'uint8');
        Ibw(:,:,:,2) = uint8(Ibwnp);
        Ibw(:,:,:,1) = uint8(Ibwnuc);
        fig3d_seg = show_3Dsurfaces(Ibw,xx,yy,zz,'segmented nucleolus');
        set(fig3d_seg,'Name','Nucleolus and nucleoplasm 3D view');
    else % Show nucleoplasm only
        Ibw = uint8(Ibwnp);
        fig3d_seg = show_3Dsurfaces(Ibw,xx,yy,zz,'segmented nucleoplasm');
        set(fig3d_seg,'Name','Nucleoplasm 3D view');
    end
    place_figure(fig3d_seg,2,2,4,1);
end

%% Compute nucleolus volume and centroid
if exist('Ibwnuc','var')
    [ic,jc,kc,Vnuc_vx] = intensity_weighted_centroid3D(Ich2smooth,Ibwnuc);  % volume in voxels
    [xcnuc,ycnuc,zcnuc] =    ijk2xyz(ic,jc,kc,xx,yy,zz);
    Vnuc_mu3 = Vnuc_vx*dx*dy*dz; % volume in cubic microns
    disp(['Volume of  nucleolus = ',num2str(Vnuc_mu3),' mu3, ratio to nucleus = ',num2str(Vnuc_mu3/Vnucleus_mu3)]);
    if Vnuc_mu3==0
        disp('The volume of the nucleolus is zero !!');
        nucleolus_exists = 'n';
    end
else
    Vnuc_mu3 = NaN;
    xcnuc = NaN; ycnuc = NaN; zcnuc = NaN;
end

%% Compute distances of each nucleolus voxel to the nucleolus boundary
% and centroid
if exist('Ibwnuc','var') && 0==1
    nuc_voxels_to_border_dist = distances_to_border(Ibwnuc,xx,yy,zz);
    % show the cdf of these distances
    if parameters.show_figures
        fig_cdf_nucleolus = figure('Name','intranucleolar distances','WindowStyle','normal');
        cdfplot(nuc_voxels_to_border_dist);
        xlabel('nucleolar voxel to border distance (mu)');
    end
end

%% Compute isosurface of segmented nucleolus
if exist('Ibwnuc','var') && 1==0
    figure,
    aux = permute(Ibwnuc,[2 1 3]);
    [faces_nuc, vertices_nuc] = isosurface(xx,yy,zz,aux,0.5);
    title('Isosurface of segmented nucleolus');
end

%% Measure background characteristics
% first try delimit a region of the image that is likely to contain only
% background voxels (ONLY VALID IF NUCLEI ARE CROPPED GENEROUSLY!)
background_green = background_characteristics(Ich1);
if exist('Ich2','var')
    background_red = background_characteristics(Ich2);
else
    background_red = [];
end


%% Show detected NPCs in 2D and 3D views
if parameters.show_figures
    figure(fig3d_seg); hold on;
    [xs,ys,zs] = sphere;
    rs = 1/10;


    %%% Show detected NPC as small blue spheres on 3D view
    if show_NPC =='y'
        for i = 1:nbNPC
            rs = 1/20*(1+(sNPC(i)-sNPC(nbNPC))/(sNPC(1)-sNPC(nbNPC)));
            surf(xNPC(i)+xs*rs,yNPC(i)+ys*rs,zNPC(i)+zs*rs,'FaceColor','b','EdgeColor','none');
        end
    end

    %%% Show centroid of nucleolus as small red sphere on 3D view
    surf(xcnuc+xs*rs,ycnuc+ys*rs,zcnuc+zs*rs,'FaceColor',[0.5 0 0],'EdgeColor','none');

    %%% Show fitted nucleus
    if show_fitted_nucleus == 'y' && nuclear_envelope_is_detected
        [xs,ys,zs] = sphere;
        if exist('Rfs','var')
            xxn = xn + xs*Rfs; yyn = yn + ys*Rfs; zzn = zn + zs*Rfs;
        elseif exist('Rxfe','var')
            xxn = xn + xs*Rxfe; yyn = yn + ys*Ryfe; zzn = zn + zs*Rzfe;
        else
            [xxn, yyn, zzn] = deal(NaN,NaN,NaN);
        end
        surf(xxn,yyn,zzn,'FaceColor','none','EdgeColor','k');
    end
end

%% Show detected bNPC on 2D views of original and smoothed image
if parameters.show_figures
    for i=1:2
        if i==1, figure(fig2d_orig1), else figure(fig2d_smoothed), end;

        %%% Show detected NPC on 2D views of original image
        if show_NPC=='y'
            show_spots(gcf,xNPC,yNPC,zNPC,2,'y','NPC (putative)');
        end

        %%% Show nucleus centroid on 2D views
        show_spots(gcf,xc,yc,zc,2,'g','nucleus');

        %%% Show nucleolus centroid (if exists)
        if exist('xcnuc','var')
            show_spots(gcf,xcnuc,ycnuc,zcnuc,2,'r','nucleolus');
        end
    end
end

%% Compute signed distance(s) between the bNPC(s) and the nucleolus
%if exist('Ibwnuc','var') && nbNPC>1
%    for ib = 1:nbNPC
%        [dist_NPC_nucleolus(ib),inn(ib),jnn(ib),knn(ib)] = dist2point3d(iNPC(ib),jNPC(ib),kNPC(ib),Ibwnuc,xx,yy,zz);
%        disp(['Distance between bNPC #',num2str(ib),' and nucleolus = ',num2str(dist_NPC_nucleolus(ib)),' microns (ignoring chromatic aberrations !!)']);

%        %%% Show the bNPC's nearest neighbour  at the nucleolus surface
%        [xnn(ib),ynn(ib),znn(ib)] =
%        ijk2xyz(inn(ib),jnn(ib),knn(ib),xx,yy,zz);

%        % show On 2D view
%        if parameters.show_figures
%            show_spots(fig2d_orig1,xnn(ib),ynn(ib),znn(ib),2,'b','nuc.neighb.');
%            subplot(1,2,1); hold on; line([xNPC(ib) xnn(ib)],[yNPC(ib) ynn(ib)],'Color','y');
%            %     subplot(2,2,3); hold on;  line([xbNPC xnn],[ybNPC ynn],'Color','y');
%            subplot(1,2,2); hold on;  line([xNPC(ib) xnn(ib)],[zNPC(ib) znn(ib)],'Color','y');
%            %     subplot(2,2,4); hold on; line([xbNPC xnn],[zbNPC znn],'Color','y');
%        end
%    end
%else
%    dist_NPC_nucleolus = NaN;
%end

%% Show the fitted sphere on the 2D views  of original and smoothed image
if parameters.show_figures && show_fitted_nucleus == 'y' && nuclear_envelope_is_detected
    for i=1:2
        if i==1, figure(fig2d_orig1), else figure(fig2d_smoothed); end
        if exist('Rfs','var')
            subplot(1,2,1); plot_circle(xn,yn,Rfs,'w:');
            subplot(1,2,2); plot_circle(xn,zn,Rfs,'w:');
        else
            subplot(1,2,1); plot_ellipse(xn,yn,Rxfe,Ryfe,'w:');
            subplot(1,2,2); plot_ellipse(xn,zn,Rxfe,Rzfe,'w:');
        end
    end
end

%% Show the detected NPC on their corresponding slices
if parameters.show_figures && show_NPC_slices == 'y'
    fig_NPC  = figure('Name','NPC (putative) ','WindowStyle','normal');
    place_figure(fig_NPC,2,2,2,2);
    aux = ceil(sqrt(2*nbNPC));
    Ncols = ceil(aux/2)*2;
    Nrows = ceil(2*nbNPC/Ncols);
    for k = 1:nbNPC
        % show (xy) cuts
        subplot(Nrows,Ncols,2*k-1);
        show_slice(Icrop,xx,yy,zz,kNPC(k),'xy','NPC (putative)');
        hold on;
        plot(xNPC(k),yNPC(k),'wo');
        str = [' #',num2str(k)];
        text(xNPC(k),yNPC(k),str,'Color','w');
        hold off;
        % show (xz) cuts
        subplot(Nrows,Ncols,2*k);
        show_slice(Icrop,xx,yy,zz,jNPC(k),'xz','NPC (putative)');
        hold on;
        plot(xNPC(k),zNPC(k),'wo');
        str = [' #',num2str(k)];
        text(xNPC(k),zNPC(k),str,'Color','w');
        hold off;
    end
    hold off;
end

if exist('fig3d_seg','var')
    figure(fig3d_seg);
end

%% Store variables of interest in output data structure
store_output_nucleolus;

% Plots (TEMPORARY !)
if parameters.show_figures
    fig_radproj = show_radial_projections(out);
    if exist('fig_NPC','var'), place_figure(fig_NPC,2,2,3,2); end
    out.fig_radproj  = fig_radproj;
end




%% Store output of nucleolus.m program
    function store_output_nucleolus;

        out.parameters = parameters;

        out.xx = xx;
        out.yy = yy;
        out.zz = zz;
        out.dx = dx;
        out.dy = dy;
        out.dz = dz;
        out.xc = xc;
        out.yc = yc;
        out.zc = zc;
        out.xbNPC = xbNPC;
        out.ybNPC = ybNPC;
        out.zbNPC = zbNPC;
        out.AbNPC = AbNPC;
        if exist('xbNPC_ch2','var')
            out.xbNPC_ch2 = xbNPC_ch2;
            out.ybNPC_ch2 = ybNPC_ch2;
            out.zbNPC_ch2 = zbNPC_ch2;
            out.AbNPC_ch2 = AbNPC_ch2;
        end
        out.xspot = xspot;
        out.yspot = yspot;
        out.zspot = zspot;
        out.Aspot = Aspot;
        out.xNPC = xNPC;
        out.yNPC = yNPC;
        out.zNPC = zNPC;
        out.sNPC = sNPC;
        out.ANPC = ANPC;
        out.nbNPC = nbNPC;
        out.xn = xn;
        out.yn = yn;
        out.zn = zn;
        if exist('xnn','var')
            out.xnn = xnn;
            out.ynn = ynn;
            out.znn = znn;
        else
            out.xnn = NaN;
            out.ynn = NaN;
            out.znn = NaN;
        end
        if exist('Rfs','var')
            out.Rfs = Rfs;
        elseif exist('Rxfe','var')
            out.Rxfe = Rxfe;
            out.Ryfe = Ryfe;
            out.Rzfe = Rzfe;
        else
            out.Rxfe = NaN; out.Ryfe = NaN; out.Rzfe = NaN;
        end
        out.Vnuc_mu3 = Vnuc_mu3;
        out.Vnucleus_mu3 = Vnucleus_mu3;
        out.Inpquantiles = Inpquantiles;
        out.xcnuc = xcnuc;
        out.ycnuc = ycnuc;
        out.zcnuc = zcnuc;

        if exist('exitflag_fn','var')
            out.exitflag_fn = exitflag_fn;
        end
        if exist('meandist_fn','var')
            out.meandist_fn = meandist_fn;
        end
        out.rhobNPC = rhobNPC;
%        out.dist_bNPC_nucleolus = dist_bNPC_nucleolus;
%        out.dist_NPC_nucleus = dist_NPC_nucleus;
        out.rhobNPC = rhobNPC;
        out.thetabNPC = thetabNPC;
        out.phibNPC = phibNPC;
        out.rhoNPC = rhoNPC;
        out.thetaNPC = thetaNPC;
        out.phiNPC = phiNPC;
        out.background_green = background_green;
        out.background_red = background_red;
        if exist('Inucleolus_quantiles','var')
            out.Inucleolus_quantiles = Inucleolus_quantiles;
        end

        % Make a default class name from the current folder and the two upper folders
        [pathstr, name, ext]  = fileparts(parameters.fullmatfilename);
        [pathstr2, name2, ext] = fileparts(pathstr);
        [pathstr3, name3, ext] = fileparts(pathstr2);
        [pathstr4, name4, ext] = fileparts(pathstr3);
        out.class = fullfile(name4,name3,name2);

        % Figures
        if parameters.show_figures
            if exist('fig1d_orig1')
                out.fig1d_orig1 = fig1d_orig1;
            else
                out.fig1d_orig1 = [];
            end
            if exist('fig1d_seg')
                out.fig1d_seg = fig1d_seg;
            else
                out.fig1d_seg = [];
            end
            if exist('fig1d_smoothed')
                out.fig1d_smoothed = fig1d_smoothed;
            else
                out.fig1d_smoothed = [];
            end
            if exist('fig2d_orig1')
                out.fig2d_orig1 = fig2d_orig1;
            else
                out.fig2d_orig1 = [];
            end
            if exist('fig2d_seg')
                out.fig2d_seg = fig2d_seg;
            else
                out.fig2d_seg = [];
            end
            if exist('fig2d_segnp')
                out.fig2d_segnp = fig2d_segnp;
            else
                out.fig2d_segnp = [];
            end
            if exist('fig2d_smoothed')
                out.fig2d_smoothed = fig2d_smoothed;
            else
                out.fig2d_smoothed = [];
            end
            if exist('fig3d_orig1')
                out.fig3d_orig1 = fig3d_orig1;
            else
                out.fig3d_orig1 = [];
            end
            if exist('fig3d_seg')
                out.fig3d_seg = fig3d_seg;
            else
                out.fig3d_seg = [];
            end
            if exist('fig3d_smoothed')
                out.fig3d_smoothed = fig3d_smoothed;
            else
                out.fig3d_smoothed = [];
            end
            if exist('fig_NPC')
                out.fig_NPC = fig_NPC;
            else
                out.fig_NPC = [];
            end

        end

        %%% Supplementary output data
        if exist('nuc_voxels_to_border_dist','var')
            out_suppl.nuc_voxels_to_border_dist = nuc_voxels_to_border_dist;
        else
            out_suppl.nuc_voxels_to_border_dist = NaN;
        end

        if exist('faces_nuc','var')
            out_suppl.faces_nuc = faces_nuc;
        else
            out_suppl.faces_nuc = [];
        end

        if exist('vertices_nuc','var')
            out_suppl.vertices_nuc = vertices_nuc;
        else
            out_suppl.vertices_nuc = [];
        end

        if exist('Ibwnuc','var')
            out_suppl.nucleolus = Ibwnuc;
        else
            out_suppl.nucleolus = [];
        end
        
        if exist('Ibwnp','var')
            out_suppl.nucleus=Ibwnp;
        else
            out_suppl.nucleus=[];
        end

    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Compute spot intensity
function A = spot_intensity(I,i,j,k)
A = I(i,j,k,1);
end


%% Detect the bNPC(s)
function [ibNPC,jbNPC,kbNPC,xbNPC,ybNPC,zbNPC,AbNPC,background,s,kappa,Imean,ilocmax,jlocmax,klocmax,xlocmax,ylocmax,zlocmax] = ...
    detect_bNPCs(Ismoothed,I,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,nb_bNPCs,bNPC_localization_method,bNPC_centroid_threshold_percentage)

%%% Find local maxima
[ilocmax,jlocmax,klocmax] = local_maxima_strict(Ismoothed);

%%% Compute spottiness of all local maxima
[s,kappa,Imean,ilocmax, jlocmax, klocmax, xlocmax, ylocmax, zlocmax] = spottiness(ilocmax, jlocmax, klocmax,Ismoothed,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz);

%%% Pick the  best maxima according to the number of bNPCs
if length(ilocmax)<nb_bNPCs
    warning('There are apparently fewer local maxima than bNPCs to be detected !');
    nb_bNPCs
    ilocmax
    [xbNPC,ybNPC,zbNPC,AbNPC,s] = deal(NaN,NaN,NaN,NaN,NaN);
else
    ibNPC = ilocmax(1:nb_bNPCs);
    jbNPC = jlocmax(1:nb_bNPCs);
    kbNPC = klocmax(1:nb_bNPCs);
    xbNPC_rough = xlocmax(1:nb_bNPCs);
    ybNPC_rough = ylocmax(1:nb_bNPCs);
    zbNPC_rough = zlocmax(1:nb_bNPCs);
    AbNPC_rough = Imean(1:nb_bNPCs);
    %             scorebNPC_rough = s(1:nb_bNPCs);

    %%% Subpixelic refinement of bNPC positions
    [xbNPC, ybNPC, zbNPC, AbNPC, background] = ...
        subpixelic_spot_localization(ibNPC,jbNPC,kbNPC,xbNPC_rough,ybNPC_rough,zbNPC_rough,AbNPC_rough,I,sigma_xy,sigma_z, ...
        dx,dy,dz,xx,yy,zz,bNPC_localization_method,bNPC_centroid_threshold_percentage);
end

end

%% Detect the non-gene spots
function  [nbspot, ispot, jspot, kspot, xspot, yspot, zspot, Aspot, sspot, background] = detect_nongenespots(s,s_thresh_spots,nb_bNPCs,Imean,ilocmax,jlocmax,klocmax,xlocmax,ylocmax,zlocmax,Ismoothed,I,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,NPC_localization_method,NPC_centroid_threshold_percentage);

%%% Pick the next best maxima to define spot
Nbestspots = length(s(s>s_thresh_spots))-1;
if Nbestspots>0
    ispot = ilocmax(1:Nbestspots+1);
    jspot = jlocmax(1:Nbestspots+1);
    kspot = klocmax(1:Nbestspots+1);
    xspot_rough = xlocmax(1:Nbestspots+1);
    yspot_rough = ylocmax(1:Nbestspots+1);
    zspot_rough = zlocmax(1:Nbestspots+1);
    Aspot_rough = Imean(1:Nbestspots+1);
    sspot = s(1:Nbestspots+1);
    nbspot = length(ispot);
else
    nbspot = 0; xspot = []; yspot = []; zspot = []; Aspot = [];
end
disp(['I have found ',num2str(nbspot),' non-gene spots']);

%%% Subpixelic refinement of spot positions
[xspot, yspot, zspot, Aspot, background] = subpixelic_spot_localization(ispot,jspot,kspot,xspot_rough,yspot_rough,zspot_rough,Aspot_rough,I,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz,NPC_localization_method,NPC_centroid_threshold_percentage);

end

%% Measure background characteristics
% the input image must be 3D and have one channel only
function background = background_characteristics(I);

if ndims(I)~=3
    error(['I must have dimension 3 but ndims(I)=',num2str(ndims(I))]);
end
margin = 5;
if size(I,1)>2*margin && size(I,2)>2*margin && size(I,3)>2*margin
    Ibackground = I([1:margin end-margin],[1:margin end-margin],:);
else
    Ibackground=  [];
end

aux = Ibackground(:);
background.mean = mean(aux);
background.std = std(aux);
background.quantiles = quantile(aux,[0.025 0.25 0.5 0.75 0.975]);

end

%% Compute quantiles of intensities inside a specific nuclear subcompartment
function Iquantiles = intensity_quantiles_subcompartment(I,Ibw_sc);

aux = I(Ibw_sc); % this gives the intensities of the voxels inside the subcompartment
p = [0.025 0.25 0.5 0.75 0.975];
Iquantiles = quantile(aux,p);

end