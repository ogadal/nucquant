% for use with nucleolus.m
function  [out, out_suppl] = nucleolus_cheat(xx,yy,zz,dx,dy,dz,parameters,groundtruth);

out.parameters = parameters;

out.xx = xx;
out.yy = yy;
out.zz = zz;
out.dx = dx;
out.dy = dy;
out.dz = dz;
out.xc = groundtruth.xc;
out.yc = groundtruth.yc;
out.zc = groundtruth.zc;
out.xbNPC = groundtruth.xbNPC;
out.ybNPC = groundtruth.ybNPC;
out.zbNPC = groundtruth.zbNPC;
out.AbNPC = groundtruth.AbNPC;
out.xNPC = groundtruth.xNPC;
out.yNPC = groundtruth.yNPC;
out.zNPC = groundtruth.zNPC;
out.ANPC = groundtruth.ANPC;
out.nbNPC = groundtruth.nbNPC;
out.xcnuc = groundtruth.xcnuc;
out.ycnuc = groundtruth.ycnuc;
out.zcnuc = groundtruth.zcnuc;
out.Rxfe = groundtruth.Rx;
out.Ryfe = groundtruth.Ry;
out.Rzfe = groundtruth.Rz;

out.class = 'CHEAT';

%%
out_suppl = out;