%%% Quality control  of results computed by nucquant_robot.m

function nucquantQC

clc, close all, clear all;
disp('================================================================');
disp('nucquantQC: Nuclear localization Quality Control');
disp('================================================================');


%% Open the mat file containing the output of nucquant_robot.m
[FileName,PathName,FilterIndex] = uigetfile('classified*.mat','Please select the  result file ');
cd(PathName);
disp(['Loading ',FileName,' ...']);
load(FileName);
disp([FileName,' loaded.']);

%% Convert output structure for compatibility !!
if iscell(output)
    disp('converting structures for compatibility...');
    N = length(output);
    aux = output;
    aux_suppl = output_suppl;
    clear output output_suppl;
    for i=1:N
        output(i) =aux{i};
        output_suppl(i) =aux_suppl{i};
    end
end

if 1==0
    % Open a copy of the corresponding text file as Excel file
    [aux1,aux2,aux3] = fileparts(FileName);
    txt_file = [aux2(1:end-6),'.txt'];
    QCfilteredTextFile = ['QCfiltered_',txt_file];
    % copyfile(txt_file,QCfilteredTextFile);
end

%% Check for duplicate data !
aux = [[output.xNPC]' [output.yNPC]' [output.zNPC]'];
[idupfirst, Ndup, ialldups, m1] = find_duplicates(aux);

if ~isempty(idupfirst)
    disp(['There seem to be up to ',num2str(sum(Ndup)-length(Ndup)),' duplicates here out of ',num2str(size(aux,1)),' !!']);
    Ndupsets = length(idupfirst);
    disp(['More precisely: there are apparently ',num2str(Ndupsets),' points that are duplicated at least once']);
   % statistics on duplicates
    disp('Statistics on duplicates:');
    aux = unique(Ndup);
    for i=1:length(aux)
        aux1 = find(Ndup==aux(i));       
        disp(['There are apparently ',num2str(length(aux1)),' sets of cells with ',num2str(aux(i)),' clones each']);
    end
    %ui = input2('Do you want to list the files corresponding to apparently duplicated data ? (y/n)','n');
    ui = 'n';
    if strcmp(ui,'y')
        for idup=1:Ndupsets
            disp(['Apparent duplicate set #',num2str(idup),'/',num2str(Ndupsets)]);
            for iclone = 1:Ndup(idup)
                iaux = ialldups{idup}(iclone);
                disp(['Clone #',num2str(iclone),'/',num2str(Ndup(idup)),':',output(iaux).parameters.fullmatfilename]);
            end
            disp('---------------------------------------');
        end
    end

    %button = questdlg('Possibly duplicated data! What should I do ?','WARNING !!','Remove apparent duplicates','Ignore and proceed','Exit','Exit');
    button = 'Ignore and proceed';
    switch button
        case 'Exit'
            disp('Leaving the program !');
            return;
        case 'Remove apparent duplicates'
            disp(['I will now remove apparent duplicates !..']);
            output = output(m1);
            output_suppl = output_suppl(m1);
            disp('done');
%        otherwise
%            warndlg('I will proceed as if nothing happened, but results may be problematic..','Warning');
    end
else
    disp('No duplicates were detected');
end


N0 = length(output);

%% Show histograms of selected nuclei quantities
for i= 1:N0
    nbNPCs(i) = output(i).nbNPC;

    zNPC_minus_znucleus(i) = output(i).zNPC(1) - output(i).zc;
    ANPC(i) = output(i).ANPC(1);
    znucleus_minus_znucleolus(i) = output(i).zc - output(i).zcnuc; % try to calculate the difference of zcnucleus and zcnucleolus, 
                                                               % if they are the same, then when we align the cell, it will just rotate along z axis, 
                                                               % the z axis will not rotate, by doing this we can reduce the errors.

    if isfield(output(i),'Rxfe')
        Rxfes(i) = output(i).Rxfe;
        Ryfes(i) = output(i).Ryfe;
        Rzfes(i) = output(i).Rzfe;
    else if isfield(output(i),'Rfs')
            Rxfes(i) = output(i).Rfs;
            Ryfes(i) = Rxfes(i);
            Rzfes(i) = Rxfes(i);
        else
            warning(['There is no Rxfe nor Rfs for nucleus #',num2str(i),'!!']);
        end
    end
end

fig_autosort = figure('Name','distribution of parameters for automatic sorting');
place_figure(fig_autosort,1,1,1,1);
subplot(2,3,1), cdfplot_ch(nbNPCs,Inf), xlabel('number of NPC per nucleus');
subplot(2,3,2),
if all(isnan(Rxfes))
    title('no data here !');
else
    cdfplot_ch(Rxfes,3); %set(gca,'XScale','log');
end
xlabel('Rx of fitted ellipsoid (um)')
subplot(2,3,3),
if all(isnan(Ryfes))
    title('no data here !');
else
    cdfplot_ch(Ryfes,3);
end
xlabel('Ry of fitted ellipsoid (um)'); %set(gca,'XScale','log');
subplot(2,3,4),
if all(isnan(Rzfes))
    title('no data here !');
else
    cdfplot_ch(Rzfes,3), %set(gca,'XScale','log');
end
xlabel('Rz of fitted ellipsoid (um)');
subplot(2,3,5),
if all(isnan(zNPC_minus_znucleus))
    title('no data here !');
else
    cdfplot_ch(zNPC_minus_znucleus,3),
end
xlabel('z(NPC)-z(nucleus) (um)');
subplot(2,3,6),
if all(isnan(znucleus_minus_znucleolus))
    title('no data here !');
else
    cdfplot_ch(znucleus_minus_znucleolus,3),
end
xlabel('z(nucleus)-z(nucleolus) (um)');


%% Automated quality control according to user-defined quantitative criteria
disp(['There are ',num2str(N0),' nuclei in this data set.']);

nuclei_to_reject_1 = [];

%automatic_QC = questdlg('Automatically flag nuclei for rejection based on quantitative criteria ?','','Yes','No','Yes');
automatic_QC = 'Yes';
if strcmp(automatic_QC,'Yes')
    prompt = {'Minimum number of NPC', ...
        'Maximum number of NPC', ...
        'Minimum radius of the fitted ellipsoid in microns', ...
        'Maximum radius of the fitted ellipsoid in microns', ...
        };
    default_values = {'3', 'Inf', '0.5', '2.0'};
    answer = inputdlg(prompt,'Criteria for "good" nuclei',1,default_values);
    nbNPCmin = str2num(answer{1});%%%%%
    nbNPCmax = str2num(answer{2});
    Rxfemin = str2num(answer{3});
    Ryfemin = Rxfemin;
    Rzfemin = Rxfemin;
    Rxfemax = str2num(answer{4});
    Ryfemax = Rxfemax;
    Rzfemax = Rxfemax;

    for i=1:N0
        nbNPC = output(i).nbNPC;
        zNPC_minus_znucleus = output(i).zNPC(1) - output(i).zc;
        znucleus_minus_znucleolus = output(i).zc - output(i).zcnuc;
        if isfield(output(i),'Rxfe')
            Rxfe = output(i).Rxfe;
            Ryfe = output(i).Ryfe;
            Rzfe = output(i).Rzfe;
        else
            Rxfe = output(i).Rfs;
            Ryfe = Rxfe;
            Rzfe = Rxfe;
        end
        ANPC = output(i).ANPC(1);

        reject = (nbNPC<nbNPCmin) || (nbNPC>nbNPCmax) || (Rxfe>Rxfemax) || (Ryfe>Ryfemax) || (Rzfe>Rzfemax) || (Rxfe<Rxfemin) || (Ryfe<Ryfemin) ...
            || (Rzfe<Rzfemin);
        if reject
            nuclei_to_reject_1 = [nuclei_to_reject_1 i];
        end
    end
    disp(['Based on these criteria I will flag the following ',num2str(length(nuclei_to_reject_1)),' nuclei for rejection:']);
    disp(num2str(nuclei_to_reject_1));
    nuclei_to_keep = setdiff(1:N0,nuclei_to_reject_1);

else
    nuclei_to_keep = 1:N0;
end
saveas(gcf,'QC_distribution_parameters.fig');
close(fig_autosort);

%% Visual quality control
%answer = questdlg('Do you want to visually sort the remaining nuclei ?','','Yes','No','Yes');
answer = 'No';
nuclei_to_reject_2 = [];
if strcmp(answer,'Yes')
    %answer = questdlg('How many categories for sorting ?','','2','3','4','2');
    answer = '2';
    Nviscats = str2num(answer);
    dlg_title = 'Names of categories';
    switch Nviscats
        case 2
            def_categories = {'BADvis','GOODvis'};
        case 3
            def_categories = {'BADvis','GOODvis-1','GOODvis-2'};
        case 4
            def_categories = {'BADvis','GOODvis-1','GOODvis-2','GOODvis-3'};
    end
    clear prompt;
    for i=1:Nviscats, keycat{i} = num2str(i-1); prompt{i} = ['Key ',keycat{i}]; end
    categories = inputdlg(prompt,dlg_title,1,def_categories);
    N1 = length(nuclei_to_keep);
    aux = []; for icat=1:Nviscats, aux = [aux,' key ',keycat{icat},' for QC=',categories{icat},', ']; end
    helpdlg(['Press ',aux,' to assign categories to each nucleus; Press backspace to go back to previous nucleus; Press Q to stop']);

    i1 = 1;
    nucleus_category = nan(1,N0);
    while i1<=N1
        inuc = nuclei_to_keep(i1);
        category = nucleus_category(inuc);
        if ~isnan(category)
            disp(['Nucleus # ',num2str(inuc),' is flagged as ',categories{category}]);
        end
        parameters = output(inuc).parameters;
        fullmatfilename = parameters.fullmatfilename;
        [path mat_file_stem aux1] = fileparts(fullmatfilename);
        local_results_folder = [mat_file_stem,'_results'];
        fullresultsfoldername = fullfile(path,local_results_folder);
        if exist(fullresultsfoldername,'dir') == 0  % checks if the result folder exists (or is accessible)
            disp(['I cannot find folder ',fullresultsfoldername,'. Looking for a different location:']);
            % perhaps the file cannot be found because the input data file
            % was moved to a different location. I now try to get the right
            % location based on the current local folder
            [aux1 aux2 aux3] = fileparts(path);
            fullresultsfoldername = fullfile(pwd,aux2,local_results_folder);
            if exist(fullresultsfoldername,'dir')== 0
                error(['I cannot find folder ',fullresultsfoldername,' !!!']);
            end
        end
        fullfigname = fullfile(fullresultsfoldername,'smoothed2D.fig');
        if exist(fullfigname,'file')==0
            error(['I cannot find figure ',fullfigname,' !!!']);
        else
            open(fullfigname);
            set(gcf,'WindowStyle','normal'); aux = get(gcf,'Name'); set(gcf,'Name',[aux,' - NUCLEUS #',num2str(inuc)]);
            if exist('figure_position','var')
                set(gcf,'Position',figure_position);
            else
                place_figure(gcf,1,1,1,2);
            end
        end
        % Get user input
        validchoice = 1;
        move2nextcell = 0;
        channels_shown = [1 2 3];
        RGBorg = [];
        while ~move2nextcell
            k=0;
            while k==0
                k = waitforbuttonpress;
            end
            key = get(gcf,'CurrentCharacter');
            if isempty(key)
                validchoice = 0;
            else
                keychar = uint8(key);
                [tf,loc] = ismember(key,keycat);
                if  tf % if a category key was pressed
                    category = loc;
                    % Assigning new category
                    nucleus_category(inuc) = category;
                    disp(['Flagging nucleus #',num2str(inuc),' as ',categories{category}]);
                    move2nextcell = 1;
                else if keychar == 8 && i1>=1 % if the Backspace key was pressed and we are not at the first nucleus
                        disp('going back to the previous nucleus !!!');
                        i1 = i1-2;
                        move2nextcell = 1;
                    else if keychar == uint8('Q')
                            disp('stopping..');
                            i1 = N1;
                            move2nextcell = 1;
                        else if keychar == uint8('r')
                                [RGBorg,channels_shown] = display_color_channel(1,channels_shown,RGBorg)
                            else if keychar == uint8('g')
                                    [RGBorg,channels_shown] = display_color_channel(2,channels_shown,RGBorg);
                                else
                                    validchoice = 0;
                                end
                            end
                        end
                    end
                end
                if ~validchoice
                    warndlg(['key ',key,' is not a valid choice. Try again.']);
                end
                figure_position = get(gcf,'Position');
            end
        end
        aux = gcf; close(aux);
        i1 =i1+1;
    end
    disp('Interactive flagging finished !');
else
    Nviscats = 0;
end

%% Create a category for the automatically rejected nuclei
% if ~isempty(nuclei_to_reject_1)
if Nviscats>0
    Ncats = Nviscats + 1;
    categories{Ncats} = 'BADauto';
    nucleus_category(nuclei_to_reject_1) = Ncats;
else
    Ncats = 2;
    categories = {'OKauto','BADauto'};
    nucleus_category(nuclei_to_keep) = 1;
    nucleus_category(nuclei_to_reject_1) = 2;
end
% end

%% Count the nuclei in each category
if Nviscats>0 || strcmp(automatic_QC,'Yes')
    for icat = 1:Ncats
        aux = find(nucleus_category==icat);
        N = length(aux);
        Nnuclei_per_cat(icat) = N;
        disp(['There are ',num2str(N),' nuclei flagged with QC = ',categories{icat}]);
    end
else
    warndlg('No quality control was done! Leaving..');
    return;
end

%% Add the QC categories to the class name of each nucleus
%answer = questdlg('Add flagged categories to the class name of each nucleus ?','','Yes','No','Yes');
answer = 'No';
if strcmp(answer,'Yes');
    for inuc=1:N0
        category = nucleus_category(inuc);
        if ~isnan(category)
            aux = output(inuc).class;
            newclassname = [aux,' QC=',categories{category}];
            output(inuc).class = newclassname;
            output_suppl(inuc).class = newclassname;
        end
    end
end
disp('categories added to class names');

%% Save output both as a single matlab file or as separate matlab files according to QC category
output_all = output;
output_suppl_all = output_suppl;
for icat=1:Ncats
    % find the nuclei to which each specific category was assigned
    inucs = find(nucleus_category==icat);
    output = output_all(inucs); output_suppl = output_suppl_all(inucs);
    % save the results as a specific matlab file
    QCfilteredMatFileName = ['QC_',categories{icat},'_',num2str(Nnuclei_per_cat(icat)),'nuc_',FileName];
    save(QCfilteredMatFileName,'output','output_suppl');
    disp(['QC-flagged results written to ',QCfilteredMatFileName]);
end
% save the results with QC status as a single matlab file
QCfilteredMatFileName = ['QC_all_',num2str(N0),'nuc_',FileName];
output = output_all; output_suppl = output_suppl_all;
save(QCfilteredMatFileName,'output','output_suppl');
disp(['QC-flagged results written to ',QCfilteredMatFileName]);

disp('End of nucquantQC program');

end

%% plot both the cdf and the (smoothed) histogram
function cdfplot_ch(x,xmax)
% plot the cdf (matlab function)
cdfplot(x);
hold on;
xmax=min(xmax,max(x(:)));

% compute and plot the (normalized) kernel density estimation
[f,xi,u] = ksdensity(x); % kernels
f = f/max(f); %normalize the peak so that the cdf and the ks density fit on the same graph
plot(xi,f,'m');

% compute and plot the (normalized) histogram
nbins = 50;
[h,xout] = hist(x,nbins);
h = h/max(h); % normalize the peak
stairs(xout,h,'r-');

legend('cdf',['ksdens (u=',num2str(u),')'],'histogram');

title(['(n=',num2str(length(x)),')']);
xmin=min(x);
xlim([xmin xmax]);
ylabel('normalized frequency or cum. freq.')
end

%% Change displayed color channels of current image
function [RGBorg,channels_shown] = display_color_channel(ch,channels_shown,RGBorg)
% returns a structure im_org containing the original RGB images present in the
% figure, and an integer (channels_shown) indicating how many channels are shown after execution of
% this function (the function works as a toggle)
aux = findobj(gcf,'Type','image');
Nim = length(aux);
inputhas3colors = isempty(setdiff([1 2 3],channels_shown));
for i=1:Nim
    im = get(aux(i),'CData');
    if ~inputhas3colors
        im_new = RGBorg{i};
    else
        im_new = im;
        im_new(:,:,setdiff(1:3,ch)) = 0;
        RGBorg{i} = im;
    end
    set(aux(i),'CData',im_new);
end
if inputhas3colors
    channels_shown = ch;
else
    channels_shown = [1 2 3];
end
end