% Generate maps of NPC localization (requires the output of nucquant_align)
%
% Ch. Zimmer

function nucquant_NPCmap

clc, clear, warning on %, close all hidden;

disp('------------------------------------------------------------------');
disp('Generate 2-D maps of NPC localization');
disp('------------------------------------------------------------------');

%% Pick the input data and set processing options

% Pick the input data
[inputfilename,inputfolder] = uigetfile('*.mat','Please select the output file produced by nucloc_align' );
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
wb1 = waitbar(0,aux);
disp(aux)
load(inputfilename);
disp('done');

%% Check for duplicate data !
aux = [xNPC_all(:) yNPC_all(:) zNPC_all(:)];
[idupfirst, Ndup, ialldups, m1] = find_duplicates(aux);

if ~isempty(idupfirst)
    aux = ['There seem to be up to ',num2str(sum(Ndup)-length(Ndup)),' duplicates here out of ',num2str(size(aux,1)),'!'];
    %button = questdlg(aux,'WARNING','Proceed','List relevant files & Proceed','Exit','Proceed');
    button='Proceed';
    switch button
        case 'List relevant files'
            Ndupsets = length(idupfirst);
            disp(['More precisely: there are apparently ',num2str(Ndupsets),' points that are duplicated at least once']);
            % statistics on duplicates
            disp('Statistics on duplicates:');
            aux = unique(Ndup);
            for i=1:length(aux)
                aux1 = find(Ndup==aux(i));
                disp(['There are apparently ',num2str(length(aux1)),' sets of cells with ',num2str(aux(i)),' clones each']);
            end
            for idup=1:Ndupsets
                disp(['Apparent duplicate set #',num2str(idup),'/',num2str(Ndupsets)]);
                for iclone = 1:Ndup(idup)
                    iaux = ialldups{idup}(iclone);
                    disp(['Clone #',num2str(iclone),'/',num2str(Ndup(idup)),':',output(iaux).parameters.fullmatfilename]);
                end
                disp('---------------------------------------');
            end
        case 'Exit'
            disp('Leaving the program !');
            return;
    end
    %button = questdlg('What should I do about the duplicates ?','WARNING','Remove apparent duplicates','Ignore and proceed','Exit','Remove apparent duplicates');
    button = 'Ignore and proceed';
    switch button
        case 'Remove apparent duplicates'
            disp(['I will now remove apparent duplicates !']);
            xNPC_all = xNPC_all(m1);
            yNPC_all = yNPC_all(m1);
            zNPC_all = zNPC_all(m1);
            rhoNPC_all = rhoNPC_all(m1);
            aux = warndlg('the nucleus and nucleolus outline are still based on the original (partly duplicated) data !','Warning','modal');
            uiwait(aux);
        case 'Exit'
            disp('Leaving the program !');
            return;
        %otherwise
        %    warndlg('I will proceed as if nothing happened, but results may be problematic..','Warning');
    end
end


    info_string = [];
    if ishandle(wb1), delete(wb1); end

    %% Open up interface to set processing options
    disp('waiting for your input..');
    parameters = nucquant_NPCmap_gui([]);

    % Exit if required
    exit = parameters.exit;
    if exit, end

    %% Retrieve NPC positions
    aux = ['Computing ...'];
    wb1 = waitbar(0,aux); disp(aux);

    NNPCs = length(xNPC_all);
    disp(['N=',num2str(NNPCs),' NPCs are present here.']);

    x_all = xNPC_all-x0;
    if ~exist('rhoNPC_all','var')
        rhoNPC_all = sqrt((yNPC_all-y0).^2 + (zNPC_all-z0).^2);
    else
        rhoNPC_all = abs(rhoNPC_all);
    end
    y_all  = rhoNPC_all;

    %% Choose a subset of positions for display
    if parameters.pct_positions~=100
        aux = randperm(NNPCs);
        Npositions = round(NNPCs*parameters.pct_positions/100);
        ipositions2keep = aux(1:Npositions);
        x = x_all(ipositions2keep);
        y = y_all(ipositions2keep);
        info_string = [info_string,[num2str(parameters.pct_positions),'% random subsample; ']];
    else
        Npositions = NNPCs;
        x = x_all;
        y = y_all;
    end

    %% some text labels and other information for figures
    textlabel = [currentclass,' (N = ',num2str(Npositions),'NPCs)'];

    %% Define representative nuclear radii
    Rxs = [output(inuclei).Rxfe];
    Rys = [output(inuclei).Ryfe];
    Rzs = [output(inuclei).Rzfe];
    normalized_sphere = (all(Rxs==1) && all(Rys==1) && all(Rzs==1));
    if normalized_sphere
        Rmeans = 1;
        info_string = [info_string,' normalized to unit sphere; '];
    else
        Rmeans = (Rxs + Rys + Rzs)/3;
    end


    if strcmp(parameters.second_landmark,'SPB')
        x = -x;
        x2ndlandmark_all = 2*x0 - x2ndlandmark_all;%
    end

    %%
    x2ndlandmark_quantiles = quantile(x2ndlandmark_all - x0,[0.1 0.5 0.9]);
    x2ndlandmarkL = x2ndlandmark_quantiles(1);
    x2ndlandmarkM = x2ndlandmark_quantiles(2);
    x2ndlandmarkR = x2ndlandmark_quantiles(3);


    %% Correct for cylindrical projection effect
    % (if a uniformly spaced grid is used)
    % this is required to make sure a uniform gene distribution will generate
    % a uniform NPC map

    if ~parameters.volume_preserving_grid
        info_string = [info_string,'regularly spaced grid (volumes not constant!); '];
    end

    if ~parameters.cumulative_probabilities
        if parameters.probdens_not_counts
            info_string = [info_string,'values = proba. dens. (mu-3); '];
        else
            info_string = [info_string,'values = counts; '];
        end
    else
        info_string = [info_string,'values = % of NPCs; '];
    end

%% Interface to R for Windows - added Mar 2009 Tarn Duong
    if ispc
        %% Show KDE isocontours 
        %% contour levels (percentages)
        cont = parameters.cum_prob_percentiles;

        %% Input variables for NPC maps
        uv2 = [x; y.^2]';  %uv2=[xgene_all - x0; rhogene_all.^2]';
        uvmin = -1.1*max(abs(uv2)); 
        uvmax = 1.1*max(abs(uv2)); 
        
        %% Transfer data to R
        saveR('cont.R','cont')
        saveR('uvmin.R','uvmin');
        saveR('uvmax.R','uvmax');
        saveR('uv2.R','uv2');
        
        %% Compute KDE NPC map in R
        CurrentDirectory=strrep(pwd,'\','/');
        eval(['!D:/users/Renjie/R-2.9.2/bin/Rscript ' CurrentDirectory '/Commands2.R']) % Here the path is very important!C:\Program Files (x86)\R\R-2.9.2\bin
        
        %% Transfer data to matlab
        S2=dlmread('a12.txt');
        S3=dlmread('a13.txt');
        S4=dlmread('a14.txt');
        S5=dlmread('a15.txt');S6=S5';%
        S8=S6(1:(numel(S6)-1));% To extract the non-zero elements in S5

        % Get the contour of NPC map
        [B11,B22,B33,C2]=mat_aling2(S2,S3,S4);
        fig=figure('Name','Map of subnuclear NPC positions');
        hold on;
        rectangle('Position',[parameters.xmin, -abs(parameters.ymax), abs(parameters.xmax - parameters.xmin), 2*abs(parameters.ymax)], 'FaceColor','black');
        [C h]=contourf(B22,B33,C2,S8);%
        %%change the color in each contour
       
        %%
        if parameters.isocontour_labels
        clabel(C,h,'Color','w','Rotation',0,'Fontsize',8);
        end
        
        title(['NPC density isocontours ', '',' (',num2str(parameters.dx),' x ',num2str(parameters.dymax),' mu bins)']);
        axis equal;
        set(gca,'FontSize',16);
        set(gca,'FontName','Arial');

        if parameters.cumulative_probabilities
        colorbar('ytick',S8, 'YTickLabels', parameters.cum_prob_percentiles); % Be careful the dimension of S5
        else
        colorbar('YTickLabels', S8);
        end

        axis equal; axis tight;
        xlabel(texlabel('R cos(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');
        ylabel(texlabel('R sin(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');

        xlim([parameters.xmin parameters.xmax]);
        ylim([-abs(parameters.ymax) parameters.ymax]);
        
        %% delete all
        delete('a12.txt')
        delete('a13.txt')
        delete('a14.txt')
        %delete('a15.txt') % Here give us the density
        delete('cont.R')
        delete('uvmin.R')
        delete('uvmax.R')
        delete('uv2.R')
    end
    %% End of R interface
    
    
%% No R interface for non-Windows OS 
    if ~ispc
        %% Create fuzzy positions image
        [Ipd, xmin, xmax, ymin, ymax, xx1, yy1] = probdens_image(x,y,parameters);


        %% Compute fuzzy histogram
        [H1,Xbinedges,Ybinedges] = fuzzy_histogram_2D(Ipd,xx1,yy1,parameters.dx,parameters.dymax,parameters.volume_preserving_grid);
        if parameters.symmetrize_topandbottom
            H1 = [H1(end:-1:1,:); H1];
            ymin = -ymax;
            Ybinedges = [-Ybinedges(end:-1:2); Ybinedges];
        end

        %% Compute volume of a grid cell
        if parameters.volume_preserving_grid
            Vbin_mu3 = pi * ( Ybinedges(end)^2 -Ybinedges(end-1)^2) * (Xbinedges(end)-Xbinedges(end-1));
            disp(['each grid cell (histogram bin) corresponds to a volume dV=',num2str(Vbin_mu3),' mu^3']);
        end

        %% Compute the probability density map
        if parameters.probdens_not_counts
            H1 = H1/(sum(H1(:))*Vbin_mu3);
            if parameters.symmetrize_topandbottom
                H1 = H1*2;
            end
        end

        %% Compute cumulative probability histogram
        if parameters.cumulative_probabilities
            H1 = 100* hist2cumhist(H1);
        end


        %% Show fuzzy histogram
        if strcmp(parameters.figure_type,'histogram')
            fig = figure('Name','fuzzy histogram');

            if parameters.volume_preserving_grid
                H1 = stretch(H1,xmin,xmax,ymin,ymax,Xbinedges,Ybinedges,parameters);
            end

            show_histogram(H1,Xbinedges,Ybinedges,parameters,'Fuzzy histogram')
        end


        %% Define significantly distinct levels for contour plots
        if parameters.cumulative_probabilities
            levels = unique([0 parameters.cum_prob_percentiles 100]);
        else
            if parameters.significantly_distinct_levels
                levels = well_separated_count_levels(parameters.significantly_distinct_levels_p,1,min(Npositions,1000));
                if parameters.probdens_not_counts
                    levels = levels/(Npositions*Vbin_mu3);
                end
                disp(['contour levels are chosen as follows: ',num2str(levels)]);
            else
                levels = [];
                info_string = [info_string,' levels chosen by matlab; '];
            end
        end

        %% Show fuzzy isocontours
        if strcmp(parameters.figure_type,'isocontours')
            fig = figure('Name','Map of subnuclear NPC position');
            show_contours(H1,Xbinedges,Ybinedges,parameters,'',levels);
        end

        % background for case where no image is shown
        if strcmp(parameters.figure_type,'positions') && ~parameters.position_blur
            fig = figure('Name','Positions');
            imagesc([parameters.xmin parameters.xmax],[-parameters.ymax parameters.ymax],zeros(1,1)); colormap(gray); axis equal; hold on;
            xlim([parameters.xmin parameters.xmax]);
            ylim([-parameters.ymax parameters.ymax]);
        end
        
        % Colormap
        cm = colormap(parameters.colormap);
        cm(1,:) = [0 0 0]; % background in black !
        colormap(cm);

    end

%% Resume Matlab for both Windows and non-Windows

    
    % place figure
    if exist('fig','var')
        place_figure(fig,1,1,1,1);
    end

    %% display nuclear envelope and nucleolus centroid positions
    plot_info(normalized_sphere,Rmeans,x2ndlandmarkL,x2ndlandmarkM,x2ndlandmarkR,textlabel,parameters);

    % display grid
    if parameters.overlay_grid
        show_grid(Xbinedges,Ybinedges,xmin,xmax,ymin,ymax,'w','-.')
    end

    % Show locations of nucleoli
    if parameters.show_nucleoli && exist('Inucall','var');
        show_nucleoli_locations(Inucall,xx2,yy2,parameters)
    end

    %plot positions on map
    if parameters.show_positions_on_map
        plot(x,y,'o','MarkerSize',4,'MarkerEdgeColor','k','MarkerFaceColor','w')
    end

    % text information
    title(info_string);

    %% Plot the individual NPC positions
    if parameters.show_NPC_positions
        fig_cylproj = figure('Name','Positions (cylindrical projection)');
        plot(x,y,'ko','MarkerFaceColor','g'); axis equal; axis tight;
        hold on;
        ylim([0 ymax]);
        xlim([xmin xmax]);
        xlabel('R*cos(alpha)');
        ylabel('R*sin(alpha)');
        title(['NPC positions after cylindrical projection']);
        % also show the nucleolar centers
        plot(dxp,dyp,'ko','MarkerFaceColor','r');
        % display grid
        if parameters.overlay_grid
            show_grid(Xbinedges,Ybinedges,xmin,xmax,ymin,ymax,'k','-')
        end
        plot_arccircle(0,0,R0,0,pi,'k-');
    end

    %% Compute and plot volumic confinement graph (volume against percentage of
    %% points)
    if parameters.volumic_confinement_plot
        if exist('H1','var')
            [V,pct_points] = volumic_confinement_stats(Npositions,H1,Xbinedges,Ybinedges,Rmeans,parameters.cum_prob_percentiles/100);
        else
            warning('To compute volumic confinement data, you need to choose "Isocontours" or "Histogram" !');
        end
    end


disp('End of nucquant_NPCmap');


end


%% Non-linear stretching of histogram image along the y-axis
function Imap2 = stretch(Imap,xmin,xmax,ymin,ymax,Xbinedges,Ybinedges,parameters)
% compute scaling factor
dy1 = (ymax-ymin)/(length(Ybinedges)-1);
param = parameters.dymax/sqrt(dy1);

% Define the transformation that will align the histogram image with the
% unequal bin histogram grid (the transformation is the non-linear stretching:
% (x,y) -> (x,param*sign(y)*sqrt(y))
T1 = maketform('custom',2,2,@F,@Finv,param);


% Stretch the probability densitiy map image (the greatly increased vertical size of the image is necessary to get
% good alignement with the non-uniform grid !)
disp('stretching probability density map...');
uData = [xmin xmax];
vData = [ymin ymax];
xData = uData;
yData = vData;
%         Imap2 = imtransform(Imap,T1,'nearest','UData',uData,'VData',vData,'XData',xData,'YData',yData,'FillValues',Inf,'size',[size(H1,1)*parameters.gridfactor size(H1,2)]);
Imap2 = imtransform(Imap,T1,'nearest','UData',uData,'VData',vData,'XData',xData,'YData',yData,'FillValues',Inf,'size',[(length(Ybinedges)-1)*parameters.gridfactor length(Xbinedges)-1]);
end

%% Correct histogram image for the cylindrical projection artefact
% this consists in dividing the counts in each bin by a number proportional
% to the volume that is projected in each bin
function [H_corrected, volume_ratio, volume_correction] = correct_for_cylindrical_projection(H,Ybinedges)
volume_ratio = NaN(size(H));
for j=1:length(Ybinedges)-1
    y1 = Ybinedges (j);
    y2 = Ybinedges (j+1);
    if y1*y2>=0
        volume_ratio(j,:) = abs(y1*y1-y2*y2)*ones(1,size(H,2));
    else
        volume_ratio(j,:) = 0.5*(y1*y1+y2*y2)*ones(1,size(H,2));
    end
end
volume_ratio = volume_ratio/min(volume_ratio(:));
volume_correction = 1./volume_ratio;
H_corrected = H.*volume_correction;

end


%% Create image of probability density by summation of gaussian spots
function [Ipd, xmin, xmax, ymin, ymax, xx1, yy1] = probdens_image(x,y,parameters)

% size of the (very small, e.g. 1x1 nm) pixels of the fuzzy probability density map
dx = parameters.prob_dens_pixel_size; dy = dx; %

% axes limits
xmin = parameters.xmin; xmax = parameters.xmax; ymax = parameters.ymax;
% axes
xx1 = floor(xmin/dx)*dx:dx:ceil(xmax/dx)*dx;
xxcenters = xx1(1)+dx/2:dx:xx1(end)-dx/2;
yypos = 0:dy:ceil(ymax/dy)*dy;
yy1 = yypos;
ymin = 0;
yycenters = yy1(1)+dy/2:dy:yy1(end)-dy/2;
Nx = length(xxcenters);
Ny = length(yycenters);

% create image of gaussian spot
[Ispot, Nxspot] = gaussian_spot(parameters.point_spot_sigma,parameters.prob_dens_pixel_size);

Ipd1 = zeros(Ny,Nx);

iii = find(~isnan(x));
iii = iii(:)';
for i=iii
    % find the pixel closest to the current point
    [aux,i1] = min((yycenters-y(i)).^2);
    [aux,j1] = min((xxcenters-x(i)).^2);
    iL = i1-(Nxspot-1)/2;
    jL = j1-(Nxspot-1)/2;
    iR = i1 + (Nxspot-1)/2;
    jR = j1 + (Nxspot-1)/2;
    iL2 = max([iL 1]);
    jL2 = max([jL 1]);
    iR2 = min([iR Ny]);
    jR2 = min([jR Nx]);
    corrfact = 1;
    % add the gaussian spot to the image
    Ipd1(iL2:iR2, jL2:jR2) = Ipd1(iL2:iR2, jL2:jR2)  + Ispot(1+iL2-iL:end-(iR-iR2), 1+jL2-jL:end-(jR-jR2))*corrfact ;
end


% Symmetrize the map about the x-axis
Ipd = Ipd1;


end


%% Plot circle representing nucleus, bar representing nucleolus center,
% plus some text information
function plot_info(normalized_sphere,Rmeans,x2ndlandmarkL,x2ndlandmarkM,x2ndlandmarkR,textlabel,parameters)
hold on;

% Draw circle
if normalized_sphere
    plot_arccircle(0,0,mean(Rmeans),0,2*pi,'y--');
    if parameters.isocontour_labels
        text(mean(Rmeans),0,[' R_0=',num2str(mean(Rmeans)),'mu'],'Color','y');
    end
else
    quantiles = parameters.nucleoli_quantiles/100;
    Rs = quantile(Rmeans,quantiles);
    for i=1:length(Rs)
        R0 = Rs(i);
        plot_arccircle(0,0,R0,0,2*pi,'y--');
        if parameters.isocontour_labels
            text(0,R0,[' R_0=',num2str(R0),'mu (',num2str(quantiles(i)*100),'%)'],'Color','w');
        end
    end
end

% Add bar to show nucleolus extent
line([x2ndlandmarkL x2ndlandmarkR],[0 0],'Color','r','LineStyle','-','LineWidth',2);
plot(x2ndlandmarkM,0,'ro','MarkerSize',12,'LineWidth',2);

% Add text information
aux = xlim; xmin = aux(1); xmax = aux(2); aux = ylim; ymin = aux(1); ymax = aux(2);
text(xmin+0.05*(xmax-xmin),ymin+0.01*(ymax-ymin),textlabel,'Color','w','VerticalAlignment','bottom','Fontsize',18);

end

%% Show histogram
function show_histogram(H,Xbinedges,Ybinedges,parameters,titlestring)
xleft = (Xbinedges(1)+Xbinedges(2))/2;
xright = (Xbinedges(end)+Xbinedges(end-1))/2;
yleft = (Ybinedges(1)+Ybinedges(2))/2;
yright = (Ybinedges(end)+Ybinedges(end-1))/2;

imagesc([xleft xright],[yleft yright], H);
set(gca,'FontSize',16);
set(gca,'FontName','Arial');
colorbar;
axis equal; axis tight;
xlabel(texlabel('R cos(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');
ylabel(texlabel('R sin(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');
set(gca,'YDir','normal');
title(['NPC density histogram (',num2str(parameters.dx),' x ',num2str(parameters.dymax),' mu bins), ',titlestring]);
%             plot_info(normalized_sphere,Rmeans,x2ndlandmarkL,x2ndlandmarkM,x2ndlandmarkR,textlabel,parameters);
hold on;
end

%% Show isocontours
function show_contours(H,Xbinedges,Ybinedges,parameters,titlestring,levels)
hold on;

Xbincenters = (Xbinedges(1:end-1)+Xbinedges(2:end))/2;
Ybincenters = (Ybinedges(1:end-1)+Ybinedges(2:end))/2;

if ~isempty(levels)
    if parameters.filled_isocontours
        [C,h,CF] = contourf(Xbincenters,Ybincenters,H,levels);
    else
        [C,h] = contour(Xbincenters,Ybincenters,H,levels);
    end
else
    if parameters.filled_isocontours
        [C,h,CF] = contourf(Xbincenters,Ybincenters,H);
    else
        [C,h] = contour(Xbincenters,Ybincenters,H);
    end
end
if parameters.isocontour_labels
    clabel(C,h,'Color','w','Rotation',0,'Fontsize',8);
end

title(['NPC density isocontours ',titlestring,' (',num2str(parameters.dx),' x ',num2str(parameters.dymax),' mu bins)']);
axis equal;
set(gca,'FontSize',16);
set(gca,'FontName','Arial');
colorbar;
axis equal; axis tight;
xlabel(texlabel('R cos(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');
ylabel(texlabel('R sin(alpha) (mu m)'),'FontSize',16,'Interpreter','tex');

xlim([Xbincenters(1) Xbincenters(end)]);
ylim([Ybincenters(1) Ybincenters(end)]);

end

%% Display grid
function show_grid(Xbinedges,Ybinedges,xmin,xmax,ymin,ymax,color,style)

for i=1:length(Xbinedges)
    line([Xbinedges(i) Xbinedges(i)],[ymin ymax],'Color',color,'LineStyle',style);
end
for j=1:length(Ybinedges)
    line([xmin xmax],[Ybinedges(j) Ybinedges(j)],'Color',color,'LineStyle',style);
end

end

%% Show nucleolar outline(s)
function show_nucleoli_locations(Inucall,xx2,yy2,parameters)
hold on;
% Show contours indicating the location of the nucleoli based
% on the sum of aligned nucleoli segmentations
aux = max(Inucall,[],3); Inucleoli= squeeze(aux)';
aux = max(Inucleoli(:));
if aux==0
    warndlg('Information on nucleoli is missing: I cannot draw nucleolar outlines !');
else
    Inucleoli = Inucleoli/aux;
    % set the levels
    levels = parameters.nucleoli_quantiles/100;
    % freeze color axis
    caxis manual;
    % draw the contours
    [C,h] = contour(xx2,yy2,Inucleoli,levels,'r:','LineWidth',2);
    if parameters.isocontour_labels
        clabel(C,h,'Color','r','Rotation',0)
    end
end

end

%%
function U = F(X,t)
epsilon = 0;

param = t.tdata;

U(:,1) = X(:,1);
y = X(:,2);
U(:,2) = sqrt(y + epsilon).*sign(y)*param;

end

%%
function X = Finv(U,t)
epsilon = 0;

param = t.tdata;

X(:,1)  = U(:,1);
v = U(:,2);
X(:,2) = sign(v).*(v.*v - epsilon)/(param*param);

end

%% Compute levels for 2D cumulative probability  histogram
function Hlevels = cum_prob_levels(H,percentiles)

aux = H(:);
H1 = aux(aux>0);
[H1s, is] = sort(H1,'descend');
H1cdf = cumsum(H1s)/sum(H1s(:));


% For each quantile, find the corresponding level of the original histogram
% by interpolating the inverse cdf
Hlevels = interp1(H1cdf,H1s,percentiles/100,'linear');

Hlevels = sort(Hlevels);

end

%% Convert histogram into cumulative distribution function
function Hcum = hist2cumhist(H)

Hcum = zeros(size(H));

[H1s, is] = sort(H(:));
H1cdf = cumsum(H1s)/sum(H1s(:));

Hcum(is) = H1cdf;

end

%% Compute volume vs. fraction of points
function [V,pct_points] = volumic_confinement_stats(Npoints,H,Xbinedges,Ybinedges,Rmeans,quantiles)

% first scale the histogram to the number of points
aux = sum(H(:));
if Npoints~=aux
    %     disp('temporarily rescaling histogram so that its sum equals the number of points..');
    H = Npoints/aux*H;
end
H1 = H(:);
[H1s, is] = sort(H1,'descend');

H1scum = cumsum(H1s);
Nbins = length(H1s);
Vtot = pi*Ybinedges(end)^2*(Xbinedges(end)-Xbinedges(1)); % total volume
volumes = (Vtot/Nbins)*ones(size(H1s));

V1s = volumes(is);

V = cumsum(V1s);
R0 = median(Rmeans);
V0 = 4/3*pi*R0^3;
V_rel = V/V0;
pct_points = H1scum / Npoints * 100;
pct_nom = quantiles*100;

for i=1:length(pct_nom)
    pct = pct_nom(i);
    [aux,i2] = min(abs(pct_points-pct));
    disp([' approx. ',num2str(pct),'% of points (',num2str(pct_points(i2)),'%) fall in a volume of ',num2str(V(i2)),' mu^3, or  ',num2str(V_rel(i2)*100),'% of the nuclear sphere of median radius ',num2str(R0),' mu']);
end
disp('Warning 1: these values depend on various parameters, including assumed localization error and histogram grid !');
disp('Warning 2: these values are computed by assuming a volume-preserving grid and no correction for volumic projections when blurring positions!')
disp('For other settings, the computed values may be wrong.');

% show figure
fig_volconf = figure('Name','Quantification of confinement');
subplot(2,1,1);
plot(pct_points,V,'.-');
hold on;
title('Smallest volume containing the NPC in x% of cells');
xlabel('% of cells');
ylabel('Volume (mu^3)');
plot(pct_points,ones(size(pct_points))*4/3*pi*1^3,'g-');
text(50,4/3*pi*1^3,'sphere of radius 1 mu','VerticalAlignment','bottom','Color','g');
plot(pct_points,ones(size(pct_points))*4/3*pi*R0^3,'r-');
text(50,4/3*pi*R0^3,['sphere of radius ',num2str(R0),' mu'],'VerticalAlignment','bottom','Color','r');
set(gca,'YLim',[0 min(max(V),8/3*pi)]);
set(gca,'XLim',[0 100]);
grid on;

subplot(2,1,2);
cdfplot(H(:));
plot(pct_points,V_rel,'.-');
xlabel('% of cells');
ylabel('Volume (fraction of median radius sphere)');
set(gca,'XLim',[0 100]);
grid on;

end
