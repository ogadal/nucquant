function varargout = nucquant_advanced_settings(varargin)
% NUCQUANT_ADVANCED_SETTINGS M-file for nucquant_advanced_settings.fig
%      NUCQUANT_ADVANCED_SETTINGS, by itself, creates a new NUCQUANT_ADVANCED_SETTINGS or raises the existing
%      singleton*.
%
%      H = NUCQUANT_ADVANCED_SETTINGS returns the handle to a new NUCQUANT_ADVANCED_SETTINGS or the handle to
%      the existing singleton*.
%
%      NUCQUANT_ADVANCED_SETTINGS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUCQUANT_ADVANCED_SETTINGS.M with the given input arguments.
%
%      NUCQUANT_ADVANCED_SETTINGS('Property','Value',...) creates a new NUCQUANT_ADVANCED_SETTINGS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before nucquant_advanced_settings_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to nucquant_advanced_settings_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help nucquant_advanced_settings

% Last Modified by GUIDE v2.5 21-Oct-2006 15:16:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @nucquant_advanced_settings_OpeningFcn, ...
    'gui_OutputFcn',  @nucquant_advanced_settings_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT



% --- Executes just before nucquant_advanced_settings is made visible.
function nucquant_advanced_settings_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nucquant_advanced_settings (see VARARGIN)

% Propagate the parameters used when calling nucquant_gui ; the new settings
% will be added to this parameter structure
if length(varargin)>0
    handles.output = varargin{1};
    parameters = handles.output;
else
    error('nucquant_advanced_settings should be called with parameters as input !');
end

% Set NPC localization method
if isfield(parameters,'bNPC_localization_method')
    if strcmp(parameters.bNPC_localization_method,'intensity-weighted')
        set(handles.radiobutton4,'Value',1)
    end
end

% Set threshold for bNPC localization by intensity-weighted centroid
if isfield(parameters,'bNPC_centroid_threshold_percentage')
    set(handles.edit1,'String',num2str(parameters.bNPC_centroid_threshold_percentage));
end

% Set minimum score of NPC (percentage of bNPC score)
if isfield(parameters,'NPC_min_score_percentage')
    set(handles.edit3,'String',num2str(parameters.NPC_min_score_percentage));
end

% Set removal of non-peripheral spots
if isfield(parameters,'NPC_are_peripheral')
    set(handles.checkbox1,'Value',parameters.NPC_are_peripheral);
end

% Set NPC localization method
if isfield(parameters,'NPC_localization_method')
    if strcmp(parameters.NPC_localization_method,'intensity-weighted')
        set(handles.radiobutton7,'Value',1)
    end
end

% Set cheat modus
if isfield(parameters,'cheat') && parameters.cheat
    set(handles.checkbox2,'Value',get(handles.checkbox2,'Max'));
end

% Update handles structure
guidata(hObject, handles);

uiwait;

% --- Outputs from this function are returned to the command line.
function varargout = nucquant_advanced_settings_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

close(handles.figure1);

%% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

parameters = handles.output; % this retrieves the parameters set before using the GUI

% Retrieve the parameters from the GUI:

%%% bNPC localization method
if get(handles.radiobutton4,'Value')
    parameters.bNPC_localization_method = 'intensity-weighted';
end

% Get threshold for bNPC localization by intensity-weighted averaging
aux = str2num(get(handles.edit1,'String'));
if ~isempty(aux) && aux>=0 && aux<=100
    parameters.bNPC_centroid_threshold_percentage = aux;
else
    error('incorrect value of threshold for intensity-weighted bNPC localization !');
end

%%% NPC Localization method
% Get NPC localization method
if get(handles.radiobutton7,'Value')
    parameters.NPC_localization_method = 'intensity-weighted';
end

% Get minimum score of NPC (percentage of bNPC score)
aux = str2num(get(handles.edit3,'String'));
if ~isempty(aux) && aux>=0 && aux<=100
    parameters.NPC_min_score_percentage = aux;
else
    error('incorrect value of threshold for NPC score !');
end

% Get threshold for NPC localization by intensity-weighted averaging
aux = str2num(get(handles.edit2,'String'));
if ~isempty(aux) && aux>=0 && aux<=100
    parameters.NPC_centroid_threshold_percentage = aux;
else
    error('incorrect value of threshold for intensity-weighted NPC localization !');
end

% Get whether NPC are peripheral
parameters.NPC_are_peripheral = get(handles.checkbox1,'Value') == get(handles.checkbox1,'Max');

% Get cheat modus
parameters.cheat = get(handles.checkbox2,'Value') == get(handles.checkbox2,'Max');

handles.output = parameters;

guidata(hObject,handles);

uiresume;

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1




% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
