% Script for use with nucleolus.m or related programs
% This program takes as input the localization data of NPCs, nucleolus and nucleus
% computed by nucleolus.m for different cells, and aligns them in order to
% produce figures that synthesize NPC localizations from all cells in a spatially
% meaningful fashion
% More precisely, each nucleus and its components (NPCs, nucleolus) is subjected to the following series of geometric
% transformations :
% - translations to make the centers of all nuclei coincide
% - rotations to put the centroid of all nucleoli on the same axis (the positive x-axis)
% - independent scaling of the 3 axes to transform the nuclear ellipsoid
% into a sphere of radius 1
% -
% Optionnally, .....

% TODO: THIS PROGRAM BADELY NEEDS TO BE MODULARIZED AND CLARIFIED !!!

function nucquant_align

close all, clear all; clc;
global swapRG;
swapRG = 'y';


disp('------------------------------------------------------------------');
disp('Align nuclear landmarks to build coherent pictures of NPC localization');
disp('------------------------------------------------------------------');


%% Pick the input data
[inputfilename,inputfolder,filterindex] = uigetfile('*.mat','Please select the file containing the extracted localization data');
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
disp(aux);
wb = waitbar(0,aux);
load(inputfilename);
if ishandle(wb), delete(wb); end
parameters.inputfilename = inputfilename;
parameters.inputfolder = inputfolder;

clear *_all;

%% Convert output structure for compatibility !!
if iscell(output)
    wb = waitbar(0,'converting structures for compatibility...');
    N = length(output);
    aux = output;
    aux_suppl = output_suppl;
    clear output output_suppl;
    i=1;
    while i<=N & ~isempty(aux{i})
        output(i) = aux{i};
        output_suppl(i) = aux_suppl{i};
        i = i +1;
    end
    if ishandle(wb), delete(wb); end
end


%% Import the names of the different classes and restrict to specific class
[aux,N] = nonemptystructurearrayelement(output);
for i=1:N,
    nucleus_class{i} = output(i).class;
end
nuclei_classes = unique(nucleus_class);
Nclasses = length(nuclei_classes);
disp(['There are  ',num2str(Nclasses),' available classes:']);
for i=1:Nclasses,
    inuclei = find(ismember(nucleus_class,nuclei_classes{i}));
    Nnuclei_per_class(i) = length(inuclei);
    disp(['Class #',num2str(i),' (',num2str(Nnuclei_per_class(i)),') : ',nuclei_classes{i}]);
end

%% Define nuclei of interest
if Nclasses>1
    iclass = str2num(input2('Please select the class of interest','1'));
else
    iclass = 1;
end
currentclass = nuclei_classes{iclass};
inuclei = find(ismember(nucleus_class,currentclass));
Nnuclei = length(inuclei);
disp(['Ok. I will align the following ',num2str(Nnuclei),' nuclei: ',num2str(inuclei)]);

%% Pop up interface for user settings
parameters = nucquant_align_gui(parameters);

Zshift_red_green_mu = parameters.shift_Z_red_green*parameters.Zshift_red_green_mu;

wb = waitbar(0,'Initializing..');
% If needed, construct a big 3D image that can contain translated and
% rotated images of all nucleoli
if ~parameters.use_isosurf
    % get the x-, y- and z-range of the union of all images
    xmin=+Inf; xmax=-Inf; for i=inuclei, aux = output(i).xx; xmin = min(xmin,min(aux)); xmax = max(xmax,max(aux)); end
    dx = aux(2)-aux(1);
    ymin=+Inf; ymax=-Inf; for i=inuclei, aux = output(i).yy; ymin = min(ymin,min(aux)); ymax = max(ymax,max(aux)); end
    dy = aux(2)-aux(1);
    zmin=+Inf; zmax=-Inf; for i=inuclei, aux = output(i).zz; zmin = min(zmin,min(aux)); zmax = max(zmax,max(aux)); end
    dz = aux(2)-aux(1);
    % create axes for the aligned images
    xx1 = xmin:dx:xmax; x0 = (xx1(end)+xx1(1))/2;
    yy1 = ymin:dy:ymax; y0 = (yy1(end)+yy1(1))/2;
    zz1 = zmin:dz:zmax; z0 = (zz1(end)+zz1(1))/2;
    xx2 = xx1 - x0;
    yy2 = yy1 - y0;
    zz2 = zz1 - z0;
    Inucall = zeros(length(xx2),length(yy2),length(zz2));
    TSIZEout = size(Inucall);
end

%% Median nuclear radius
aux1 = [output(:).Rxfe];
aux2 = [output(:).Ryfe];
aux3 = [output(:).Rzfe];
aux = [aux1(:) aux2(:) aux3(:)];
aux = mean(aux,2);
R0 = median(aux);


inucproc=0;

%% Main loop
for inuc = inuclei
    inucproc=inucproc+1;
    if mod(inuc,10)==0
        waitbar(inucproc/Nnuclei,wb,['aligning nucleus #',num2str(inuc),' out of ',num2str(Nnuclei),'...']);
    end
    xx = output(inuc).xx;
    yy = output(inuc).yy;
    zz = output(inuc).zz;
    xcnucleus = output(inuc).xc;
    ycnucleus = output(inuc).yc;
    zcnucleus = output(inuc).zc;
    if strcmp(parameters.second_landmark,'nucleolus')
        x2ndlandmark = output(inuc).xcnuc;
        y2ndlandmark = output(inuc).ycnuc;
        z2ndlandmark = output(inuc).zcnuc - Zshift_red_green_mu; % apply Z-shift if necessary
    else
        auxx = output(inuc).xbNPC_ch2;
        auxy = output(inuc).ybNPC_ch2;
        auxz = output(inuc).zbNPC_ch2;
        auxA = output(inuc).AbNPC_ch2;
    end

    if isfield(output(inuc),'Rxfe') % nuclear envelope is modeled as axes-aligned ellipsoid
        Rx = output(inuc).Rxfe;
        Ry = output(inuc).Ryfe;
        Rz = output(inuc).Rzfe;
        %         disp(['DEBUG: ellipsoid Rx=',num2str(Rx),', Ry=',num2str(Ry),', Rz=',num2str(Rz),' !!!']);
    else % nuclear envelope is modeled as sphere
        Rx = output(inuc).Rfs;
        Ry = Rx;
        Rz = Rx;
        %         disp(['DEBUG: sphere Rx=',num2str(Rx),', Ry=',num2str(Ry),', Rz=',num2str(Rz),' !!!']);
    end
    aux = output(inuc).xNPC;
    xNPC = aux;
    aux = output(inuc).yNPC;     yNPC = aux;
    aux = output(inuc).zNPC;     zNPC = aux;

    if isnan(x2ndlandmark)
        disp('Warning: this cell apparently does not have a second nuclear landmark ! I therefore skip it.');
        inuclei = setdiff(inuclei,inuc);
        Nnuclei = Nnuclei - 1;
    else

        if parameters.use_isosurf % Use the nucleolar isosurfaces to compute a composite image
            align_isosurfaces;
        else % Use the binary nucleoli images to compute a composite image

            if parameters.align_nucleolus_surface
                Ibwnuc = output_suppl(inuc).nucleolus;
            end

            % Compute the alignement transformation
            [Tvox,Tphys] = align_nucleoli_tform(x0,y0,z0,R0,xcnucleus,ycnucleus,zcnucleus,x2ndlandmark,y2ndlandmark,z2ndlandmark,Rx,Ry,Rz,dx,dy,dz,min(xx),min(yy),min(zz),parameters);
            % bounds
            %         outbounds = findbounds(T,
            RS = makeresampler('cubic','bound'); % resampling structure

            % Transform the binary nucleoli image
            if parameters.align_nucleolus_surface
                Ibwnuc_aligned = tformarray(Ibwnuc, Tvox, RS, [1 2 3], [1 2 3], TSIZEout, [], []);
            end

            % Transform coordinates of various points
            [xcnucleus_aligned, ycnucleus_aligned, zcnucleus_aligned] = tformfwd(Tphys,[xcnucleus ycnucleus zcnucleus]);
            [x2ndlandmark_aligned, y2ndlandmark_aligned, z2ndlandmark_aligned] = tformfwd(Tphys,[x2ndlandmark y2ndlandmark z2ndlandmark]);
            [xNPC_aligned, yNPC_aligned, zNPC_aligned] = tformfwd(Tphys,xNPC,yNPC,zNPC);


            % Add the aligned nucleolus segmentation image to composite image
            % of aligned segmented nucleoli
                if exist('Ibwnuc_aligned','var');
                    Inucall = Inucall + Ibwnuc_aligned;
                end

            % Collect NPC and nucleoli center locations
            if ~exist('xNPC_all','var')
                xNPC_all = xNPC_aligned; yNPC_all = yNPC_aligned; zNPC_all = zNPC_aligned;
                x2ndlandmark_all = x2ndlandmark_aligned; y2ndlandmark_all = y2ndlandmark_aligned; z2ndlandmark_all = z2ndlandmark_aligned;
            else
                xNPC_all = [xNPC_all xNPC_aligned]; yNPC_all = [yNPC_all yNPC_aligned]; zNPC_all = [zNPC_all zNPC_aligned];
                x2ndlandmark_all = [x2ndlandmark_all x2ndlandmark_aligned]; y2ndlandmark_all = [y2ndlandmark_all y2ndlandmark_aligned]; z2ndlandmark_all = [z2ndlandmark_all z2ndlandmark_aligned];
            end

        end
    end
end
if ishandle(wb), delete(wb); end

%% Show aligned superposition of segmented nucleoli image

[fig1d_composite, fig2d_composite, fig3d_composite] = show_1D2D3D(Inucall,xx2,yy2,zz2,'aligned superposition of segmented nucleoli'); close(fig1d_composite);
set(fig2d_composite,'Name','2D aligned nucleoli superposition');
place_figure(fig2d_composite,2,2,1,1);
set(fig3d_composite,'Name','3D aligned nucleoli superposition');
place_figure(fig3d_composite,2,2,2,1);
hold on;
view([1 1 1]); axis equal;
set(findobj(gca,'FaceColor','g','Type','patch'),'FaceColor','r'); % repaint the nucleolus in red

% show sphere
[xs,ys,zs] = sphere(50);
surf(xs*R0,  ys*R0, zs*R0,'FaceColor','yellow','EdgeColor','none');
axis equal
xlabel('x (mu)');
ylabel('y (mu)');
zlabel('z (mu)');
alpha(0.1);

%% Compute the "median" nucleolus.
% Definition: TODO !
Ibwnucmedian = (Inucall>N/2);
[fig1d_mediannuc, fig2d_mediannuc, fig3d_mediannuc] = show_1D2D3D(Ibwnucmedian,xx2,yy2,zz2,'median nucleolus'); close(fig1d_composite);
set(fig3d_mediannuc,'Name','3D median nucleolus');
alpha(0.3)


%% Show NPCs as small green spheres on 3D view
if ~exist('xNPC_all')
    disp(['There are apparenty no NPCs here to show !']);
    return;
else
    figure(fig3d_composite); hold on;
    [xs,ys,zs] = sphere(10);
    rs = 1/50;
    for i=1:numel(xNPC_all)
        if parameters.nice3Dview
            surf(-x0 + xNPC_all(i)+xs*rs, -y0 + yNPC_all(i)+ys*rs, -z0 + zNPC_all(i)+zs*rs,'FaceColor','g','EdgeColor','none');
            alpha(0.5);
        else
            text(-x0 +xNPC_all(i),-y0 +yNPC_all(i),-z0 + zNPC_all(i),num2str(i),'FontSize',8,'Color','g');
        end
        hold on;
    end
end

%% show nucleolar centers
for i=1:length(x2ndlandmark_all)
    if parameters.nice3Dview
        surf(-x0 + x2ndlandmark_all(i)+xs*rs, -y0 + y2ndlandmark_all(i)+ys*rs, -z0 + z2ndlandmark_all(i)+zs*rs,'FaceColor','r','EdgeColor','none');
        alpha(0.5);
    else
        text(-x0 +x2ndlandmark_all(i),-y0 + y2ndlandmark_all(i),-z0 + z2ndlandmark_all(i),num2str(i),'FontSize',8,'Color','r');
    end
end

if parameters.nice3Dview
    alpha(0.3); lighting gouraud;
end

%% Show NPCs on 2D view
show_spots(fig2d_composite,xNPC_all-x0,yNPC_all-y0,zNPC_all-z0,2,'g','');
if exist('xNPC_BOT','var')
    show_spots(fig2d_composite,xNPC_BOT-x0,yNPC_BOT-y0,zNPC_BOT-z0,2,'c','');
end
show_spots(fig2d_composite,x2ndlandmark_all-x0,y2ndlandmark_all-y0,z2ndlandmark_all-z0,2,'r','');
subplot(1,2,1), plot_circle(0,0,R0,'w-.'); subplot(1,2,2), plot_circle(0,0,R0,'w-.');


%% Cylindrical projection figures
for ifig=1:2
    fig_cylindricalprojection = figure('Name',['Cylindrical projection ',num2str(ifig)]);
    hold on;
    axis equal;
    title(['Cylindrical projection of ',num2str(numel(xNPC_all)),' NPC positions ']);
    xlabel('x (mu)');
    ylabel('y (mu)');
    thetas = 0:0.01:2*pi;
    plot_circle(0,0,R0,'k-.');
    % project NPC positions by rotation around the x-axis
    rhoNPC_all = sqrt((yNPC_all-y0).^2 + (zNPC_all-z0).^2); % distance of NPC to the x-axis
    rhosignedNPC_all = rhoNPC_all .* sign(yNPC_all-y0);
    if ifig == 1
        aux = rhoNPC_all;
    else
        aux = rhosignedNPC_all;
    end
    % show NPCs as green disks
    plot(xNPC_all-x0,aux,'ko','MarkerFaceColor','g');
    [thetanuc,phinuc,Rnuc] = cart2sph(x2ndlandmark_all-x0,y2ndlandmark_all-y0,z2ndlandmark_all-z0);
    [dxp,dyp]=pol2cart(thetanuc,Rnuc);
    plot(dxp,dyp,'ko','MarkerFaceColor','r');
end


%% Write results to text file
%auxRxfe = [output(inuclei).Rxfe];
%auxRyfe = [output(inuclei).Ryfe];
%auxRzfe = [output(inuclei).Rzfe];
%header = ['xNPC_all \t rhoNPC_all \t xcnucleoli_all \t x0 \t', ...
%    'Rxfe \t Ryfe \t Rzfe \n'];
%     \t x0 \t y0 \t z0 \n'];
%aux = [xbNPC_all(:)'; rhobNPC_all(:)'; xcnucleoli_all(:)'; x0*ones(1,length(xbNPC_all));...
%    auxRxfe(:)'; auxRyfe(:)'; auxRzfe(:)'  ];

%write_results2text_file(aux, header, currentclass);

% Additional data
%[pathstr, filename, ext, versn] = fileparts(currentclass);
%filename = [filename,'2.txt'];
%fid = fopen(filename, 'w');
%if fid==-1
%    disp(['WARNING: Could not open and write file ',filename,' !!']);
%else
%    fprintf(fid,'xx2=\n','char');
%    fprintf(fid,'%f\t',xx2(:));
%    fprintf(fid,'\nyy2=\n','char');
%    fprintf(fid,'%f\t',yy2(:));
%    Imaxnucall = max(Inucall, [], 3);
%    aux = repmat('%f\t ',[1 size(Imaxnucall,2)]);
%    fprintf(fid,'\nmax. int. proj. of Inucall with\nnrows=','char');
%    fprintf(fid,'%i\n',size(Inucall,1));
%    fprintf(fid,'ncols=','char');
%    fprintf(fid,'%i\n',size(Inucall,2));
%    for i = 1:size(Imaxnucall,1)
%        fprintf(fid, [aux, '\n'], Imaxnucall(i,:));
%    end
%    fclose(fid);
%    disp(['wrote file ',filename]);
%end

%% Save results
disp(['Saving worskpace to ',parameters.outputfile,' ...']);
save(parameters.outputfile);
disp('done');
disp('End of program');

end
