% Allow user to group processing results of nucquant_robot into categories


clc, close all, clear all;

disp('__________________________________________');
disp('nucquant_class: group nuclei into classes ');
disp('__________________________________________');


% Open the mat file containing the output of nucquant_robot.m
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Please select the  result file ');
%a=dir('nucquant_output*');
%FileName = a.name; 
%PathName = cd;
cd(PathName);
disp(['loading ',FileName,' ...']);
load(FileName);
disp([FileName,' loaded.']);

% Convert output structure for compatibility !!
if iscell(output)
    disp('converting structures for compatibility...');
    N = length(output);
    aux = output;
    aux_suppl = output_suppl;
    clear output output_suppl;
    i=1;
    while i<=N && ~isempty(aux{i})
        output(i) = aux{i};
        output_suppl(i) = aux_suppl{i};
        i =i +1;
    end
end


% Group classes
finished = 'n';
while finished=='n'
    N = length(output);
    disp('retrieving list of classes  ..');
    for i=1:N,
        if isfield(output,'class')
            aux = output(i).class;
        else % if no class exists for this nucleus, use the name of the folder to define the default class
            aux = output(i).parameters.fullmatfilename;
            [pathstr, name, ext] = fileparts(aux);
            output(i).class = pathstr;
        end
        classes{i} = output(i).class;
    end
    list_of_classes = unique(classes);
    Nclasses = length(list_of_classes);
    disp('Available classes:');
    for i=1:Nclasses
        disp(['Class #',num2str(i),' : ',list_of_classes{i}]);
    end

    aux1 = input2(['Please select one or several classes that you want to group into a new class (e.g. 1 for class 1, [1 2 4] for classes 1, 2 and 4.)\n', ...
        'Warning: the class order may have changed !'],'1');
    %iclass = str2num('1');
    aux = inputdlg(aux1,'',1,{'1'});
    iclass = str2num(aux{1});
    aux = inputdlg(['Please give a label to group #',num2str(iclass)],'',1,{char('A'+iclass-1)});
    classname = aux{1};
    %classname = 'Renjie'; 
    % Group selected classes and nuclei
    classes_of_interest = list_of_classes(iclass);
    inuclei = find(ismember(classes,classes_of_interest));
    for ii = 1:length(inuclei)
        inuc = inuclei(ii);
        disp(['assigning class ',classname,' to nucleus ',num2str(inuc),'..']);
        output(inuc).class = classname;
        output_suppl(inuc).class = classname;
    end

    finished = 'y';
end


%   save output and additional output data to a mat file
ClassifiedMatFileName = ['classified_',FileName];
save(ClassifiedMatFileName,'output','output_suppl');
disp(['Output parameters written to ',ClassifiedMatFileName]);


