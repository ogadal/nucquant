
% This script is the combination of correct z value and replace zNPC by new
% z value and refitting the reaidus of the nucleus.

function nucquant_correct_z

clc; close all, clear all;
% Pick the input data
%a=dir('QC_OK*');
%inputfilename = a.name;
%inputfolder = cd;
[inputfilename,inputfolder,FilterIndex]=uigetfile('*.mat','Please select the result file you want to correct Z');
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
disp(aux);
wb = waitbar(0,aux);
load(inputfilename);
if ishandle(wb), delete(wb); end
parameters.inputfilename = inputfilename;
parameters.inputfolder = inputfolder;

clear *_all;

i=length(output);


%% correct zNPC before and after.

% compute deltax, deltay and deltaz between NPC and nucleus and dist_NPC_nucleus/mean_R.
for j=1:i
dist_NPC_nucleus_x=[]; dist_NPC_nucleus_y=[]; dist_NPC_nucleus_z=[];
dist_NPC_nucleus_centroid=[];dist_NPC_nucleus_centroid_relative=[];R=[];

% Import nuclei centers
    xcnucleus = []; ycnucleus = []; zcnucleus = [];
    xcnucleus = [output.xn];
    ycnucleus = [output.yn];
    zcnucleus = [output.zn];

% Import the position and the number of NPCs
   xNPC = []; yNPC = []; zNPC = []; nbNPC = [];
   xNPC = [output.xNPC];
   yNPC = [output.yNPC];
   zNPC = [output.zNPC];
   nbNPC = [output.nbNPC];
   
% Import the half-axies of the nucleus ellipsoid
    Rx=[output.Rxfe];
    Ry=[output.Ryfe];
    Rz=[output.Rzfe];
    
disp('computing detax, detay and detaz between NPC and nucleus center including the dist_NPC_nucleus_relative...');
a=sum(nbNPC(1:(j-1)))+1;b=sum(nbNPC(1:j)); % extract coordinates of NPCs to their corresponding nuclei
output(j).dist_NPC_nucleus_centroid=distance3d(xNPC(a:b),yNPC(a:b),zNPC(a:b),xcnucleus(j),ycnucleus(j),zcnucleus(j));
output(j).R=[Rx(j),Ry(j),Rz(j)];
output(j).dist_NPC_nucleus_centroid_relative=output(j).dist_NPC_nucleus_centroid/mean(output(j).R);
output(j).dist_NPC_nucleus_x=xNPC(a:b)-xcnucleus(j);
output(j).dist_NPC_nucleus_y=yNPC(a:b)-ycnucleus(j);
output(j).dist_NPC_nucleus_z=zNPC(a:b)-zcnucleus(j);

end

% Plot the origin figure
figure('Name','origin data analysis');
subplot(1,3,1);
x=[output.dist_NPC_nucleus_x];
y=[output.dist_NPC_nucleus_centroid_relative];
xlabel('deltaXNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
plot(x,y,'r.','MarkerSize',4);
legend(['N=',num2str(length(x))]);

subplot(1,3,2);
x=[output.dist_NPC_nucleus_y];
y=[output.dist_NPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaYNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);

subplot(1,3,3);
x=[output.dist_NPC_nucleus_z];
y=[output.dist_NPC_nucleus_centroid_relative];
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaZNPC-nucleus (mu)'),
ylabel('Distance/Radius'),
legend(['N=',num2str(length(x))]);

% Fitting the figure3 using polyfit
p=polyfit(x,y,2);

c=p(1);d=p(2);

% correct the z value.
for j=1:i
    
   xn_new=[];yn_new=[];zn_new=[];R_xy=[];R_xy_mean=[];R_mean=[];
   
   % import the position of the nucleus center
   
   output(j).xn_new=output(j).xn*ones(1,output(j).nbNPC);
   output(j).yn_new=output(j).yn*ones(1,output(j).nbNPC);
   output(j).zn_new=output(j).zn*ones(1,output(j).nbNPC); 
   output(j).R_mean=mean(output(j).R)*ones(1,output(j).nbNPC);
   output(j).R_xy=[output(j).Rxfe,output(j).Ryfe];
   output(j).R_xy_mean=mean(output(j).R_xy)*ones(1,output(j).nbNPC);
end

% Import the postion of all nucleus center(z) (new)
zcnucleus = [];R_mean_new=[];R_mean=[];

zcnucleus = [output.zn_new];
R_mean_new=[output.R_xy_mean];
R_mean=[output.R_mean];

   
% Import the position and the number of NPCs
xNPC = []; yNPC = []; zNPC = []; nbNPC = [];
xNPC = [output.xNPC];
yNPC = [output.yNPC];
zNPC = [output.zNPC];
nbNPC = [output.nbNPC];

% Import the deltax, deltay and deltaz
dist_NPC_nucleus_x=[];dist_NPC_nucleus_y=[];dist_NPC_nucleus_z=[];
dist_NPC_nucleus_x=[output.dist_NPC_nucleus_x];
dist_NPC_nucleus_y=[output.dist_NPC_nucleus_y];
dist_NPC_nucleus_z=[output.dist_NPC_nucleus_z];

% Import the old distance between NPC and nucleus center
dist_NPC_nucleus_centroid_relative=[];dist_NPC_nucleus_z_new=[];zNPC_new=[];
dist_NPC_nucleus_centroid_relative=[output.dist_NPC_nucleus_centroid_relative];

m=sum(nbNPC(1:i));dist_NPC_nucleus_centroid_relative_new=[];dist_NPC_nucleus_centroid_new=[];delta=[];
for k=1:m
    dist_NPC_nucleus_centroid_relative_new(k)=dist_NPC_nucleus_centroid_relative(k)-c*(dist_NPC_nucleus_z(k))^2-d*(dist_NPC_nucleus_z(k));
    dist_NPC_nucleus_centroid_new(k)=dist_NPC_nucleus_centroid_relative_new(k)*R_mean(k);
if dist_NPC_nucleus_z(k)<0
        dist_NPC_nucleus_z_new(k)=-sqrt(abs((dist_NPC_nucleus_centroid_new(k))^2-(dist_NPC_nucleus_x(k))^2-(dist_NPC_nucleus_y(k))^2));
else
    dist_NPC_nucleus_z_new(k)=sqrt(abs((dist_NPC_nucleus_centroid_new(k))^2-(dist_NPC_nucleus_x(k))^2-(dist_NPC_nucleus_y(k))^2));
end   % This part I think the z correction exist some question, we need to check.
zNPC_new(k)=dist_NPC_nucleus_z_new(k)+zcnucleus(k);
end
delta_z=zNPC_new-zNPC;%%%
clear p a b c d;

% Plot the figure
figure('Name','correctted data');
subplot(2,2,1);
x=dist_NPC_nucleus_x;
y=dist_NPC_nucleus_centroid_relative_new;
xlabel('deltaXNPC-nucleus (mu)'),
ylabel('Distance'),
plot(x,y,'r.','MarkerSize',4);
legend(['N=',num2str(length(x))]);

subplot(2,2,2);
x=dist_NPC_nucleus_y;
y=dist_NPC_nucleus_centroid_relative_new;
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaYNPC-nucleus (mu)'),
ylabel('Distance'),
legend(['N=',num2str(length(x))]);

subplot(2,2,3);
x=dist_NPC_nucleus_z_new;
y=dist_NPC_nucleus_centroid_relative_new;
plot(x,y,'r.','MarkerSize',4);
xlabel('deltaZNPC-nucleus-new (mu)'),
ylabel('Distance'),
legend(['N=',num2str(length(x))]);

subplot(2,2,4);
x=[output.dist_NPC_nucleus_z];
y=delta_z;
plot(x,y,'r.','MarkerSize',4);
xlabel('zNPC(mu)'),
ylabel('deltaz-new-old(mu)'),
legend(['N=',num2str(length(x))]);

% fit the curve of the fourth figure
p=polyfit(x,y,3);
a=p(1); b=p(2); c=p(3); d=p(4);

%% Use new zNPC replace the origin zNPC.

nbNPC = [output.nbNPC];

for j=1:i
    disp('computing the new zNPC...');
    e=sum(nbNPC(1:(j-1)))+1;f=sum(nbNPC(1:j));
    output(j).zNPC=zNPC_new(e:f);
end

%% Correct the z value of the nucleolus center.
zcnuc=[output.zcnuc];zc=[output.zc];
mn=zcnuc-zc;
for j=1:i
    disp('Computing the new zcnuc...');
    output(j).zcnuc=a*mn(j)^3+b*mn(j)^2+c*mn(j)+d+zcnuc(j);
end

%% Correct the z value of the bright spot in red channel
zbNPC_ch2=[output.zbNPC_ch2];
ms=zbNPC_ch2-zc;
for j=1:i
    if zbNPC_ch2(j)==NaN
        disp('there is no bright spot in second channel');
    else
        output(j).zbNPC_ch2=a*ms(j)^3+b*ms(j)^2+c*ms(j)+d+zbNPC_ch2(j);
    end
end

%% Refitting the radius by ellipsoid_3param method.

for j=1:i
    
if 1==1 %%% Use putative NPC
        xNEp = output(j).xNPC; yNEp = output(j).yNPC; zNEp = output(j).zNPC; sNEp = output(j).sNPC; nbNEp = output(j).nbNPC;
end
if nbNEp>0
  disp('fitting a 3-parameter (Rx,Ry,Rz)  axes-aligned ellipsoid ..');
  [output(j).Rxfe,output(j).Ryfe,output(j).Rzfe,meandist_fn,residual,exitflag_fn] = fit_ellipsoid_3param(xNEp,yNEp,zNEp,sNEp,output(j).xc,output(j).yc,output(j).zc);
  [output(j).xn,output(j).yn,output(j).zn] = deal(output(j).xc,output(j).yc,output(j).zc);  
  disp(['result of fitting nucleus surface: meandist_fn=',num2str(meandist_fn),', exitflag=',num2str(exitflag_fn)]);
else
    Rxfe = NaN; Ryfe = NaN; Rzfe = NaN;
        [output(j).xn,output(j).yn,output(j).zn] = deal(output(j).xc,output(j).yc,output(j).zc); meandist_fn=NaN; exitflag_fn=NaN;
end
end

%% Delete the rest of the parameters during this caculation
clear R;
clear R_mean R_mean_new R_xy R_xy_mean Rx Ry Rz;
clear dist_NPC_nucleus_centroid dist_NPC_nucleus_centroid_new dist_NPC_nucleus_centroid_relative dist_NPC_nucleus_centroid_relative_new;
clear dist_NPC_nucleus_x dist_NPC_nucleus_y dist_NPC_nucleus_z dist_NPC_nucleus_z_new exitflag_fn i j k m meandist_fn nbNEp nbNPC;
clear p residual sNEp x xNEp xNPC xcnucleus xn_new y yNEp yNPC ycnucleus yn_new zNEp zNPC zNPC_new zcnucleus zn_new;
clear e f aux inputfilename inputfolder parameters wb delta delta_z;
clear zcnuc mn zc zbNPC_ch2 ms;

%% 3D-NE fitting to calculate the size of the nucleus and the sphericity.

j=length(output); % number of the cells

ncl=1; % number of clusters

for nk1=1:j
    X=[];Y=[];Z=[];

    x=output(1,nk1).xNPC; X=[X x]; 
    y=output(1,nk1).yNPC; Y=[Y y]; 
    z=output(1,nk1).zNPC; Z=[Z z]; 

    xc=output(nk1).xc;yc=output(nk1).yc;zc=output(nk1).zc;
    Cc=[xc yc zc];
    
    % Calculate the distance of NPC to the nucleus center.
    output(nk1).dist_NPC_NC=distance3d(x,y,z,xc,yc,zc);

    X=transpose(X);Y=transpose(Y);Z=transpose(Z);

    U=[X Y Z];
    opts = statset('Display','final');
    [idx,C] = kmeans(U,ncl,'Distance','sqeuclidean','Replicates',5,'Options',opts);
    n1=size(U(idx==1,1),1);n2=size(U(idx==2,1),1);n3=size(U(idx==3,1),1);

    [nn1,nn2,nn3]=plusgr3(n1,n2,n3);
    
    if ncl==1
        %subplot(2,2,2);

        [S,U2]=kamregul(U,Cc,3); % The 3rd parameter of kamregul represents the hypothetical time, the more we used,
        % the more hypothetical spots were produced.

        % Create the triangle small faces.
        U1=[U2;S];
        dv1=delaunayn(U1);
        tr1=TriRep(dv1,U1);
        [trv1,vb1]=freeBoundary(tr1);

        % The parameters of all the small faces.
        FV11.vertices=vb1;FV11.faces=trv1;
        clear vb1 trv1 FV2

    end
    
    % Calculate the surface area and volume of each nucleus.
    if ncl==1   
        disp(['Computing the ', num2str(nk1),' nucleus volume and sphericity...']);
        [Vr,Sr]=stlVolume(transpose(FV11.vertices),transpose(FV11.faces));
        % save the results.
        output(nk1).Vnucleus_3D=Vr;
        output(nk1).Snucleus_3D=Sr;
        % Calculate the radius of the sphere with the same volume.
        Rr=(3*Vr/(4*pi))^(1/3);
        output(nk1).Rr=Rr;
        % Calculate the surface area of the sphere with the same volume of this
        % fitting result.
        Ss=4*pi*((3*Vr)/(4*pi))^(2/3);
        % Calculate the parameter which can be used to analyze if the shape
        % of the fitting result. The more closer to 1, the more
        % near to sphere.
        output(nk1).sphericity=Ss/Sr;
    end
    
    clear x y z xc yc zc opts dv1 C Cc idx n1 n2 n3 nn1 nn2 nn3 S FV11 Rr Sr Ss tr1 U U1 U2 Vr X Y Z; 
end

clear j ncl nk1 zcnuc;

save QC_OKcorrect_nucquant_output_suppl.mat;
disp('done');
disp('End of program');

end


