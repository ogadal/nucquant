% This script is the combination of correct z value and replace zNPC zgene zcnuc by new
% z value and refitting the reaidus of the nucleus.

function nucquant_correct_z_manually

clc; close all, clear all;
% Pick the input data
%a=dir('QC_OK*');
%inputfilename = a.name;
%inputfolder = cd;
[inputfilename,inputfolder,FilterIndex]=uigetfile('*.mat','Please select the result file you want to correct Z');
cd(inputfolder);
aux = ['loading ',inputfilename,'...'];
disp(aux);
load(inputfilename);

% request use input
prompt={'Enter the prefactor a of x^3:', ...
    'Enter the prefactor b of x^2:', ...
    'Enter the prefactor c of x:', ...
    'Enter the constant parameter d:'};
default_values={'-0.0662','0.0027','-0.2923','0.0088'};%%%
answer=inputdlg(prompt,'Check the parameters',1,default_values);
a=str2num(answer{1});
b=str2num(answer{2});
c=str2num(answer{3});
d=str2num(answer{4});

j=length(output);
for i=1:j
    % import the nuclei center
    xc=output(i).xc;
    yc=output(i).yc;
    zc=output(i).zc;
    % import the position of NPCs
    xNPC=[output(i).xNPC];
    yNPC=[output(i).yNPC];
    zNPC=[output(i).zNPC];
    nbNPC=output(i).nbNPC;

    % Correct the zNPC.
    mn=zNPC-zc;
    for s=1:nbNPC
    zNPC_new(s)=a*(mn(s))^3+b*(mn(s))^2+c*(mn(s))+d+zNPC(s);
    end
    
    % Use the new zNPC replace the old one.
    output(i).zNPC=zNPC_new;
    clear xc yc zc xNPC yNPC zNPC zNPC_new nbNPC mn s;
end

%% Correct the z value of the nucleolus center.
zcnuc=[output.zcnuc];zc=[output.zc];
mn=zcnuc-zc;
for j=1:i
    disp('Computing the new zcnuc...');
    output(j).zcnuc=a*mn(j)^3+b*mn(j)^2+c*mn(j)+d+zcnuc(j);
end

%% Correct the z value of the bright spot in red channel
zbNPC_ch2=[output.zbNPC_ch2];
ms=zbNPC_ch2-zc;
for j=1:i
    if zbNPC_ch2(j)==NaN
        disp('there is no bright spot in second channel');
    else
        output(j).zbNPC_ch2=a*ms(j)^3+b*ms(j)^2+c*ms(j)+d+zbNPC_ch2(j);
    end
end

%% Refitting the radius by ellipsoid_3param method.
clear i;

for i=1:j
    
if 1==1 %%% Use putative NPC
        xNEp = output(i).xNPC; yNEp = output(i).yNPC; zNEp = output(i).zNPC; sNEp = output(i).sNPC; nbNEp = output(i).nbNPC;
end
if nbNEp>0
  disp('fitting a 3-parameter (Rx,Ry,Rz)  axes-aligned ellipsoid ..');
  [output(i).Rxfe,output(i).Ryfe,output(i).Rzfe,meandist_fn,residual,exitflag_fn] = fit_ellipsoid_3param(xNEp,yNEp,zNEp,sNEp,output(i).xc,output(i).yc,output(i).zc);
  [output(i).xn,output(i).yn,output(i).zn] = deal(output(i).xc,output(i).yc,output(i).zc);  
  disp(['result of fitting nucleus surface: meandist_fn=',num2str(meandist_fn),', exitflag=',num2str(exitflag_fn)]);
else
    Rxfe = NaN; Ryfe = NaN; Rzfe = NaN;
        [output(i).xn,output(i).yn,output(i).zn] = deal(output(i).xc,output(i).yc,output(i).zc); meandist_fn=NaN; exitflag_fn=NaN;
end
end

clear a b c d i j prompt a answer aux default_values inputfilename inputfolder;
clear xNEp yNEp zNEp sNEp nbNEp exitflag_fn meandist_fn residual;
clear ms mn zc zcnuc zgene;
%clear zcnuc zc mn;
save QC_OKcorrect_output_nucquant_file.mat;
disp('done');
disp('End of program');
end


