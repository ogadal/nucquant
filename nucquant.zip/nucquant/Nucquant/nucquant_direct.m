% Tiny script that runs the program nucleolus.m in non-driven mode

clear all, close all hidden; clc;
global swapRG;

disp('------------------------------------------------------------------');
disp('nucquant_direct');
disp('------------------------------------------------------------------');

dir0 = cd;
cd(dir0);

[parameters.matfilename parameters.dir0] = uigetfile('*.mat','Pick the .mat file that contains the image and acquisition info');

% parameters = get_nucquant_user_parameters(parameters);
parameters = nucquant_gui(parameters)

parameters.fullmatfilename = fullfile(parameters.dir0,parameters.matfilename);


[out,out_suppl] = nucleolus(parameters);
