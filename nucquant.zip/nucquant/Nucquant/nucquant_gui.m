function varargout = nucquant_gui(varargin)
% NUCQUANT_GUI M-file for nucquant_gui.fig
%      NUCQUANT_GUI, by itself, creates a new NUCQUANT_GUI or raises the existing
%      singleton*.
%
%      H = NUCQUANT_GUI returns the handle to a new NUCQUANT_GUI or the handle to
%      the existing singleton*.
%
%      NUCQUANT_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NUCQUANT_GUI.M with the given input arguments.
%
%      NUCQUANT_GUI('Property','Value',...) creates a new NUCQUANT_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before nucquant_gui_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to nucquant_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help nucquant_gui

% Last Modified by GUIDE v2.5 24-Apr-2014 16:28:29

%% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @nucquant_gui_OpeningFcn, ...
    'gui_OutputFcn',  @nucquant_gui_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% --- Executes just before nucquant_gui is made visible.
function nucquant_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to nucquant_gui (see VARARGIN)

% Propagate the parameters used when calling nucquant_gui ; the new settings
% will be added to this parameter structure
if ~isempty(varargin)
    handles.output = varargin{1};
    parameters = handles.output;
else
    error('nucquant_gui should be called with parameters as input !');
end

% Set default advanced parameters
parameters.nucleus_surface_fit = 'ellipsoid_3param';
parameters.bNPC_localization_method = 'intensity-weighted';
parameters.NPC_localization_method = 'intensity-weighted';
parameters.bNPC_centroid_threshold_percentage = 80;
parameters.NPC_min_score_percentage = 1;
parameters.NPC_are_peripheral  = 1;
parameters.cheat = 0;
handles.output = parameters;

% Update handles structure
guidata(hObject, handles);
%pushbutton1_Callback(hObject, eventdata, handles);
uiwait;

% UIWAIT makes nucquant_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%% --- Outputs from this function are returned to the command line.
function varargout = nucquant_gui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
varargout{1} = handles.output;

close(handles.figure1);

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

parameters = handles.output; % this retrieves the parameters set before using the GUI

% Retrieve the parameters from the GUI:

% Number of bNPCs in green and red channels
if get(handles.radiobutton13,'Value')
    parameters.nb_bNPCs_ch1 = '1';
elseif get(handles.radiobutton2,'Value')
    parameters.nb_bNPCs_ch1 = '1 or 2';
elseif get(handles.radiobutton1,'Value')
    parameters.nb_bNPCs_ch1 = '2';
elseif get(handles.radiobutton25,'Value')
    parameters.nb_bNPCs_ch1 = '0';    
elseif get(handles.radiobutton30,'Value')
    parameters.nb_bNPCs_ch1 = get(handles.edit3,'String');
else
    error('this should not happen !');
end

if get(handles.radiobutton28,'Value')
    parameters.nb_bNPCs_ch2 = '1';
elseif get(handles.radiobutton27,'Value')
    parameters.nb_bNPCs_ch2 = '1 or 2';
elseif get(handles.radiobutton26,'Value')
    parameters.nb_bNPCs_ch2 = '2';
elseif get(handles.radiobutton29,'Value')
    parameters.nb_bNPCs_ch2 = '0';    
end


% Save figures?
if get(handles.radiobutton12,'Value')
    parameters.save_figures = 'y';
elseif get(handles.radiobutton10,'Value')
    parameters.save_figures = 'n';
end

% Nucleus staining type
if get(handles.radiobutton4,'Value')
    parameters.nuclear_staining = 'Nucleoplasm';
elseif get(handles.radiobutton14,'Value')
    parameters.nuclear_staining = 'Nuclear envelope';
end

% Swap red and green ?
parameters.swap_redgreen= get(handles.checkbox1,'Value') == get(handles.checkbox1,'Max');

% Locate nucleus center
parameters.locate_nucleus_center = get(handles.checkbox5,'Value') == get(handles.checkbox5,'Max');

% Locate nucleolus ?
parameters.process_nucleolus =  get(handles.checkbox2,'Value') == get(handles.checkbox2,'Max');

% Detect NPC clusters ?
parameters.detect_NPC = get(handles.checkbox3,'Value') == get(handles.checkbox3,'Max');

% Detect nuclear envelope ?
parameters.detect_envelope = get(handles.checkbox4,'Value') == get(handles.checkbox4,'Max');

% Show/save figures ?
if get(handles.radiobutton12,'Value') % Show and save
    parameters.show_figures = 1;
    parameters.save_figures = 1;
elseif get(handles.radiobutton10,'Value')
    parameters.show_figures = 0;
    parameters.save_figures = 0;
elseif get(handles.radiobutton24,'Value')
    parameters.show_figures = 1;
    parameters.save_figures = 0;
end

% Save incomplete results every xxx frames
parameters.save_incomplete_period = str2num(get(handles.edit2,'String'));

%Other parameters
parameters.save_tabular = 'n';

handles.output = parameters;

guidata(hObject,handles);

% close(gcf);

uiresume;


%% --- Executes on key press over pushbutton1 with no controls selected.
function pushbutton1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
parameters = nucquant_advanced_settings(handles.output);
handles.output = parameters;
guidata(hObject,handles);

% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1




% --------------------------------------------------------------------
function uipanel4_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4




% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5





function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


