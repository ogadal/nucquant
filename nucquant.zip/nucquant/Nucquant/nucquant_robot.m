% Script that drives the program nucleolus.m on series of data
%
global I3d;
global xx_glo;
global yy_glo;
global zz_glo;
global hR_isosurface; % isosurface handle for Ired channel
global hG_isosurface; % isosurface handle for green channel
global hB_isosurface; % isosurface handle for blue channel
global pR_isosurface; % isosurface patch handle for red channel
global pG_isosurface; % isosurface patch handle for green channel
global pB_isosurface; % isosurface patch handle for blue channel
global swapRG;


clear all; close all hidden; clc;
disp('------------------------------------------------------------------');
disp('nucquant_robot');
disp('------------------------------------------------------------------');

aux = fclose('all');
if aux<0
    warning('Could not close all files !!');
end

% Number of monitors
NbMonitors = size(get(0,'MonitorPosition'),1);

% Setting some processing parameters
warning off;

% Specify default folder for inputs and outputs
dir_def = cd;

% Get list of input data
[mat_file_rel_path, dir_in]  = get_nucquant_input_data(dir_def);

% Let user choose processing parameters
parameters = [];
if 1==0
    parameters = get_nucquant_user_parameters(parameters);
else
    parameters = nucquant_gui(parameters);
end

%% Check if there is an incomplete processing result file (e.g. due to a
% crash), and if the user agrees, reuse it to avoid reprocessing everything
cd(dir_in);
aux = dir('*.mat.incomplete');
if ~isempty(aux)
    suppl_outputfilename_temp = aux(1).name;
    disp(['I detected an incomplete matlab file named ',suppl_outputfilename_temp,' !'])
    answer = questdlg('Incomplete results found. Use it without reprocessing ?','','Yes','No','Yes');
    if strcmp(answer,'Yes')
        reuse_incomplete_results = 'y';
    else
        reuse_incomplete_results = 'n';
    end
else
    disp('No incomplete matlab file detected !');
    reuse_incomplete_results = 'n';
end
if reuse_incomplete_results=='y' % Reuse already processed data
    disp(' I will build on existing results by not reprocessing these nuclei !');
    suppl_outputfilename = suppl_outputfilename_temp(1:end-11);
    disp(['Copying ',suppl_outputfilename_temp,' to ',suppl_outputfilename,'..']);
    copyfile(suppl_outputfilename_temp,suppl_outputfilename);
    disp(['Loading ',suppl_outputfilename,'...']);
    load(suppl_outputfilename);
    nucleus_processed = zeros(1,length(output));
    for i=1:length(output)
        nucleus_processed(i) = ~isempty(output{i});
    end
    Nallmatfiles = length(output);
    nuclei_to_process = find(nucleus_processed == 0);
    Nnuclei_processed = length(find(nucleus_processed));
    disp(['There are ',num2str(Nallmatfiles),' nuclei, out of which ',num2str(Nnuclei_processed),' have already been processed.']);
    dir_out = dir_in;
else
    Nallmatfiles = length(mat_file_rel_path);
    nuclei_to_process = 1:Nallmatfiles;
end

disp('Please wait..');

Nnuclei_to_process = length(nuclei_to_process);
disp(['There are ',num2str(Nnuclei_to_process),' nuclei to be processed.']);
if 1==0 % list the files of all nuclei to be processed
    for inucleus = nuclei_to_process
        disp(['Nucleus #',num2str(inucleus),': ',mat_file_rel_path{inucleus}]);
    end
end
% wbfolders = waitbar(0,['processing folder 1/',num2str(N_folders)]);




%% Specify folder for storing output (unless reusing existing results)
if reuse_incomplete_results=='n'
    cd(dir_in);
    dir_out = dir_in;
    FileName = ['nucquant_output_',num2str(Nnuclei_to_process),'cells'];
    cd(dir_out);

    % Create text, Excel and mat-files for storing output parameters, asking to
    % delete or rename existing files if needed
    [pathstr,populationname,ext] = fileparts(fullfile(dir_out,FileName));
    if parameters.save_tabular == 'y'
        outputExcelfilename = [populationname,'.xls'];
        rename_or_delete(pathstr,outputExcelfilename);
        outputtextfilename =  [populationname,'.txt'];
        rename_or_delete(pathstr,outputtextfilename);
        outputtextfilename_temp = [populationname,'_incomplete.txt'];
        rename_or_delete(pathstr,outputtextfilename_temp);
    end
    suppl_outputfilename = [populationname,'_suppl.mat'];
    rename_or_delete(pathstr,suppl_outputfilename);
    suppl_outputfilename_temp = [suppl_outputfilename,'.incomplete'];
    rename_or_delete(pathstr,suppl_outputfilename_temp);
else

end


% Pre-allocate output structures for speed (unless reusing existing
% structures)
if ~exist('output','var')
    output = cell(Nallmatfiles,1);
end
if ~exist('output_suppl','var')
    output_suppl = cell(Nallmatfiles,1);
end

% Header of output text or Excel file
if parameters.save_tabular == 'y'
    fid = fopen(outputtextfilename_temp,'w');
    fprintf(fid,'%s\n',datestr(now));
    fprintf(fid,'folder\tmat_file\txbNPC\tybNPC\tzbNPC\tnb(NPC)\txfn\tyfn\tzfn\txcnuc\tycnuc\tzcnuc\tRxfe\tRyfe\tRzfe\tV_nucleus\tV_nucleolus\texitflag_fn\tmeandist_fn\trho(bNPC)\td(bNPC,nucleolus)\td(bNPC,nucleus)\n');
    excel_output = {'folder', 'mat_file', 'xbNPC', 'ybNPC', 'zbNPC', 'nb(NPC)', 'xfn', 'yfn', 'zfn', 'xcnuc', 'ycnuc', 'zcnuc', 'Rxfe', 'Ryfe', 'Rzfe', 'V_nucleus', 'V_nucleolus', 'exitflag_fn', 'meandist_fn', 'rho(bNPC)', 'd(bNPC,nucleolus)', 'd(bNPC,nucleus)'};
end


% Set processing options
dir0 = cd;  cd(dir0); parameters.dir0 = dir0;

%% Do the processing
if exist('wdlg','var')
    close(wdlg);
end
i_folder = 0;
enter_new_folder = 'y';

wbnuclei = waitbar(0,'Starting ..');
t1 = clock;
if NbMonitors>1
    aux = get(wbnuclei,'Position');
    scrsz = get(0,'ScreenSize');
    set(wbnuclei,'Position',[scrsz(4) scrsz(3)/2 aux(3) aux(4)]);
end
set(wbnuclei,'CloseRequestFcn','')

for i_matfile = 1:Nnuclei_to_process
    inucleus = nuclei_to_process(i_matfile);
    % text for waitbar
    text4waitbar =  ['Processing nucleus ',num2str(i_matfile),'/',num2str(Nnuclei_to_process),'..'];
    if i_matfile>1
        time_remaining_max = seconds2timestring(ceil(max(time_pernucleus)*(Nnuclei_to_process-i_matfile+1)));
        text4waitbar = [text4waitbar,' time left ~ ',time_remaining_max];
        if i_matfile>2 && 1==0
            time_remaining_std = seconds2timestring(round(std(time_pernucleus)*(Nnuclei_to_process-i_matfile+1)));
            text4waitbar = [text4waitbar,' +/- ',time_remaining_std];
        end
    end
    waitbar((i_matfile-0.5)/Nnuclei_to_process,wbnuclei,text4waitbar);
    % Choose current data set (*.mat file)

    disp(['Processing nucleus #',num2str(inucleus),' (',num2str(i_matfile),'/',num2str(Nnuclei_to_process),') ...']);
    % Processing by nucleolus.m
    parameters.fullmatfilename = mat_file_rel_path{inucleus};
    clear out out_suppl;
    t = clock;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% Do the nuclear localization analysis %%%%%
    [out,out_suppl] = nucleolus(parameters);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    time_pernucleus(i_matfile) = etime(clock,t);
    % save figures to local folder (first create this folder, if it doesn't exist)
    [path mat_file_stem aux1] = fileparts(parameters.fullmatfilename);
    cd(path);
    if parameters.save_figures
        local_results_folder = [mat_file_stem,'_results'];
        if exist(local_results_folder,'dir')~=7,
            mkdir(local_results_folder);
        end
        cd(local_results_folder);
        disp('Saving figures ...');
        if ispc && 1==0
            saveas(out.fig2d_orig1,'original2D', 'emf');
            saveas(out.fig2d_segnp,'nucleus_seg2D', 'emf');
            saveas(out.fig2d_smoothed,'smoothed2D', 'emf');
            saveas(out.fig3d_seg,'view3D','emf');
            saveas(out.fig_radproj,'radproj','emf');
            saveas(out.fig_NPC,'NPCcuts','emf');
        end
        saveas(out.fig2d_orig1,'original2D', 'fig');
        if isfield(out,'fig2d_segnp') && 1==0 %&& ishandle(out.fig2d_segnp)
            saveas(out.fig2d_segnp,'nucleus_seg2D', 'fig');
        end
        saveas(out.fig2d_smoothed,'smoothed2D', 'fig');
        saveas(out.fig3d_seg,'view3D','fig');
        saveas(out.fig_radproj,'radproj','fig');
        if isfield(out,'fig_NPC') && 1==0
            saveas(out.fig_NPC,'NPCcuts','fig');
        end
    end

    % save output data obtained so far
    dir_last = cd;
    cd(dir_out);
    if parameters.save_tabular == 'y'
        if 1==1 % write text file with data obtained thus far
            disp(['writing to file ',outputtextfilename_temp,'...']);
            fprintf(fid,'%s\t%s\t%f\t%f\t%f\t%i\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%i\t%f\t%f\t%f\t%f\n',path,mat_file_stem,out.xbNPC,out.ybNPC,out.zbNPC,out.nbNPC,out.xfn,out.yfn,out.zfn,out.xcnuc,out.ycnuc,out.zcnuc,out.Rxfe,out.Ryfe,out.Rzfe,out.Vnucleus_mu3,out.Vnuc_mu3,out.exitflag_fn,out.meandist_fn,out.rhobNPC,out.dist_bNPC_nucleolus,out.dist_bNPC_nucleus);
        else % write Excel file
            % TODO:voir comment faire pour eviter l'apparition d'une
            % fenetre de dialogue demandant si on peut ecraser la
            % version existante du fichier !
            xlswrite(outputtextfilename_temp,[path mat_file_stem out.xbNPC out.ybNPC out.zbNPC out.nbNPC out.xfn out.yfn out.zfn out.xcnuc out.ycnuc out.zcnuc out.Rxfe out.Ryfe out.Rzfe out.Vnucleus_mu3 out.Vnuc_mu3 out.exitflag_fn out.meandist_fn out.rhobNPC out.dist_bNPC_nucleolus out.dist_bNPC_nucleus]);
        end
    end

    output{inucleus} = out;
    output_suppl{inucleus} = out_suppl;

    if parameters.save_tabular == 'y'
        aux = {path, mat_file_stem, out.xbNPC, out.ybNPC, out.zbNPC, out.nbNPC, out.xfn, out.yfn, out.zfn, out.xcnuc, out.ycnuc, out.zcnuc, out.Rxfe, out.Ryfe, out.Rzfe, out.Vnucleus_mu3, out.Vnuc_mu3, out.exitflag_fn, out.meandist_fn, out.rhobNPC, out.dist_bNPC_nucleolus, out.dist_bNPC_nucleus};
        excel_output = [excel_output; aux];
    end
    close all;

    % save output data obtained so far as mat file
    if exist('output','var') && mod(i_matfile,parameters.save_incomplete_period)==0
        disp(['writing to ',suppl_outputfilename_temp,'...']);
        save(suppl_outputfilename_temp,'output','output_suppl');
    end

end
time_tot = etime(clock,t1);
waitbar((Nnuclei_to_process-0.25)/Nnuclei_to_process,wbnuclei,'Finishing up..');

%% save output data obtained so far as mat file
if exist('output','var')
    disp(['writing to ',suppl_outputfilename_temp,'...']);
    save(suppl_outputfilename_temp,'output','output_suppl');
end


cd(dir_out);

%% save final output data as Excel (Windows) or text file (Mac)
if parameters.save_tabular == 'y'
    if ispc
        disp(['Writing Excel file ',outputExcelfilename,' ...']);
        xlswrite(outputExcelfilename,excel_output);
    end

    % save final output data as txt file
    fclose(fid);
    movefile(outputtextfilename_temp,outputtextfilename);
end


%%   save final output and additional output data to a mat file
movefile(suppl_outputfilename_temp,suppl_outputfilename);

close all hidden;
if exist('wbnuclei','var') && 1==0
    delete(wbnuclei);
end

if exist('time_pernucleus','var')
    disp(['Processing time per nucleus: min = ',num2str(min(time_pernucleus)),', mean = ', num2str(mean(time_pernucleus)),', max =',num2str(max(time_pernucleus))]);
end

disp(['Total processing time = ',num2str(time_tot),' s']);
disp('Program finished.');

%% Show graph of processing time
figure,
plot(1:length(time_pernucleus),time_pernucleus);
xlabel('Nucleus analyzed ');
ylabel('Processing time per nucleus (s)');



