function sigma = pair_close_positions_2(points1,points2,maxdist)
% Pair the two sets of points based on mimimum distance, with the maximum
% distance allowed given by 'maxdist'
% Returns the permutation sigma that achieves this pairing, so that:
%      point1(i,:) is the best match to point2(sigma(i),:)
% The second set of points can contain fewer, but not more points than the first set.
% If a point in the 1st set cannot be paired, then the corresponding value of sigma
% is set to NaN.
% The arguments are matrices of the form Nx2, where N is the number of points, and
% the rows contain the x and y coordinates of each point:
%  x(1) y(1)
%  x(2) y(2)
%  ...  ...
%  x(N) y(N)

points1 = squeeze(points1);
points2 = squeeze(points2);

%% Handle a wrong squeeze that can occur if there is only one point in one of the sets
if size(points1,2)~=2 & size(points1,1)==2
    points1=points1';
end
if size(points2,2)~=2 & size(points2,1)==2
    points2=points2';
end

N1 = size(points1,1);
N2 = size(points2,1);

N1valid = length(points1(isfinite(points1(:,1))));
N2valid = length(points2(isfinite(points2(:,1))));
if(N1valid<N2valid)
    disp('pair_positions_2 requires at least as many valid points in the 1st set as in the 2nd set !');
    points1
    points2
    N1
    N2
    N1valid
    N2valid
    stop;
end

% Intialise 'assigned'
assigned = zeros([N1 1]);

maxdistsq = maxdist*maxdist;

% Compute N1xN2 matrix 'dsq12' containing the squared distances of all pairs (P1,P2),
% where P1 is a point from the 1st set ('points1') and P2 a point from the
% 2nd set (points2)
dsq12 = ones([N1 N2])*NaN; % initialise matrix
for i1=1:N1
    P1 = points1(i1,:); x1=P1(1); y1=P1(2);
    if (isfinite(x1) && isfinite(y1))
        for i2=1:N2            
            P2 = points2(i2,:); x2=P2(1); y2=P2(2);
            dx = x2-x1; dy=y2-y1; drsq = dx.*dx + dy.*dy;
            dsq12(i1,i2) = drsq;
        end
    end
end
%dsq12

% Initialise sigma
sigma = ones([1 N1])*NaN;

% Now look iteratively for the smallest distance in the matrix dsq12 to
% pair points that are the closest together
finished = 0;
while finished==0
    % Locate the pair of points (points1(i1),points2(i2)) that has the smallest distance
    [dsqs,rows]=min(dsq12);
    [dsq,i2]=min(dsqs);
    i1=rows(i2);
    % pair points1(i1) and points2(i2)
    if(isfinite(dsq) && dsq<=maxdistsq)
        sigma(i1)=i2;
        % remove both points from consideration by setting the i1-row and
        % the i2-column in the matrix to infinity
        dsq12(i1,:)=ones([1 N2])*Inf;
        dsq12(:,i2)=ones([N1 1])*Inf;
%        dsq
    else
        finished=1;
    end       
end
