% Plot matrix of pair-wise cdf's (cumulative distribution functions) and perform pair-wise
% Kolmogorov-Smirnov tests
% X is a cell array containing the input data for all classes
% class is a cell array of the same size as X, which indicates the class
% for each element of X.
% quantitystring is a string describing the quantity X that is plotted
%
% The function returns among other things the matrix pKS containing the probabilities associated
% to each pair-wise KS test

function [figKS,pKS,ksstat] = pairwise_KStests(X,class,quantitystring)

figKS = figure('Name',[quantitystring,' : cdf and KS tests']);

if isempty(X)
    title(['There are apparently no values for ',quantitystring,'!!']);
    pKS = NaN;
    ksstat = NaN;
    return;
end

% Get the classes
list_of_classes = unique(class);

Nclasses = length(list_of_classes);

warning off;
colors = jet(Nclasses);
ipair = 1;
for i1=1:Nclasses
    % Get the data for class 1
    class1 = list_of_classes{i1};
    indexes1 = find(ismember(class,class1));
    if any(indexes1>length(X))
whos
error('problem 1 in pairwise_KStests!');
    end
    X1 = X(indexes1);

    % Plot the single cdf of class 1
    subplot(Nclasses,Nclasses, (i1-1)*Nclasses+i1 );
    if all(isnan(X1)) % make sure there are valid data
        legend('no data here !');
    else
        [h1, stats1(i1)] = cdfplot(X1);
        set(h1,'Color',colors(i1,:));
        legend([class1]);
        xlabel(quantitystring);
        title(['N=',num2str(length(X1)),' nuclei; median = ',num2str(median(X1)),', mean=',num2str(mean(X1)),' std=',num2str(std(X1))]);
    end

    for  i2=i1+1:Nclasses
        % Get the data for class 2
        class2 = list_of_classes{i2};
        indexes2 = find(ismember(class,class2));
        X2 = X(indexes2);

        % Plot the two cumulative histograms
        subplot(Nclasses,Nclasses, (i1-1)*Nclasses+i2 );
        if all(isnan(X1)) || all(isnan(X2)) % make sure there are valid data
            legend('no data here !');
            pKS(i1,i2) = NaN;
            ksstat(i1,i2) = NaN;
        else
            [h1, stats1] = cdfplot(X1);
            set(h1,'Color',colors(i1,:));
            hold on;
            [h2, stats2] = cdfplot(X2);
            set(h2,'Color',colors(i2,:));
            legend(class1,class2);
            xlabel(quantitystring);

            % Perform the KS test
            alpha = 0.01;
            [HKS(i1,i2),pKS(i1,i2),ksstat(i1,i2)] = kstest2(X1,X2,alpha);

            if 1==0
                if HKS(i1,i2)
                    title(['KS: difference is significant ! (p=',num2str(pKS(i1,i2)),')']);
                else
                    title(['KS: difference not significant (p=',num2str(pKS(i1,i2)),')']);
                end
            else
                title(['KS: prob of equal distr. p=',num2str(pKS(i1,i2))]);
            end
        end
    end
end

if ~exist('pKS','var')
    pKS = NaN;
end
if ~exist('ksstat','var')
    ksstat = NaN;
end