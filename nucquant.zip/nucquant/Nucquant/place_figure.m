% sets the position of the figure on the screen
% .....
function place_figure(fig,Nrows,Ncols,N,monitor)


screensize =     get(0,'ScreenSize');

Sleft = screensize(1);
Sbot = screensize(2);
Swidth = screensize(3);
Sheight = screensize(4);

figwidth = Swidth/Ncols-20;
figheight = Sheight/Nrows-80;

irow = ceil(N/Ncols);
icol = N-(irow-1)*Ncols;

figleft = 10 + (icol-1)*(figwidth+20);
figbot = 10 + (Nrows-irow)*(figheight+80);

if monitor==2
    Nbmonitors =  size(get(0,'MonitorPosition'),1);
    if  Nbmonitors==2
        figleft = figleft + Swidth;
    end
end

rect = [figleft figbot figwidth figheight];

if ishandle(fig)
    set(fig,'Position',rect);
else
    warning('did not reposition figure because fig is not a valid handle in place_figure !');
end

