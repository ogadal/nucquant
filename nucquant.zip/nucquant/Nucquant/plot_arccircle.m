% Plot arc circle of radius r centered on (x,y) and with angles theta from the x-axis spanning
% (theta1, theta2)
function h = plot_arccircle(x,y,r,theta1,theta2,stylestring)

theta = linspace(theta1,theta2);
[xcircle,ycircle] = pol2cart(theta,r);
h = plot(x+xcircle,y+ycircle,stylestring,'LineWidth',2);

return