% Plot circle of radius r centered on (x,y)
function plot_circle(x,y,r,stylestring)

plot_arccircle(x,y,r,0,2*pi,stylestring)


return