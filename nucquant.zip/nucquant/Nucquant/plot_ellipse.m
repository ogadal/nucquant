% Plot axes-aligned ellipse of half axes (Rx,Ry) centered on (x,y)
function plot_ellipse(x,y,Rx,Ry,stylestring)

theta = linspace(0,2*pi);
xcircle = x + Rx*cos(theta);
ycircle = y + Ry*sin(theta);
hold on;
plot(xcircle,ycircle,stylestring);

return