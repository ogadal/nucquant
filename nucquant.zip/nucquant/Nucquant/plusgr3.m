function [nn1,nn2,nn3]=plusgr3(n1,n2,n3)

if n1>=max(n2,n3)
    if n2>=n3
        nn1=1;nn2=2;nn3=3;
    else
        nn1=1;nn2=3;nn3=2;
    end
end

if n2>=max(n1,n3)
    if n1>=n3
        nn1=2;nn2=1;nn3=3;
    else
        nn1=2;nn2=3;nn3=1;
    end
end

if n3>=max(n1,n2)
    if n1>=n2
        nn1=3;nn2=1;nn3=2;
    else
        nn1=3;nn2=2;nn3=1;
    end
end