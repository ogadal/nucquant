function [x,y] = positionvector2xy(positionvector)

global Npix;
global Nvox;

if Nvox~=0, Npix=Nvox; end
    

if length(positionvector)==2*Npix
    aux = reshape(positionvector,Npix,2);
else
    whos
    disp(' problem 1 in positionvector2xy !');
    stop;
end

x = aux(:,1);
y = aux(:,2);