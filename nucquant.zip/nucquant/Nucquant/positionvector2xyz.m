function [x,y,z] = positionvector2xyz(positionvector)

global Nvox;

if length(positionvector)==3*Nvox
    aux = reshape(positionvector,Nvox,3);
else
    Nvox
    length(positionvector)
    error('problem 1 in positionvector2xyz !');
end

x = aux(:,1);
y = aux(:,2);
z = aux(:,3);