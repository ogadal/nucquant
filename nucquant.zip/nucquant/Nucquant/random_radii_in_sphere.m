% For use with nucquant program.
% This function performs a statistical test to determine wether the input
% radial distances of points in 3D (rho) are consistent with a uniform spatial
% distribution within a sphere centered on the origin and of unknown
% radius.
% Output:
% - p is the probability that the null hypothesis (the points obey a
% spatially uniform distribution) is true
% - H is 1 if the null hypothesis is rejected at the confidence level
% alpha, 0 if it is maintained

function [H,p] = random_radii_in_nucleus(rho,alpha)

if length(rho)>1

    [rhomax,imax] = max(rho);

    % theoretical c.d.f of rho for a uniform spatial distribution
    cdf_theo = [rho(:) (rho(:)/rhomax).^3];

    % this removes the maximum radius from the sample because it was used to
    % determine the theoretical cdf.
    rho2 = rho(setdiff(1:length(rho),imax)); 
    
    % Perform a KS test on the sample radii vs. the theoretical
    % distribution
    % TO DO: CHECK the test exactly !
    [H,p] = kstest(rho2,cdf_theo,alpha);

else % only one radius
    H=0;
    p = NaN; % ????
end