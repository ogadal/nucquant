% Rename or delete file if already exists

function rename_or_delete(path,file);

ff = fullfile(path,file);

if exist(ff,'file')
    answer = questdlg(['File ',ff,' already exists. What should I do with it ?'],'Warning !','Replace','Rename','Replace');
    if strcmp(answer,'Replace')
        disp(['Deleting and replacing ',ff,'...']);
        delete(ff);
    else
        [pathstr, name, ext] = fileparts(ff);
        newfilename = [name,'_old',ext];
        dir0 = cd;
        cd(path);
        [newfilename, pathname] = uiputfile('*','Rename file',newfilename);
        ffnew = fullfile(pathname,newfilename);
        disp('Renaming :')
        disp(ff)
        disp(' to :');
        disp([ffnew,'...']);
        movefile(ff,ffnew,'f');
        cd(dir0);
    end
else
%     disp(['File ',ff,' does not seem to exist !']);
end