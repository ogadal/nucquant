%%% for use with thomann.m
%%% Plot histogram and cumulative histograms of spot scores, spot intensity distribution curvature,
%%% spot mean intensities

function fig = score_histograms(s,s_thresh,kappa,Imean)

warning off MATLAB:Axes:NegativeDataInLogAxis

%%% considering only the Nmax spots with the highest scores
Nmax = 100;
if ~issorted(-s)
    error('spots must be sorted in order of decreasing scores first !');
end
Nkeep = min(Nmax,length(s));
s = s(1:Nkeep);
kappa = kappa(1:Nkeep);
Imean = Imean(1:Nkeep);

%%% Plot histogram of spot scores
Nbins = 100;

fig = figure('Name','Spot score histograms');

subplot(2,3,1);
hist(s,Nbins);
xlabel('s=kappa*<I>');
hold on; aux=ylim; plot([s_thresh s_thresh],aux,'r:');
legend(['threshold score=',num2str(s_thresh)]);
ylabel('#');
set(gca,'YLim',[0 20]);
set(gca,'XScale','log');

subplot(2,3,2);
hist(kappa,Nbins);
xlabel('kappa');
ylabel('#');
set(gca,'YLim',[0 20]);
set(gca,'XScale','log');

subplot(2,3,3);
hist(Imean,Nbins);
xlabel('<I>');
ylabel('#');
set(gca,'YLim',[0 20]);
set(gca,'XScale','log');

%%% Cumulative histograms
subplot(2,3,4);
cdfplot(s);
xlabel('s');
hold on; aux=ylim; plot([s_thresh s_thresh],aux,'r:');
set(gca,'XScale','log');

subplot(2,3,5);
cdfplot(kappa);
xlabel('kappa');
set(gca,'XScale','log');

subplot(2,3,6);
cdfplot(Imean);
xlabel('<I>');
set(gca,'XScale','log');
