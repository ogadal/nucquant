% Convert seconds to a string with days, hours, minutes, seconds

function timestring = seconds2timestring(seconds)


sec = rem(seconds,60);
aux = [num2str(sec),'s'];

min = rem(floor(seconds/60),60);

if min>0
    aux = [num2str(min),'min ',aux];

    hours = rem(floor(seconds/3600),24);
    if hours>0
        aux = [num2str(hours),'h ',aux];

        days = floor(seconds/86400);
        if days>0
            aux = [num2str(days),'days ',aux];
        end
    end
end

timestring = aux;