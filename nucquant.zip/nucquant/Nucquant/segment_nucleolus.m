 % Segment the nucleolus and compute its approximate volume and quantiles of its intensity
function  [Ibwnuc, threshnuc, Vnuc_vox, Inucquantiles] = segment_nucleolus(I,dx,dy,dz)

threshnuc = (max(I(:))+min(I(:)))/2;
Ibwnuc = false(size(I));
Ibwnuc = I>threshnuc;


% Keep only the largest connected component
disp('keeping only the largest connected component of the nucleolus..');
[Ibwnp,Vnuc_vox] = largest_connected_component_3D(Ibwnuc);

% Compute quantiles of nucleolus intensity
aux = I(Ibwnuc); % this gives the intensities of the voxels inside the segmented nucleolus
p = [0.025 0.25 0.5 0.75 0.975];
Inucquantiles = quantile(aux,p);

