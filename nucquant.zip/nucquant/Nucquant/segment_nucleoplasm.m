% Segment the nucleoplasm and compute its approximate volume and quantiles of its intensity
function [Ibwnp, thresh, Volnp_vx, Inpquantiles] = segment_nucleoplasm(I,dx,dy,dz,parameters)

% First determine threshold
minI = min(I(:));


switch 4
    case 1
        maxI = max(I(:));
        meanI = mean(I(:));
        medianI = median(I(:));
        %                thresh = minI+(maxI-minI)/3;
        %        thresh   = minI+(meanI-minI)/2;;
        thresh   = minI*1.5;

    case 2  % Otsu thresholding
        [thresh EM] = graythresh(I);

    case 3
        %  compute cumulative histogram
        cumhist = ecdf(I(:));

        % find the grey level corresponding to the mode of the histogram (CHECK THIS)
        Imode1 = I(max(find(cumhist<=0.5)));

        % estimate
        thresh = minI + (Imode1-minI)*1.5;

    case 4 % Using a target volume
        % set radius of ideal spherical nucleus
        switch parameters.nuclear_staining
            case    'Nuclear envelope'
                R = 1.5;
            case 'Nucleoplasm'
                R = 1.0;
            otherwise
                error('this value of parameters.nuclear_staining is invalid !');
        end

        Vnuc_mu3 = 4/3*pi*R^3;% target volume in microns
        Vnuc_vx = Vnuc_mu3/(dx*dy*dz); % target volume in voxels
        [h, bins] = hist(I(:),1000);
        hc = cumsum(h(end:-1:1));
        aux = find(hc>=Vnuc_vx,1,'first');
        if isempty(aux)
            warning('Image is probably smaller than the target volume ! Using trivial threshold  for nucleoplasm segmentation');
            thresh = -Inf;
        else
            thresh = bins(end-aux+1);
        end
end

% Treshold the image
Ibwnp = false(size(I));
Ibwnp = I>thresh;

% If the nucleoplasm is stained, Keep only the largest connected component
switch parameters.nuclear_staining
    case    'Nuclear envelope'
        Volnp_vx = sum(Ibwnp(:));
        % do nothing
    case 'Nucleoplasm'
        [Ibwnp,Volnp_vx] = largest_connected_component_3D(Ibwnp);
    otherwise
        error('this value of parameters.nuclear_staining is invalid !');
end


% % DEBUG
% disp(['sum(Ibwnp) = ',num2str(sum(Ibwnp(:)))]);
% disp(['Vnuc_vx = ',num2str(Vnuc_vx)]);
%
%
%
%
% figure,bar(bins,h),
% hold on; aux=ylim; plot([thresh thresh],aux,'r:');


