
function [fig1d,fig2d,fig3d] = show_1D2D3D(I,xx,yy,zz,imagestring);

global I3d;
global xx_glo;
global yy_glo;
global zz_glo;
global hR_isosurface; % isosurface handle for red channel
global hG_isosurface; % isosurface handle for green channel
global hB_isosurface; % isosurface handle for blue channel
global pR_isosurface; % isosurface patch handle for red channel
global pG_isosurface; % isosurface patch handle for green channel
global pB_isosurface; % isosurface patch handle for blue channel
global swapRG;


fig1d = show_1Dprofile(I,xx,yy,zz,imagestring);

fig2d = show_2Dviews(I,xx,yy,zz,imagestring);

fig3d = show_3Dimage(I,xx,yy,zz,imagestring);