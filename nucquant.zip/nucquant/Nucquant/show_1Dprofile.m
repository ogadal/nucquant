% show_1Dprofile.m
% Shows intensity profiles through the 3D grey-level or RGB image 'I'

function fig1d = show_1Dprofile(I,xx,yy,zz,imagestring);

global I3d;
global xx_glo;
global yy_glo;
global zz_glo;
global hR_isosurface; % isosurface handle for red channel
global hG_isosurface; % isosurface handle for green channel
global hB_isosurface; % isosurface handle for blue channel
global pR_isosurface; % isosurface patch handle for red channel
global pG_isosurface; % isosurface patch handle for green channel
global pB_isosurface; % isosurface patch handle for blue channel
global swapRG;

if length(xx)~=size(I,1) || length(yy)~=size(I,2) || length(zz)~=size(I,3)
    size(I)
    whos xx yy zz
    error('show_3Dimage: Axes lengths not compatible with image size !');
end

xx_glo = xx;
yy_glo = yy;
zz_glo = zz;

Nx = length(xx);
Ny = length(yy);
Nz = length(zz);

% Indices of the most central voxel
i0 = round((Nx-1)/2 + 1);
j0 = round((Ny-1)/2 + 1);
k0 = round((Nz-1)/2 + 1);

% Plot intensity profiles along the 3 axes through the origin
if ndims(I)==4
    Nchannels = size(I,4);
else
    Nchannels = 1;
end

if Nchannels>1
    aux = I(:,:,:,3); if max(aux(:))==0, Nchannels = 2; end;
    aux = I(:,:,:,2); if max(aux(:))==0, Nchannels = 1; end;
end


fig1d = figure('Name',['1D profile through ',imagestring],'WindowStyle','normal');
subplot(2,2,1);
plot(xx,squeeze(I(:,j0,k0,1:Nchannels)));
xlabel('x (mu)');
axis tight;
title([imagestring,' profile at y=',num2str(yy(j0)),', z=',num2str(zz(k0))]);
ylabel('I(x)');
subplot(2,2,2);
plot(yy,squeeze(I(i0,:,k0,1:Nchannels)));
xlabel('x (mu)');
axis tight;
title([imagestring,' profile at x=',num2str(xx(i0)),', z=',num2str(zz(k0))]);
ylabel('I(y)');
subplot(2,2,3);
plot(zz,squeeze(I(i0,j0,:,1:Nchannels)));
xlabel('z (mu)');
axis tight;
title([imagestring,' profile at x=',num2str(xx(i0)),', y=',num2str(yy(j0))]);
ylabel('I(z)');
legend;

