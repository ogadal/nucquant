% show_3Dsurfaces.m
% Shows surface rendering of the 3D grey-level or RGB image 'I'

function fig3d = show_3Dsurfaces(I,xx,yy,zz,imagestring);

global I3d;
global xx_glo;
global yy_glo;
global zz_glo;
global hR_isosurface; % isosurface handle for Ired channel
global hG_isosurface; % isosurface handle for green channel
global hB_isosurface; % isosurface handle for blue channel
global pR_isosurface; % isosurface patch handle for red channel
global pG_isosurface; % isosurface patch handle for green channel
global pB_isosurface; % isosurface patch handle for blue channel
global swapRG;

xx_glo = xx;
yy_glo = yy;
zz_glo = zz;

limx = [xx(1) xx(end)];
limy = [yy(1) yy(end)];
limz = [zz(1) zz(end)];

Nx = length(xx);
Ny = length(yy);
Nz = length(zz);

fig3d = figure('Toolbar','figure','Name',['3D view of ',imagestring]);

if islogical(I),
    I = double(I);
end

if ndims(I)==4
    Nchannels = size(I,4);
    I3d = permute(I,[2 1 3 4]);
else
    Nchannels = 1;
    I3d = permute(I,[2 1 3]);
end


switch Nchannels
    case {2,3}
        Ired = I3d(:,:,:,1);
        Igreen = I3d(:,:,:,2);
    case 3
        Iblue = I3d(:,:,:,3);
    case 1
        Igreen = I3d;
    otherwise
        error('Nchannels must be 1, 2 or 3!');
end

% Red isosurface
if exist('Ired','var')
    Rmin = min(Ired(:));  Rmax = max(Ired(:));
    isolevel_R = Rmin+(Rmax-Rmin)/2;
    if Rmax>Rmin
        pR_isosurface = patch(isosurface(xx,yy,zz,Ired,isolevel_R));
        isonormals(xx,yy,zz,Ired,pR_isosurface);
        set(pR_isosurface,'FaceColor','red','EdgeColor','none');
    else
        disp('Red channel not shown because all voxels have the same intensity');
    end
else
    isolevel_R = NaN;
end

% Green isosurface
if exist('Igreen','var')
    Gmin = min(Igreen(:));  Gmax = max(Igreen(:));   isolevel_G = Gmin+(Gmax-Gmin)/2;
    if Gmax>Gmin
        pG_isosurface = patch(isosurface(xx,yy,zz,Igreen,isolevel_G));
        isonormals(xx,yy,zz,Igreen,pG_isosurface);
        set(pG_isosurface,'FaceColor','green','EdgeColor','none');
    else
        disp('Green channel not shown because all voxels have the same intensity');
    end
else
    isolevel_G = NaN;
end

% Set axes properties etc.
daspect([1 1 1]);
alpha(0.25);
view(3);
limx = [xx_glo(1) xx_glo(end)];
limy = [yy_glo(1) yy_glo(end)];
limz = [zz_glo(1) zz_glo(end)];
axis([limx limy limz]);
camlight
lighting gouraud;
xlabel('x (mu)')
ylabel('y (mu)')
zlabel('z (mu)')
title(['Isosurfaces of ',imagestring,' at R=',num2str(isolevel_R),' G=',num2str(isolevel_G)]);
grid on;
%
if exist('Ired','var') && Rmax>Rmin
    hR_isosurface = uicontrol('style','slider','String','Red','position',...
        [5 5 20 500],'Min',Rmin,'Max',Rmax,'Value',isolevel_R,'Callback','update_RGB_isosurfaces');
end
if exist('Igreen','var') &&   Gmax>Gmin
    hG_isosurface = uicontrol('style','slider','String','Green','position',...
        [30 5 20 500],'Min',Gmin,'Max',Gmax,'Value',isolevel_G,'Callback','update_RGB_isosurfaces');
end



