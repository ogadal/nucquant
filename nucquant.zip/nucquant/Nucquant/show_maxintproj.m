% show a maximum intensity projection of the input 3D image I
%
% xx, yy, and zz are vectors defining the locations of the centers of the
% pixels
% plane can be 'xy', 'xz' or 'yz' and specifies the projection plane

function show_maxintproj(I,xx,yy,zz,plane,imagestring)

global swapRG;

%  scale the image to the range [0 65535] to minimize rounding errors in
%  the display (TODO: see if this does not slow down things excessively !!);
% TODO: see if one should use 'im2uint16' instead ???
% TODO: do this channel by channel !!!
if 1==1
    aux1 = max(I(:));
    aux2 = min(I(:));
    aux3 = double(intmax('uint16'));
    aux4 = aux3/aux1;
    I = (I - aux2)*aux4;
end

I = uint16(I);   % Seems to be necessary for correct scaling and display of different image types

if isempty(xx)
    xx = 1:size(I,1);
end
if isempty(yy)
    yy = 1:size(I,2);
end
if isempty(zz)
    zz = 1:size(I,3);
end

if length(xx)~=size(I,1) || length(yy)~=size(I,2) || length(zz)~=size(I,3)
    error('show_maxintproj: Axes lengths not compatible with image size !');
end

% If required, swap first two color channels
if exist('swapRG','var') && ~isempty(swapRG) && swapRG && (ndims(I)==4)   %&& (size(I,4)==3)
    %     disp('swapping in show_maxintproj!');
    aux = I(:,:,:,1);
    I(:,:,:,1) = I(:,:,:,2);
    I(:,:,:,2) = aux;
end


% set font size for labels
fs = 8;

if 1==0
    dx = (xx(end)-xx(1))/(length(xx)-1);
    dy = (yy(end)-yy(1))/(length(yy)-1);
    dz = (zz(end)-zz(1))/(length(zz)-1);

    limx = [xx(1)-dx/2 xx(end)+dx/2]
    limy = [yy(1)-dy/2 yy(end)+dy/2];
    limz = [zz(1)-dz/2 zz(end)+dz/2]
else
    limx = [xx(1) xx(end)];
    limy = [yy(1) yy(end)];
    limz = [zz(1) zz(end)];
end

% tolerance for stretchlim
if 1==0
    tol = [0.01 0.99];
else
    tol = [0 1];
end

switch plane
    case 'xy'
        aux = squeeze(max(I,[],3));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux2 = stretchlim(aux,tol);
        aux = imadjust(aux,aux2,[]);
        imagesc(limx,limy,aux); %xlim(limx); ylim(limy); hold;
        hx = xlabel('x (mu)');
        hy = ylabel('y (mu)');
        ht = title([imagestring,' (max. int. proj.)']);

    case 'xz'
        aux = squeeze(max(I,[],2));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux = imadjust(aux,stretchlim(aux,tol),[]);
        imagesc(limx,limz,aux); %xlim(limx); ylim(limz); hold;
        hx = xlabel('x (mu)');
        hy = ylabel('z (mu)');
        ht = title([imagestring,' (max. int. proj.)']);

    case 'yz'   % CHECK CODE FOR THIS CASE !!!!!
        aux = squeeze(max(I,[],1));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux = imadjust(aux,stretchlim(aux,tol),[]);
        imagesc(limx,limz,aux); %xlim(limx); ylim(limz); hold;
        hx = xlabel('y (mu)');
        hy = ylabel('z (mu)');
        ht = title([imagestring,' (max. int. proj.)']);

    otherwise
        error('this value of plane is not allowed in show_maxintproj.m !');
end

set([hx hy ht],'FontSize',fs);
set(gca,'FontSize',fs);
axis xy;
axis image;
axis tight;

if ndims(aux)==2,
    colormap(gray);
end

hold on;

%%%%%%%%%%
% generalization of imagesc2 to images that may have 2 channels (not just 1
% or 3)
function imagesc2(limx,limy,I);
if (ndims(I)==3) && (size(I,3)==2)
    I(:,:,3) = zeros(size(I(:,:,1)));
end
aux = I(:,:,3);
imagesc(limx,limy,I);

