%% Show radial projection of NPC and gene using the fitted sphere
function fig = show_radial_projections(out);
xNPC = out.xNPC;
yNPC = out.yNPC;
zNPC = out.zNPC;
xn = out.xn;
yn = out.yn;
zn = out.zn;
if isfield(out,'Rfs')
    Rfs = out.Rfs;
end
xbNPC = out.xbNPC;
ybNPC = out.ybNPC;
zbNPC = out.zbNPC;
rhobNPC = out.rhobNPC;
thetabNPC = out.thetabNPC;
phibNPC = out.phibNPC;
rhoNPC = out.rhoNPC;
thetaNPC = out.thetaNPC;
phiNPC = out.phiNPC;
fig = figure('Name','Radial projection','WindowStyle','normal');
place_figure(fig,2,2,4,2);
[dxp,dyp]=pol2cart(thetaNPC,rhoNPC);
if isfield(out,'Rfs')
    plot(dxp(rhoNPC>Rfs),dyp(rhoNPC>Rfs),'bo','MarkerFaceColor','b');
    plot(dxp(rhoNPC<=Rfs),dyp(rhoNPC<=Rfs),'ro','MarkerFaceColor','r');
else
    plot(dxp,dyp,'ro','MarkerFaceColor','r');
end
hold on;
axis equal;
title('Radial projection of NPC positions');
xlabel('x');
ylabel('y');
thetas = 0:0.01:2*pi;
if isfield(out,'Rfs')
    plot_circle(0,0,Rfs,'k:');
elseif isfield(out,'Rxfe')
    plot_ellipse(0,0,out.Rxfe,out.Ryfe,'k:');
else
    disp('PROBLEM!');
end
for ii=1:length(xNPC),text(dxp(ii),dyp(ii),['#',num2str(ii)]);end
[dxp,dyp]=pol2cart(thetabNPC,rhobNPC);
plot(dxp,dyp,'bo','MarkerFaceColor','g');

end