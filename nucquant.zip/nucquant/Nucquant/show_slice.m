% show a slice of the input 3D image I
%
% xx, yy, and zz are vectors defining the locations of the centers of the
% pixels
% i0 is the index of the slice
% (i.e. i0 for a 'yz' cut, j0 for a 'xz' cut, and k0 for a 'xy' cut)
% plane can be 'xy', 'xz' or 'yz' and specifies the axes of the cut


function show_slice(I,xx,yy,zz,i0,plane,imagestring)

global swapRG;



% If required, swap first two color channels
if ~isempty(swapRG) && swapRG && ndims(I)==4 && size(I,4)>1
    aux = I(:,:,:,1);
    I(:,:,:,1) = I(:,:,:,2);
    I(:,:,:,2) = aux;
end

% set font size for labels
fs = 6;


if 1==0
    dx = (xx(end)-xx(1))/(length(xx)-1);
    dy = (yy(end)-yy(1))/(length(yy)-1);
    dz = (zz(end)-zz(1))/(length(zz)-1);

    limx = [xx(1)-dx/2 xx(end)+dx/2]
    limy = [yy(1)-dy/2 yy(end)+dy/2];
    limz = [zz(1)-dz/2 zz(end)+dz/2]
else
    limx = [xx(1) xx(end)];
    limy = [yy(1) yy(end)];
    limz = [zz(1) zz(end)];
end

hold on;

switch plane
    case 'xy'
        k0 = i0;
        aux = squeeze(I(:,:,k0,:));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux = uint16(aux);
        aux = imadjust(aux,stretchlim(aux,[0 1]),[]);
        imagesc(limx,limy,aux);
        hx =  xlabel('x (mu)');
        hy = ylabel('y (mu)');
        ht = title([imagestring,' (z=',num2str(zz(k0)),' mu)']);


    case 'xz'
        j0 = i0;
        aux = squeeze(I(:,j0,:,:));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux = uint16(aux);
        aux = imadjust(aux,stretchlim(aux,[0 1]),[]);
        imagesc(limx,limz,aux);
        hx =  xlabel('x (mu)');
        hy =  ylabel('z (mu)');
        ht =  title([imagestring,' (y=',num2str(yy(j0)),' mu)']);


    case 'yz'   % CHECK CODE FOR THIS CASE !!!!!
        aux = squeeze(I(i0,:,:,:));
        aux = permute(aux,[2 1 3]);
        aux = twochannels2rgb(aux);
        aux = uint16(aux);
        aux = imadjust(aux,stretchlim(aux,[0 1]),[]);
        imagesc(limy,limz,aux);
        hx = xlabel('y (mu)');
        hy = ylabel('z (mu)');

    otherwise
        error('this value of plane is not allowed in show_slice.m !');

end

set([hx hy ht],'FontSize',fs);
set(gca,'FontSize',fs);
axis xy;
axis image;

if ndims(aux)==2,
    colormap(gray);
end

hold on;