%% Show spot locations on 2 or 4 panel image figure
function show_spots(figure_handle,xspot,yspot,zspot,Npanels,color,label)

Nspots = length(xspot);


nrows = Npanels/2;

ms = 10;

%% Show spot locations image figure,
figure(figure_handle);
subplot(nrows,2,1); hold on;
plot(xspot,yspot,'x','Color',color,'MarkerSize',ms);
for i=1:Nspots
    str = [' #',num2str(i)];
    if Nspots>1
        labelstr = [' ',label,str];
    else
        labelstr = [' ',label];
    end
    text(xspot(i),yspot(i),labelstr,'Color',color);
end
subplot(nrows,2,2); hold on;
plot(xspot,zspot,'x','Color',color,'MarkerSize',ms);
for i=1:Nspots
    str = [' #',num2str(i)];
    if Nspots>1
        labelstr = [' ',label,str];
    else
        labelstr = [' ',label];
    end
    text(xspot(i),zspot(i),labelstr,'Color',color);
end

if nrows>1
    subplot(nrows,2,3); hold on;
    plot(xspot,yspot,'x','Color',color,'MarkerSize',ms);
    for i=1:Nspots
        str = [' #',num2str(i)];
        if Nspots>1
            labelstr = [' ',label,str];
        else
            labelstr = [' ',label];
        end
        text(xspot(i),yspot(i),labelstr,'Color',color);
    end
    subplot(nrows,2,4); hold on;
    plot(xspot,zspot,'x','Color',color,'MarkerSize',ms);
    for i=1:Nspots
        str = [' #',num2str(i)];
        if Nspots>1
            labelstr = [' ',label,str];
        else
            labelstr = [' ',label];
        end
        text(xspot(i),zspot(i),labelstr,'Color',color);
    end
end