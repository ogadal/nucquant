% compute the sigmas of the Thomann Gaussian approximation of the PSF
% cf. Thomann et al. , J. of Microscopy 208, Oct. 2002, pp. 49-64


% lambda = emission wavelength
% NA = numerical aperture of the objective lens
% n = refractive index of the sample medium

function [sigma_xy,sigma_z] = sigma_PSF_thomann(lambda,NA,n)

sigma_xy = 0.21 * lambda / NA;
sigma_z = 0.66 * lambda * n / (NA*NA);

