
%% Compute spottiness score as in the Thomann et al. paper

function [s,kappa,Imean,ilocmax, jlocmax, klocmax, xlocmax, ylocmax, zlocmax] = spottiness(ilocmax, jlocmax, klocmax,Ismoothed,sigma_xy,sigma_z,dx,dy,dz,xx,yy,zz)
Nlocmax = length(ilocmax);
%%% Compute the score (curvature*mean intensity) of each local maximum
if Nlocmax>0
    Lx = 3*sigma_xy/dx;
    Ly = 3*sigma_xy/dy;
    Lz = 3*sigma_z/dz;
    clear kappa Imean s;
    kappa = nan(1,Nlocmax); Imean = nan(1,Nlocmax); s = nan(1,Nlocmax); % preallocation for speed
    for i=1:Nlocmax
        kappa(i) = curvature_thomann(Ismoothed,ilocmax(i),jlocmax(i),klocmax(i),dx,dy,dz); % intensity curvature
        Imean(i) = mean_intensity(Ismoothed,ilocmax(i),jlocmax(i),klocmax(i),Lx,Ly,Lz); % mean intensity in local cube centered on pixel
        s(i) = kappa(i)*Imean(i); % compute the score
    end
    %%% Sort the local maxima in order of decreasing scores
    [s,i] = sort(s,'descend');
    [ilocmax, jlocmax, klocmax] = deal(ilocmax(i), jlocmax(i), klocmax(i));
    [xlocmax ylocmax zlocmax] = ijk2xyz(ilocmax,jlocmax,klocmax,xx,yy,zz);
    kappa = kappa(i);
    Imean = Imean(i);
else
    [s,kappa,Imean,ilocmax, jlocmax, klocmax, xlocmax, ylocmax, zlocmax] = deal([],[],[],[],[],[],[],[],[]);
end
end
