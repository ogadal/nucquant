% Estimate the intrinsic intensity of a diffraction limited spot

function  Aspot_intr = subdiffraction_spot_intensity( xspot, yspot, zspot, I, xx, yy, zz, dx, dy, dz, sigma_xy, sigma_z )

% First define a small neighborhood around the spot centroid that is a
% little larger than the spot (so as to be able to estimate the background)

di = round(2*sigma_xy/dx); dj=di; dk = round(2*sigma_z/dz);
[i, j, k] = xyz2ijk(xspot,yspot,zspot,xx,yy,zz);

imin = max(1,i-di);
jmin = max(1,j-dj);
kmin = max(1,k-dk);
imax = min(size(I,1),i+di);
jmax = min(size(I,2),j+dj);
kmax = min(size(I,3),k+dk);

Iloc = I(imin:imax, jmin:jmax, kmin:kmax);
Iloc = Iloc(:);

% Now estimate the background

background = min(Iloc); % IMPROVE LATER ?????

% Compute the total intensity of the PSF approximation over the same window
% TO DO LATER: THIS SHOULD BE PRE-COMPUTED (analytically ? ) TO SPEED
% THINGS UP !!!

Itot_PSF = gaussian_kernel(sigma_xy/dx,sigma_z/dz,'peak');

% Compute an estimate of the intrinsic spot intensity 

Aspot_intr = sum(Iloc - background)/sum(Itot_PSF(:)); 

