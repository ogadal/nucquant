%% Subpixelic localization of spot positions in 2D
%%% - (ispot,jspot) = indices of the predetected pixels
%%% - (xspot_rough,yspot_rough) = rough coordinates of the predetected voxels (typically the centers of the pixels)
%%% - Aspot_rough = rough value of the amplitude of the spot from the predetection
%%% - I = 2D image
%%% - sigma_xy = standard deviations of the gaussian approximating the PSF
%%% - (dx,dy) = size of a pixel
%%% - (xx,yy) = axes
%%% - method =  a string defining the type of localization method: 'intensity-weigted', 'model fitting', or 'voxelic'
%%% - centroid_threshold_percentage = when using the intensity weighting
%%% this number defines the threshold

function [xspot, yspot, Aspot_intr, background] = subpixelic_2D_spot_localization(ispot,jspot,xspot_rough,yspot_rough,Aspot_rough,I,sigma_xy,dx,dy,xx,yy,method,centroid_threshold_percentage)

global Ngmm;
global Nvox;
global sigma_xy2;

nbspot = length(ispot);

if nbspot == 0
    [xspot, yspot, Aspot_intr, background] = deal([],[],[],[]);
end

%% Refine the position and intensity of the spot(s)
switch method

    case 'intensity-weighted'      %%% Compute subpixel positions using intensity weighted averaging
        disp('computing subpixel spot position using intensity averaging...');
        di = round(2*sigma_xy/dx); dj=di; 
        xspot = NaN(1,nbspot); yspot = xspot; 
        background = min(I(:)); % IMPROVE THIS ??
        for i = 1:nbspot
            [xspot(i),yspot(i), Isum(i), Imin(i)] = intensity_centroid_2D(ispot(i),jspot(i),I,di,dj,xx,yy,centroid_threshold_percentage/100);
            %             Aspot_intr(i) = spot_intensity(I,ispot(i),jspot(i),kspot(i));
            % Compute intrinsic spot intensity
            if 1==0
                Aspot_intr(i) = Aspot_rough(i); % IMPROVE THIS LATER
            else
                Aspot_intr(i) = subdiffraction_spot_intensity( xspot(i), yspot(i), zspot(i), I, xx, yy, zz, dx, dy, dz, sigma_xy, sigma_z );
            end
        end
        %         disp(['(xspot-xspot_rough)/dx=',num2str((xspot-xspot_rough)/dx)]);

    case 'model fitting'       %%% Compute subpixel position using a global mixture model fitting
        disp('computing subpixel spot position using global mixture model fitting...');
        Ngmm = nbspot;
        [xspot,yspot,zspot,Aspot_intr,background] = fit_2Dgmm_model(I,xx,yy,xspot_rough,yspot_rough,Aspot_rough,0,'1-step');
        % TODO: use an initial guess of the background rather than zero !!!

    case 'single particle fit'  %%% Compute subpixel positions by fitting a single particle model to each spot
        disp('computing subpixel spot position by fitting a model to each spot sequentially...');

        for is = 1:nbspot
            % Define a small image neighborhood around the initialisation for the single particle fit
            [Iloc, xxloc, yyloc] = local_2Dimage(I,xx,yy,xspot_rough(is),yspot_rough(is),sigma_xy);
            Nvox = numel(Iloc);

            Ngmm = 1;
            [xspot(is),yspot(is),Aspot_intr(is),background(is)] = fit_2Dgmm_model(Iloc,xxloc,yyloc,xspot_rough(is),yspot_rough(is),Aspot_rough(is),0,'1-step');
        end
        % TODO: use an initial guess of the background rather than zero !!!

    case 'voxelic'   %%% do not refine position
        xspot = xspot_rough;
        yspot = yspot_rough;
        Aspot_intr = spot_intensity(I,ispot,jspot);
        background = min(I(:)); % IMPROVE THIS ??

    otherwise
        error(['method=',method,' is not allowed !']);
end
