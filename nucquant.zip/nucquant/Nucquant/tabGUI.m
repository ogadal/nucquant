function varargout = tabGUI(varargin)
% TABGUI M-file for tabGUI.fig
%      TABGUI, by itself, creates a new TABGUI or raises the existing
%      singleton*.
%
%      H = TABGUI returns the handle to a new TABGUI or the handle to
%      the existing singleton*.
%
%      TABGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TABGUI.M with the given input arguments.
%
%      TABGUI('Property','Value',...) creates a new TABGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tabGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tabGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tabGUI

% Last Modified by GUIDE v2.5 31-May-2007 18:02:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tabGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @tabGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% function that is called when the GUI is created
function tabGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tabGUI (see VARARGIN)

% Choose default command line output for tabGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tabGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

hGui = getappdata(0,'hGui');                                                                        % Gets the data vars from the GUI Called IHM
NbrOfEffectiveCells = getappdata(hGui, 'NbrOfEffectiveCells');                                      % Number of effective celles detected during the detection part
NbrOfColumns = getappdata(hGui,'WidhtForCrops');                                                    % Gets the number of columns per pages
NbrOfLines = getappdata(hGui,'HeightForCrops');                                                     % Gets the number of lines per pages


if mod(NbrOfEffectiveCells,NbrOfColumns*NbrOfLines) == 0
    NbrOfPages = floor(NbrOfEffectiveCells/(NbrOfColumns*NbrOfLines));                              % Number of pages to display if the number of cells per page is a multiple of the total number of cells
else
    NbrOfPages = floor(NbrOfEffectiveCells/(NbrOfColumns*NbrOfLines))+1;                            % Number of pages to display otherwhise
end

setappdata(0,'hGuiTab',gcf);                                                                        % creates a new application data set
hGuiTab = getappdata(0,'hGuiTab');                                                                  % and creates a shortcut to its handle
setappdata(hGuiTab,'NbrOfPages',NbrOfPages);                                                        % adds the number of pages to be shown
setappdata(hGuiTab,'NbrOfLines',NbrOfLines);                                                        % also adds the number of lines per page
setappdata(hGuiTab,'NbrOfColumns',NbrOfColumns);                                                    % and the number of cells per line

for i=1:20                                                                                          % as we have a maximum of 20 pages, we have to hide the ones that will not be used
    set(handles.(strcat('TAB',num2str(i),'_PB')),'Visible','off');                                  % so begin by hiding all of them
end

% Now we will determinate the positioning of each button in the GUI in
% order to make the user believe (s)he's using tabs

SetOfPos1 = get(handles.axes3,'Position');                                                          % here is the position of the axes in the panel (top left point coordinates + width&height)
SetOfPos2 = get(handles.uipanel1,'Position');                                                       % and here is the UIPanel position (top left point coordinates + width&height)

NbrOfButtons = NbrOfPages;                                                                          % this var isn't really usefull, but keep it anyway ;)
X = SetOfPos2(1);                                                                                   % here we get the position of the top left point of the first button
Y = SetOfPos2(2)+SetOfPos2(4);
Width = SetOfPos2(3)/NbrOfButtons;                                                                  % now let's calculate the width of each button (the more page we have, the thiner the buttons will be)
Height = 2;                                                                                         % and we fix the height to 2 (correct height to see the tab buttons)

for i=1:getappdata(hGuiTab,'NbrOfPages');                                                           % Now we will format each button we need
    if i==1                                                                                         % as the application opens on the first page, the first button has to be the valide one
        set(handles.(strcat('TAB',num2str(i),'_PB')),'Value',0,'Visible','on','string',['Cell ',num2str((i-1)*NbrOfLines*NbrOfColumns+1),'-',num2str(i*NbrOfLines*NbrOfColumns)],'Position',[X+(i-1)*Width,Y,Width,Height]);                % so we set its value, its visibility, its name and its position
    elseif i==NbrOfPages
        set(handles.(strcat('TAB',num2str(i),'_PB')),'Value',0,'Visible','on','string',['Cell ',num2str((i-1)*NbrOfLines*NbrOfColumns+1),'-',num2str(NbrOfEffectiveCells)],'Position',[X+(i-1)*Width,Y,Width,Height]);                      % every other usefull buttons will be visible but invalide
    else
        set(handles.(strcat('TAB',num2str(i),'_PB')),'Value',0,'Visible','on','string',['Cell ',num2str((i-1)*NbrOfLines*NbrOfColumns+1),'-',num2str(i*NbrOfLines*NbrOfColumns)],'Position',[X+(i-1)*Width,Y,Width,Height]);
    end
end

subplot(1,1,1);                                                                                     % here is the solution to erase anything on the figure
DisplayCrops(1,handles);                                                                            % and now we are sure nothing is present on the page, we can call the DisplayCrops function (see this function for more details)
set(gcf,'Name','ROI details');                                                                      % names the GUI

%% Output function.... not used here, so no code needed
function varargout = tabGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%% function that loads the ROIs in the several tabs
function DisplayCrops(PageNumber,handles)

hGui = getappdata(0, 'hGui');                                                                       % gets the application data set from the IHM GUI
hGuiTab = getappdata(0,'hGuiTab');                                                                  % and gets the current data set too

disp(strcat('Loading Page:',num2str(PageNumber),'/',num2str(getappdata(hGuiTab,'NbrOfPages')),'...'));  % display what's appening... always usefull

for i=1:getappdata(hGuiTab,'NbrOfPages');                                                           % looks every button in order to modify their status
    if i==PageNumber                                                                                % the button corresponding to the page we're looking has to be valide (up)
        set(handles.(strcat('TAB',num2str(i),'_PB')),'Value',0);                                    % so put it up
    else
        set(handles.(strcat('TAB',num2str(i),'_PB')),'Value',1);                                    % and get all the other down
    end
end

subplot(1,1,1);                                                                                     % now let's refresh the figure and begin by erasing the axe

MosOfCrops = getappdata(hGui,'Mosaic_Of_Crops');                                                    % now get the mosaic of crops
BoundariesOfCrop = getappdata(hGui,'BoundariesOfCrop');                                             % the boundaries (allways displayed on screen)
CentroidsOfCrop = getappdata(hGui,'CentroidsOfCrop');                                               % the centroids
NbrOfCropsPerPage = getappdata(hGuiTab,'NbrOfLines')*getappdata(hGuiTab,'NbrOfColumns');            % and calculate the number of ROIs per page
TagTable = getappdata(hGui,'CropTag');

for i=1:NbrOfCropsPerPage;                                                                          % Now we're going to load ROIs in the axe
    Lab = (PageNumber-1)*NbrOfCropsPerPage+i;                                                       % We will use a counter to know how many crops we have already loaded. Lab is this counter
    if (Lab > getappdata(hGui,'NbrOfEffectiveCells'))                                               % if Lab is greater than the number of ROIs per page, there is a problem
        disp('Trying to reach a ROIs that is not on the page');                                     % so say it to the user
        return                                                                                      % and stop the program, otherwhise it could crash down
    else                                                                                            % if everything's ok
        subplot(getappdata(hGuiTab,'NbrOfLines'),getappdata(hGuiTab,'NbrOfColumns'),i);             % prepare as many ploting cells as needed
        Ima = MosOfCrops{Lab};                                                                      % and get the correct ROI to display

        imagesc(Ima);                                                                               % display it
        hold on;
            b = BoundariesOfCrop{Lab};                                                              % and show also boundaries
            if TagTable{Lab}(3) == 1
                plot(b(:,2),b(:,1),'red','Linewidth',getappdata(hGui,'BThickness'));
            elseif TagTable{Lab}(2) == 1
                plot(b(:,2),b(:,1),'blue','Linewidth',getappdata(hGui,'BThickness'));
            else
                plot(b(:,2),b(:,1),'white','Linewidth',getappdata(hGui,'BThickness'));
            end
            text(CentroidsOfCrop(Lab,2),CentroidsOfCrop(Lab,1),['\color]{yellow}',num2str(Lab)]);   % and centroids
        hold off;
        axis off;                                                                                   % hide axis
    end
end

setappdata(hGuiTab,'CurrentPage',PageNumber);                                                       % and add the current page shown to the application data set



%% Here are the function associated to the 20 buttons of the Tab GUI
function TAB1_PB_Callback(hObject, eventdata, handles)
DisplayCrops(1,handles);                                                                            % Display the page n�1

function TAB2_PB_Callback(hObject, eventdata, handles)
DisplayCrops(2,handles);                                                                            % Display the page n�2

function TAB3_PB_Callback(hObject, eventdata, handles)
DisplayCrops(3,handles);                                                                            % Display the page n�3

function TAB4_PB_Callback(hObject, eventdata, handles)
DisplayCrops(4,handles);                                                                            % Display the page n�4

function TAB5_PB_Callback(hObject, eventdata, handles)
DisplayCrops(5,handles);                                                                            % Display the page n�5

function TAB6_PB_Callback(hObject, eventdata, handles)
DisplayCrops(6,handles);                                                                            % Display the page n�6

function TAB7_PB_Callback(hObject, eventdata, handles)
DisplayCrops(7,handles);                                                                            % Display the page n�7

function TAB8_PB_Callback(hObject, eventdata, handles)
DisplayCrops(8,handles);                                                                            % Display the page n�8

function TAB9_PB_Callback(hObject, eventdata, handles)
DisplayCrops(9,handles);                                                                            % Display the page n�9

function TAB10_PB_Callback(hObject, eventdata, handles)
DisplayCrops(10,handles);                                                                           % Display the page n�10

function TAB11_PB_Callback(hObject, eventdata, handles)
DisplayCrops(11,handles);                                                                           % Display the page n�11

function TAB12_PB_Callback(hObject, eventdata, handles)
DisplayCrops(12,handles);                                                                           % Display the page n�12

function TAB13_PB_Callback(hObject, eventdata, handles)
DisplayCrops(13,handles);                                                                           % Display the page n�13

function TAB14_PB_Callback(hObject, eventdata, handles)
DisplayCrops(14,handles);                                                                           % Display the page n�14

function TAB15_PB_Callback(hObject, eventdata, handles)
DisplayCrops(15,handles);                                                                           % Display the page n�15

function TAB16_PB_Callback(hObject, eventdata, handles)
DisplayCrops(16,handles);                                                                           % Display the page n�16

function TAB17_PB_Callback(hObject, eventdata, handles)
DisplayCrops(17,handles);                                                                           % Display the page n�17

function TAB18_PB_Callback(hObject, eventdata, handles)
DisplayCrops(18,handles);                                                                           % Display the page n�18

function TAB19_PB_Callback(hObject, eventdata, handles)
DisplayCrops(19,handles);                                                                           % Display the page n�19

function TAB20_PB_Callback(hObject, eventdata, handles)
DisplayCrops(20,handles);                                                                           % Display the page n�20


%% this is the function that controls the close request function
function figure1_CloseRequestFcn(hObject, eventdata, handles)

delete(hObject);                                                                                    % this simply and affectively destroy the window
hGui = getappdata(0,'hGui');                                                                        % gets the tab GUI data set
if isappdata(hGui,'tabGUIFlag')                                                                     % and if the data are not destroyed yet
    rmappdata(hGui,'tabGUIFlag');                                                                   % just do it!!!
end

%% this is the function that listens to the window messages (left and right arrows)
function figure1_KeyPressFcn(hObject, eventdata, handles)

hGuiTab = getappdata(0,'hGuiTab');                                                                  % gets the application data set

PageNbr = getappdata(hGuiTab,'CurrentPage');                                                        % gets the current page number
NbrOfPages = getappdata(hGuiTab,'NbrOfPages');                                                      % and also gets the total number of pages

if get(gcf,'CurrentCharacter') == 28                                                                % this listens to the window message "Right Arrow" (ASCII code for right arrow is '28')
    if PageNbr == 1                                                                                 % if we're looking at the first page and press the right arrow, we simply loop to the last page
        DisplayCrops(NbrOfPages,handles);                                                           % so load the last page
        setappdata(hGuiTab,'CurrentPage',NbrOfPages);                                               % and refresh the current page number
    else
        DisplayCrops(PageNbr-1,handles);                                                            % else, just go to the previous page by loading it
        setappdata(hGuiTab,'CurrentPage',PageNbr-1);                                                % and don't forget to refresh the current page number
    end
elseif get(gcf,'CurrentCharacter') == 29                                                            % now if the window message is "Left Arrow" (ASCII code for left arrow is '29')
    if PageNbr == NbrOfPages                                                                        % if we're looking at the last page, we loop to the first page
        DisplayCrops(1,handles);                                                                    % so display it thanks to the DisplayCrops function
        setappdata(hGuiTab,'CurrentPage',1);                                                        % and refresh the current page number
    else
        DisplayCrops(PageNbr+1,handles);                                                            % otherwise, go to the next page by loading it
        setappdata(hGuiTab,'CurrentPage',PageNbr+1);                                                % and refresh the current page number
    end
end