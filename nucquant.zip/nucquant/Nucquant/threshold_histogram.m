% automatic thresholding of a list of positive numbers
% x are the positive numbers sorted in the descending order
% the second argument (max_gapratio) is the initially required minimum ratio between the smallest x above the threshold and the largest x below the threshold
% e.g a gapratio = 10 means that the program looks for at least 10
% between at least 1 pair of consecutive numbers in the histogram
% the threshold is then set somewhere inside this gap.
% If a gap of the specified size cannot be found, then the size of the
% required gap is progressively reduced by iteratively dividing it with a constant
% factor.
% If this gap drops below the value specified by 'min_gapratio', the
% thresholding fails and returns failed = 1 (otherwise failed = 0)

% TODO: improve this code ! can be optimzized a lot using the fact that the
% input data is sorted.
% Also, allow the gap to be reduced progressively if the initial gap cannot
% be found

function [x_th, actualgap, failed] = threshold_histogram(x,max_gapratio,min_gapratio)

if isempty(x)
    [x_th, actualgap] = deal(NaN,NaN); failed = 0;
    return;
end

if ~issorted(x(end:-1:1))
    disp('resorting ...');
    x = sort(x,'descend');
end

if x(1)<=0
    [x_th, actualgap] = deal(NaN,NaN); failed = 0;
    warning('input values x are negative but should all be positive ! returning NaN values !');
    return;
end

ratiofactor = 1.25; % this is the factor by which the gap ratio is being reduced  if a gap of the initial size cannot be found

ratio = max_gapratio;

largegapfound = 0;

x1 = x(1);
while ~largegapfound && ratio>=min_gapratio
    x2 = x1/ratio;
    aux1 = x(x<x1);
    aux2 = x(x>=x2);
    if isempty(aux1)
        disp(['could not find a gap of ratio ',num2str(ratio),' in the input data !']);
        ratio = ratio/ratiofactor;
        %         disp(['reducing the required gap ratio to ',num2str(ratio),'...']);
        x1=x(1);
    else
        largegapfound = isempty(intersect(aux1,aux2)) && ~isempty(x<x2);
        x1 = min(aux2);
    end
end


actualgap = ratio;

if largegapfound
    failed = 0;
    x_th = (x1+x2)/2;
    disp(['automated thresholding succeeded (threshold=',num2str(x_th),', gap = ',num2str(actualgap),')']);
else
    disp('automated thresholding failed !');
    failed = 1;
    x_th = NaN;
end
