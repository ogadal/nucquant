% Return string with path to the system-dependent "temporary" folder
function tmp = tmpfolder;
tmp = tempdir;
% if ispc,
%     tmp  = 'C:/WINDOWS/temp';
% else
%     tmp = '/tmp';
% end