% return the indices and the values of two local maxima in a vector

function [k1, k2, x1, x2] = two_local_max(X)

X(1) = -inf;
X(end) = -inf;

[x1, k1] = max(X);

X(k1-1:k1+1)  = - inf;

[x2, k2] = max(X);


% function res = is_local_max(X,i)
% 
% res = X(i)>X(i-1) && X(i)>X(i+1);