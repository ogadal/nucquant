% Convert a 2-channel 2-D image into an RGB image 
% (this allows to use Matlab functions such as imagesc, imadjust, which
% work only for 1-channel or 3-channel (RGB) images)
% If the input image has one or three channels, it is returned without any
% change

function Iout = twochannels2rgb(I);

if ndims(I) == 3 && size(I,3)==2
    C = class(I);
    Iout  = zeros(size(I,1),size(I,2),3,C);
    Iout(:,:,1:2) = I;
else
    Iout = I;
end
    