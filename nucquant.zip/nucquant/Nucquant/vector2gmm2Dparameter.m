function [xci,yci,Ai,b] = vector2gmm2Dparameter(parametervector)

global Ngmm;

if length(parametervector)==3*Ngmm+1
    xci = parametervector(1:Ngmm);
    yci = parametervector(Ngmm+1:2*Ngmm);
    Ai = parametervector(2*Ngmm+1:3*Ngmm);
      b = parametervector(3*Ngmm+1);
else
    error('problem 1 in vector2gmm2Dparameter !');
    parametervector
    Ngmm
end
