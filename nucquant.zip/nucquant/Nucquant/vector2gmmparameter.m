function [xci,yci,zci,Ai,b] = vector2gmmparameter(parametervector)

global Ngmm;

if length(parametervector)==4*Ngmm+1
    xci = parametervector(1:Ngmm);
    yci = parametervector(Ngmm+1:2*Ngmm);
    zci = parametervector(2*Ngmm+1:3*Ngmm);
    Ai  = parametervector(3*Ngmm+1:4*Ngmm);
    b = parametervector(4*Ngmm+1);
else
    disp('problem 1 in vector2gmmparameter !');
    parametervector
    Ngmm
    stop;
end
