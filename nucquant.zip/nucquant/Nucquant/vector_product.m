
% Compute the vector product of two 3D vectors U1 and U2
function U = vector_product(U1,U2)
x1 = U1(1); y1 = U1(2); z1 = U1(3);
x2 = U2(1); y2 = U2(2); z2 = U2(3);
x = y1*z2 - z1*y2;
y = -x1*z2 + z1*x2;
z = x1*y2 - y1*x2;
U = [x; y; z];