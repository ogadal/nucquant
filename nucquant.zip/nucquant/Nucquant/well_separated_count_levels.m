% Generate well separated count levels

function N = well_separated_count_levels(alpha,N1,Nmax)

N(1) = N1;

i = 2;
finished = 0;
while ~finished
    N(i) = poissinv(1-alpha,N(i-1));
    finished = (N(i)>Nmax);
    i=i+1;
end

N = [0 N];