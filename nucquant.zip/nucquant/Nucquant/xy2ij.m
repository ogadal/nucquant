% converts spatial coordinates into indices into a 2D matrix

function [i,j] = xy2ij(x,y,xx,yy)
i = index(x,xx);
j = index(y,yy);


% from the orderered array xx, find the value xx(k) that
% is nearest to x, and return k
function k =  index(x,xx)
aux = find(xx<=x);
aux2 = find(xx>=x);

if isempty(aux) | isempty(aux2)
    warning(['Problem in xy2ij:  x=',num2str(x),', but min(xx)=',num2str(min(xx)),' and  max(xx)=',num2str(max(xx)),'!']);
    k = NaN;
else
    km = max(aux);
    kp = min(aux2);
    if nearest(x,xx(km),xx(kp)) == 1
        k = km;
    else
        k = kp;
    end
end

% returns 1 if y is closer to x than z, otherwise returns 0
function res = nearest(x,y,z)

if abs(x-y)<abs(x-z)
    res = 1;
else
    res = 0;
end