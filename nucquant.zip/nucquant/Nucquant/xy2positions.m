% returns a long 1D vector containing the positions of all the pixels in
% the image
%
% (xx,yy) are the coordinates of the 3 axes

function pv = xy2positionvector(xx,yy)

Nx = length(xx);
Ny = length(yy);
Npix = Nx*Ny;

[i,j] = ind2sub([Nx Ny],1:Npix);
xaux = xx(i);
yaux = yy(j);

pv = [xaux(:); yaux(:)]; 