% returns a long 1D vector containing the positions of all the voxels in
% the image
%
% (xx,yy,zz) are the coordinates of the 3 axes

function pv = xyz2positionvector(xx,yy,zz)

Nx = length(xx);
Ny = length(yy);
Nz = length(zz);
Nvox = Nx*Ny*Nz;

[i,j,k] = ind2sub([Nx Ny Nz],1:Nvox);
xaux = xx(i);
yaux = yy(j);
zaux = zz(k);

pv = [xaux(:); yaux(:); zaux(:)]; 