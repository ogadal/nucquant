function [fig_whole, crop_rectangles] = zoomandcrop(I)

Igreen = I;
Ired = I;

if ndims(I)>2
    Igreen(:,:,1) = zeros(size(Igreen(:,:,2)));
    Ired(:,:,2) = zeros(size(Ired(:,:,1)));
end

% if the following boolean is set to 1, the crop rectangles already freezed when a new crop
% rectangle is created; if it is set to 0, then one can delete or move all
% rectangles in the field, but this can slow down things a lot when many
% rectangles are present !
% LATER: turn this into a user selectable option !!
freeze_rectangles = 1;


%% Set default settings using memory file, if exists
dir0 = cd; cd(tmpfolder);
if exist('zoomandcropmemory.mat','file'),
    disp('loading user settings from memory file ...');
    load('zoomandcropmemory','defsize','fig_whole_position','fig_overview_position');
else warning('no memory file found !'); end, cd(dir0);
if ~exist('defsize','var')
    defsize = [70 70]; % default size for rectangles
end

%% Instructions for the user
text4help = ['Create a rectangular crop region by clicking and/or dragging.              ', ...
    'Simultaneously press shift if you want to force the rectangles to be squares.              ', ...
    'A single click will place a rectangle of initial default size ',num2str(defsize(1)),'x',num2str(defsize(2)),' at the cursor location.              ', ...
    '(the default size will be changed once you create a new rectangle by dragging).', ...
    'You can drag the rectangle to the right place, but you cannot resize it once it is created.              ', ...
    'You can delete the current rectangle by double-clicking on it.              ', ...
    'For a high contrast view of a rectangle area, click on the rectangle and press the key "i"'              , ...
    'To create another crop region, press the space bar.              ', ...
    'To finish, press "f".              '];

disp_nice(text4help);

% helpdlg(text4help,'Zoom and crop instructions');

%% Display maximum intensity projection
fig_whole = figure('Toolbar','none','Menubar','none','NumberTitle','off');
if exist('fig_whole_position','var'),   set(fig_whole,'Position',fig_whole_position); else    place_figure(fig_whole,1,1,1,2); end
hI =  imagesc(I); axis equal; axis xy; set(gca,'YDir','reverse'); axis tight; hold on;
Nchannels = size(I,3);
if Nchannels == 1
    colormap('gray');
end
hSP = imscrollpanel(fig_whole,hI);
set(hSP,'HitTest','off');
api = iptgetapi(hSP);
api.setMagnification(2) % 2X = 200%
fig_overview = imoverview(hI);
if exist('fig_overview_position','var') && ~isempty(fig_overview_position),  set(fig_overview,'Position',fig_overview_position); else place_figure(fig_overview,2,2,1,1); end
finished = 0;
lastpoint = [NaN NaN];
set(fig_whole,'CurrentPoint',lastpoint);
set(fig_whole,'Interruptible','off');
set (fig_whole,'WindowStyle','modal');
irect=0;
irectdeleted = [];
channels_shown = 'b';
Ishow = I;

%% Interactive cropping
while finished ~=1
    irect = irect +1;
    set(fig_whole,'Name','Please select new crop rectangle (click or drag)');
    % Allow user to select rectangle by clicking or dragging
    rect = getrect(fig_whole);
    if rect(3)<5 || rect(4)<5
        rect(1:2) = rect(1:2) - defsize/2;
        rect(3:4) = defsize;
    else
        defsize = rect(3:4);  % update the default rectangle size
    end

    if ~freeze_rectangles
        hrect(irect) = imrect(gca,rect);
    else
        hrect(1) = imrect(gca,rect);
    end

    accept_rect=0;
    move2next_rect = 0;
    while move2next_rect ==0   && ~finished
        disp('Press space bar to accept new rectangle; double click or right click to delete ; "f" to finish ; click on rectangle and press "i" for a hi-contrast close-up.');
        set(fig_whole,'Name','Press space bar to accept new rectangle; "f" to finish ; "g" or "r" to display green or red channel only (or toggle back); click and press "i" for a hi-contrast close-up.');
        k = waitforbuttonpress;
        if k==0 % mouse pressed
            st = get(gcf,'SelectionType');
            switch st
                case {'open','alt'} % double click to remove a rectangle
                    if ~isempty(gco)
                        if freeze_rectangles % && ishandle(hrect(1)) (the latter condition is required for Matlab versions before 2008a)
                            delete(hrect(1));
                            move2next_rect = 1;
                            irect = irect - 1;
                            disp('rectangle deleted !!');
                        else
                            iaux = find(hrect==gco); % find over which rectangle the cursor is located
                            idelete = min(iaux);
                            delete(hrect(idelete));
                            irectdeleted = [irectdeleted idelete];
                            move2next_rect  = 1;
                            irect = irect - 1;
                        end
                    end
                otherwise
                    %%%
            end
        else % keyboard pressed
            key = get(gcf,'CurrentCharacter');
            figure(fig_whole); hold on;
            switch key
                case ' ' % accept rectangle
                    accept_rect = 1;
                    move2next_rect = 1;
                case 'f'
                    answer = questdlg('Really finished ?','','Yes','No','Yes');
                    if strcmp(answer,'Yes')
                        finished = 1;
                        accept_rect = 1;
                    end
                case 'i'
                    if ~isempty(gco)
                        if ~freeze_rectangles
                            iaux = find(hrect==gco); % find over which rectangle the cursor is located
                        else
                            iaux = 1;
                        end
                        if ~isempty(iaux),
                            % get rectangle position
                            api = iptgetapi(hrect(iaux));
                            rectzoom =  api.getPosition();
                            % crop the region and display it in a separate
                            % window
                            Izoom = imcrop(Ishow,rectzoom);
                            if exist('figzoom','var')
                                figure(figzoom);
                            else
                                figzoom = figure('Name','Hi-contrast view - DO NOT CLOSE THIS FIGURE (you can move it) !!!','NumberTitle','off');
                            end
                            imagesc(Izoom); axis equal; axis tight; axis xy; set(gca,'YDir','reverse');  hold on;
                        end
                    end
                case 'g' % show green channel only (or revert to both)
                    if channels_shown ~= 'g'
                        channels_shown = 'g';
                        Ishow = Igreen;
                    else
                        channels_shown = 'b';
                        Ishow = I;
                    end
                    set(hI,'CData',Ishow);
                case 'r' % show red channel only
                    figure(fig_whole);
                    if channels_shown ~= 'r'
                        channels_shown = 'r';
                        Ishow = Ired;
                    else
                        channels_shown = 'b';
                        Ishow = I;
                    end
                    set(hI,'CData',Ishow);
            end
        end
        if freeze_rectangles && accept_rect % && ishandle(hrect(1))  (the latter condition is required for Matlab versions before 2008a)
            api = iptgetapi(hrect(1));
            rect = api.getPosition();
            crop_rectangles{irect} = rect;
            rectangle('Position',rect,'EdgeColor','y','LineWidth',2,'LineStyle','--');
            text(rect(1)+5,rect(2),num2str(irect),'Color','y','FontSize',12,'VerticalAlignment','Top');
            delete(hrect(1));
        end
    end

end

% api.setMagnification(0.3)

%% Gather final crop regions
if ~freeze_rectangles
    irectfinal = setdiff(1:length(hrect),irectdeleted);
    if ~isempty(irectfinal)
        ii=0;
        figure(fig_whole);
        for i=irectfinal
            api = iptgetapi(hrect(i));
            rect = api.getPosition();
            set(hrect(i),'Visible','off');
            ii = ii+1;
            crop_rectangles{ii} = rect;
            rectangle('Position',rect,'EdgeColor','y','LineWidth',2,'LineStyle','--');
            text(rect(1)+5,rect(2),num2str(ii),'Color','y','FontSize',12,'VerticalAlignment','Top');
        end
    else
        crop_rectangles = [];
    end
end

set(fig_whole,'WindowStyle','normal');

%% Save user settings
fig_whole_position = get(fig_whole,'Position');
if ishandle('fig_overview')
    fig_overview_position = get(fig_overview,'Position');
else
    fig_overview_position = [];
end

dir0 = cd; cd(tmpfolder); 
save('zoomandcropmemory','defsize','fig_whole_position','fig_overview_position'); cd(dir0);

if ~exist('crop_rectangles','var')
    crop_rectangles = [];
end

end
