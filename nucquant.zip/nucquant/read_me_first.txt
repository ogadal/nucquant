This folder contains:

-Users_guide

Nucquant folder (Matlab and R code for Nucquant package (163 elements))

Sample folder containing cropped sample from one confocal stack :
(available upon request - strain yCNOD99-1, with GFP-Nup49 and mCherry-Nop1)

- 3 manually cropped nuclei (example_of_manual_crop)

- Output file of the analysed manually cropped nuclei (output_manual)

- 33 automatically cropped nuclei (example_automatic_cropped_nuclei)

- Output file of the analysed automatically cropped nuclei (output_automatic)

